package com.eve.companion

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.sqrt

/**
 * أذن إيف المحلية الخفيفة: تلتقط الكلام (بكاشف نشاط صوتي وذاكرة سابقة 400 مللي ثانية) وتسلّم كل جملة خاماً (PCM 16kHz)
 * إلى منطق التعرف في eve.html (MFCC + DTW) الذي يطابقها مع عباراتك التي علّمتها لإيف. لا نموذج جاهز ولا إنترنت.
 */
class PcmEar(
    private val onUtt: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onState: (Boolean) -> Unit,
    private val isBusy: () -> Boolean,
    private val diag: (String) -> Unit
) : Ear {
    @Volatile private var on = false

    override fun start() {
        on = true
        Thread {
            var ar: AudioRecord? = null
            try {
                val sr = 16000
                val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                ar = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 16000))
                if (ar.state != AudioRecord.STATE_INITIALIZED) { onState(false); diag("{\"stt\":\"NO_MIC\"}"); return@Thread }
                ar.startRecording(); onState(true); diag("{\"stt\":\"LOCAL\"}")
                val frame = ShortArray(1600)
                val pre = ArrayDeque<ByteArray>()
                var out = ByteArrayOutputStream()
                var floor = 250.0; var voiced = false; var silence = 0; var frames = 0; var lastLevel = 0L
                while (on) {
                    val n = ar.read(frame, 0, frame.size); if (n <= 0) continue
                    val b = ByteArray(n * 2)
                    var s = 0.0
                    for (i in 0 until n) { b[2 * i] = (frame[i].toInt() and 255).toByte(); b[2 * i + 1] = (frame[i].toInt() shr 8).toByte(); s += frame[i] * frame[i].toDouble() }
                    val rms = sqrt(s / n)
                    val t = System.currentTimeMillis()
                    if (t - lastLevel > 120) { lastLevel = t; onLevel((rms / 4000.0).coerceIn(0.0, 1.0).toFloat()) }
                    if (rms < floor * 1.6) floor = floor * 0.97 + rms * 0.03
                    val loud = rms > max(900.0, floor * 3.0) && !isBusy()
                    if (!voiced) {
                        pre.addLast(b); if (pre.size > 4) pre.removeFirst()
                        if (loud) { voiced = true; silence = 0; frames = 0; out = ByteArrayOutputStream(); for (p in pre) out.write(p); pre.clear() }
                    } else {
                        out.write(b); frames++
                        if (loud) silence = 0 else silence++
                        if (silence >= 5 || frames >= 35) {
                            if (frames - silence >= 2) onUtt(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
                            voiced = false; silence = 0
                        }
                    }
                }
            } catch (e: Exception) {
                diag("{\"stt\":\"LOCAL_ERR\"}"); onState(false)
            } finally {
                try { ar?.stop() } catch (e: Exception) { }
                try { ar?.release() } catch (e: Exception) { }
            }
        }.start()
    }

    override fun stop() { on = false }
}
