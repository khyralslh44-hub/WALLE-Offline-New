const fs=require('fs');const src=fs.readFileSync('ear.js','utf8');
const E=new Function('btoa','atob',src+';return {earFeat,earDTW,earCal,earRecog,earPack,earUnpack,earPcm}')((s)=>Buffer.from(s,'binary').toString('base64'),(s)=>Buffer.from(s,'base64').toString('binary'));
const S=require('./synth.js');S.setSeed(99);
const V=14,words=S.mkWords(V+8,5),enrolled=words.slice(0,V),unknown=words.slice(V);
const feat=(w,o)=>E.earFeat(S.word(w,S.spk(o)));
function run(label,o,nEnr=3,verbose=true){S.setSeed(1234);const T={};let fails=0;
 for(let i=0;i<V;i++){T['w'+i]=[];for(let r=0;r<nEnr;r++){const f=feat(enrolled[i]);if(f)T['w'+i].push(f);else fails++}}
 const t0=Date.now(),thr=E.earCal(T),calMs=Date.now()-t0;let ok=0,wrong=0,rej=0,N=0,ms=0;
 for(let i=0;i<V;i++)for(let r=0;r<20;r++){const f=feat(enrolled[i],o);N++;if(!f){rej++;continue}const t1=Date.now(),R=E.earRecog(f,T,thr);ms+=Date.now()-t1;if(!R.ok)rej++;else if(R.label==='w'+i)ok++;else wrong++}
 let fa=0,NU=0;for(const u of unknown)for(let r=0;r<15;r++){const f=feat(u,o);NU++;if(!f)continue;if(E.earRecog(f,T,thr).ok)fa++}
 let fn=0;for(let r=0;r<40;r++){const f=E.earFeat(S.noiseOnly());if(f&&E.earRecog(f,T,thr).ok)fn++}
 const bytes=Object.values(T).reduce((s,L)=>s+L.reduce((a,f)=>a+f.length*f[0].length,0),0);
 console.log(label.padEnd(44),`صحيح ${(100*ok/N).toFixed(0).padStart(3)}% | خطأ ${(100*wrong/N).toFixed(1).padStart(4)}% | رُفض ${(100*rej/N).toFixed(0).padStart(3)}% | كلمات غريبة قُبلت ${(100*fa/NU).toFixed(1).padStart(4)}% | ضجيج قُبل ${fn}/40 | ${(ms/Math.max(1,N-rej)).toFixed(1)}ms/تعرّف`);
 return{bytes,calMs}}
console.log('مفردات مُسجَّلة:',V,'| كلمات غريبة:',unknown.length,'| (كلام مُصطنع لا عربي حقيقي)\n');
let r=run('نفس المتكلم، 3 تسجيلات/عبارة',{});
run('نفس المتكلم، 2 تسجيلات/عبارة',{},2);
run('نفس المتكلم، ضجيج أعلى (SNR 12–18)',{snr:15});
run('متكلم مختلف قليلاً (±8% نبرة/حنجرة)',{f0:130,fs:1.08});
run('متكلم مختلف كثيراً (نبرة 190، حنجرة +20%)',{f0:190,fs:1.2});
console.log('\nحجم القوالب بعد الضغط ≈',(r.bytes/1024).toFixed(0),'KB (Int8)، معايرة',r.calMs,'ms');
const f=feat(enrolled[0]);const p=E.earUnpack(E.earPack(f));let md=0;for(let i=0;i<f.length;i++)for(let k=0;k<f[0].length;k++)md=Math.max(md,Math.abs(f[i][k]-p[i][k]));console.log('أقصى خطأ تكميم:',md.toFixed(3),'| طول التسلسل',f.length,'إطاراً (20ms)');
