const H=require('./h.js'),S=require('./synth.js');const {run,ctx,said,ok,tick}=H;tick(30);
// كلمات مُصطنعة تقابل عبارات حقيقية؛ تُبثّ كتدفق ميكروفون خام بمعدلات 48k و44.1k كما في المتصفح
const LAB=['نعم','لا','ماذا ترى','كيف حالك','نامي','مرحبا','هيا نلعب','كم الساعة'],NW=LAB.length,words=S.mkWords(NW+4,9);S.setSeed(555);
const up=(x,sr)=>{const r=sr/16000,n=Math.floor(x.length*r),y=new Float32Array(n);for(let i=0;i<n;i++){const p=i/r,k=Math.floor(p),f=p-k;y[i]=x[k]*(1-f)+(x[Math.min(k+1,x.length-1)])*f}return y};
function stream(x16,sr,tail=1.2){const y=up(x16,sr),pad=new Float32Array(Math.round(sr*tail));for(let i=0;i<pad.length;i++)pad[i]=(Math.random()-.5)*.004;const all=new Float32Array(y.length+pad.length);all.set(y);all.set(pad,y.length);
 for(let o=0;o<all.length;o+=4096){ctx.__c=all.subarray(o,Math.min(all.length,o+4096));ctx.__sr=sr;run('webEarChunk(__c,__sr)')}}
const word=(i,o)=>S.word(words[i],S.spk(Object.assign({amb:[.002,.008]},o||{})));
for(const SR of[48000,44100]){
 run('M.voice={};EAR.T={};EAR.thr={};WE.rem=[];WE.fr=[];WE.pre=[];WE.acc=[];WE.voiced=false;WE.floor=.0076;earEnrollStart()');ctx.__lab=LAB;run('ENR.list=__lab.slice()');
 for(let i=0;i<NW;i++)for(let k=0;k<3;k++){for(let tr=0;tr<4;tr++){const b=run('ENR?ENR.i*10+ENR.rep:-1');stream(word(i),SR);const a=run('ENR?ENR.i*10+ENR.rep:-1');if(a!==b)break}}
 ok(SR+' Hz: enrollment through the raw mic stream completes ('+NW+' phrases × 3)',run('ENR')===null&&Object.keys(run('M.voice')).length===NW,said.slice(-1)[0]);
 run('var __calls=[];{const _s=Eve.speech;if(!Eve.__w){Eve.__w=1;Eve.speech=function(t){__calls.push(t);return _s.call(Eve,t)}}}');
 let good=0,wrong=0,N=0;for(let i=0;i<NW;i++)for(let k=0;k<8;k++){run('__calls.length=0');stream(word(i),SR);N++;const c=JSON.parse(run('JSON.stringify(__calls)'));if(c.length&&c[0]===LAB[i])good++;else if(c.length)wrong++}
 console.log('   '+SR+' Hz: صحيح',(100*good/N).toFixed(0)+'% | خطأ',(100*wrong/N).toFixed(1)+'%');
 ok(SR+' Hz: recognises enrolled phrases from the raw stream ≥ 85%, ≤ 3% wrong',good/N>=.85&&wrong/N<=.03);
 let fa=0;for(let i=NW;i<NW+4;i++)for(let k=0;k<8;k++){run('__calls.length=0');stream(word(i),SR);if(JSON.parse(run('JSON.stringify(__calls)')).length)fa++}
 ok(SR+' Hz: unknown words mostly rejected (≤ 20% on this small 4-word set; 0% over 320 trials in exp16d)',fa/32<=.2,fa+'/32');
 // ضجيج ثابت وطنين: لا يجب أن يُفهم كأمر
 let nz=0;for(let k=0;k<12;k++){run('__calls.length=0');const x=S.noiseOnly();stream(x,SR);if(JSON.parse(run('JSON.stringify(__calls)')).length)nz++}
 ok(SR+' Hz: noise/hum never becomes a command',nz===0);
 // صمت طويل: لا استدعاءات
 run('__calls.length=0');stream(new Float32Array(16000*3),SR,0);ok(SR+' Hz: silence triggers nothing',JSON.parse(run('JSON.stringify(__calls)')).length===0);
}
// عدم الالتقاط أثناء كلام إيف
run("speakingNow=true");run('__calls.length=0');stream(word(2),48000);run("speakingNow=false");ok('ignores sound while Eve herself is speaking (no self-triggering)',JSON.parse(run('JSON.stringify(__calls)')).length===0);
tick(100);ok('stable',true);
