const fs=require('fs');const src=fs.readFileSync('ear.js','utf8');
const E=new Function('btoa','atob',src+';return {earFeat,earCal,earRecog}')(s=>Buffer.from(s,'binary').toString('base64'),s=>Buffer.from(s,'base64').toString('binary'));
const S=require('./synth.js');const V=12,words=S.mkWords(V+6,9);
// VAD مطابق لأذن المتصفح (نسخة معزولة) لمقارنة قبل/بعد على نفس الإشارات
function vadSeg(x){let floor=.0076,pre=[],acc=[],voiced=false,sil=0,frames=0,seg=null;const pad=new Float32Array(19200);for(let i=0;i<pad.length;i++)pad[i]=(Math.random()-.5)*.004;const all=new Float32Array(x.length+pad.length);all.set(x);all.set(pad,x.length);
 for(let o=0;o+1600<=all.length;o+=1600){const fr=all.subarray(o,o+1600);let s=0;for(const v of fr)s+=v*v;const rms=Math.sqrt(s/1600);if(rms<floor*1.6)floor=floor*.97+rms*.03;const loud=rms>Math.max(.012,floor*3);
  if(!voiced){pre.push(fr);if(pre.length>4)pre.shift();if(loud){voiced=true;sil=0;frames=0;acc=pre.slice();pre=[]}}
  else{acc.push(fr);frames++;if(loud)sil=0;else sil++;if(sil>=5||frames>=35){if(frames-sil>=2&&!seg){const n=acc.reduce((q,f)=>q+f.length,0);seg=new Float32Array(n);let p=0;for(const f of acc){seg.set(f,p);p+=f.length}}voiced=false;sil=0;acc=[]}}}return seg}
function exp(name,o,get){S.setSeed(4242);const T={};for(let i=0;i<V;i++){T['w'+i]=[];for(let r=0;r<3;r++){const f=get(S.word(words[i],S.spk(o)));if(f)T['w'+i].push(f)}}
 const thr=E.earCal(T);let ok=0,wr=0,N=0;for(let i=0;i<V;i++)for(let r=0;r<12;r++){const f=get(S.word(words[i],S.spk(o)));N++;if(!f)continue;const R=E.earRecog(f,T,thr);if(R.ok){if(R.label==='w'+i)ok++;else wr++}}
 let fa=0,NU=0;for(let i=V;i<V+6;i++)for(let r=0;r<10;r++){const f=get(S.word(words[i],S.spk(o)));NU++;if(!f)continue;if(E.earRecog(f,T,thr).ok)fa++}
 console.log(name.padEnd(44),'صحيح',(100*ok/N).toFixed(0).padStart(3)+'%','| خطأ',(100*wr/N).toFixed(1).padStart(4)+'%','| غريب مقبول',(100*fa/NU).toFixed(0).padStart(3)+'%')}
const direct=x=>E.earFeat(x),vad=x=>{const s=vadSeg(x);return s?E.earFeat(s):null};
console.log('— ضجيج نسبي للصوت (النموذج القديم، غير واقعي) —');exp('مباشر',{},direct);exp('عبر كاشف VAD',{},vad);
console.log('— ضجيج محيطي ثابت هادئ (rms .002–.008) —');exp('مباشر',{amb:[.002,.008]},direct);exp('عبر كاشف VAD',{amb:[.002,.008]},vad);
console.log('— ضجيج محيطي أعلى (rms .008–.02: مقهى/سيارة) —');exp('مباشر',{amb:[.008,.02]},direct);exp('عبر كاشف VAD',{amb:[.008,.02]},vad);
