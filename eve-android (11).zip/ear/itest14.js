const H=require('./h.js');const {run,ctx,said,ok,tick,getT,setT}=H;
const last=()=>said.slice(-1)[0];const ask=u=>{run(`understand(${JSON.stringify(u)})`);return last()};
tick(30);ok('replay buffer is empty after first-run training (infancy is not "experience")',run('RB.length')===0);
// ===== ذاكرة عاملة
run("M.people={'سالم':'اخي','سارة':'اختي'};M.places=[{v:[1],c:3,n:'المطبخ'}];M.ep=[];M.assoc={};M.seenObj={cup:{t:Date.now()-1e6,p:'المطبخ',x:.7,y:.5}};hadPresent=true;IDS.who='';PLACE='';OBJ=[];WM=[]");
run("{const n=Date.now();for(let i=0;i<4;i++)M.ep.push({t:n-i*6e4,p:'المطبخ',w:'سالم',o:['cup'],a:'',m:'joy',v:.5,s:'',sal:.6,c:1});for(let i=0;i<3;i++)M.ep.push({t:n-i*6e4,p:'',w:'سارة',o:[],a:'',m:'calm',v:.2,s:'',sal:.4,c:1})}");
let r=ask('ماذا تذكرين عن سالم');ok('episodic recall for a named person',/سجلتُ 4 لقطات/.test(r),r);
r=ask('متى رايته');ok('pronoun "he/him" resolved from working memory (no name given)',/سجلتُ 4 لقطات/.test(r),r);
r=ask('ماذا تذكرين عن سارة');r=ask('وماذا عنه');ok('the MOST RECENT entity wins ("what about him?" → سارة)',/سجلتُ 3 لقطات/.test(r),r);
r=ask('اين الكوب');r=ask('متى رايته');ok('object pronoun resolved ("where is the cup" → "when did you see it")',/سجلتُ 4 لقطات/.test(r)&&run('JR.some(j=>j.k==="wm"&&/كوب/.test(j.y))'),r);
run('WM=[]');r=ask('متى رايته');ok('empty working memory → asks who/what, instead of guessing or asking for a meaning',/عمّن أو عمّا تتحدث/.test(r),r);
r=ask('ماذا تذكرين عن سالم');setT(getT()+10*6e4);r=ask('متى رايته');ok('working memory fades after ~10 minutes (she no longer assumes the referent)',/عمّن أو عمّا تتحدث/.test(r),r);
run('WM=[]');for(let i=0;i<8;i++){ctx.__v='ش'+i;run('wmAdd("p",__v,1)')}ok('capacity is limited to 5 items',run('WM.length')===5&&run('WM.every(x=>["ش3","ش4","ش5","ش6","ش7"].includes(x.v))'),run('WM.map(x=>x.v).join()'));
// ===== تثبيت الذكريات
run("{M.ep=[];M.habits=[];M.prof.days={};const n=Date.now();for(let d=1;d<=10;d++){const b=n-d*864e5;for(let i=0;i<3;i++)M.ep.push({t:b+i*6e4,p:'المطبخ',w:'سالم',o:['cup'],a:'',m:'joy',v:.5,s:'',sal:.6,c:1})}for(let i=0;i<40;i++)M.ep.push({t:n-(60+i)*864e5,p:'الصالة',w:'',o:[],a:'',m:'calm',v:0,s:'',sal:.3,c:1});M.ep.push({t:n-70*864e5,p:'المكتب',w:'ليلى',o:[],a:'',m:'sad',v:-.9,s:'كلامك «ح»',sal:1,c:1});M.ep.sort((a,b)=>a.t-b.t)}");
const before=run('M.ep.length');run('consolidate()');
ok('merges bursts of near-identical moments (30 → 10 episodes with counts)',run('M.ep.filter(e=>e.w==="سالم").length')===10&&run('M.ep.filter(e=>e.w==="سالم").every(e=>e.c===3)'),before+' → '+run('M.ep.length'));
ok('forgets old trivial memories',run('M.ep.filter(e=>e.p==="الصالة").length')===0);
ok('but keeps an old emotionally intense one (forgetting depends on salience)',run('M.ep.some(e=>e.w==="ليلى")'));
const hb=run('M.habits.find(h=>h.w==="سالم"&&h.p==="المطبخ")');ok('abstracts a HABIT from repeated days (person + place + time of day)',!!hb&&hb.d===10&&hb.n===30,JSON.stringify(hb));
r=ask('ماذا تعرفين عن عاداتي');ok('answers about habits from the abstracted memory',/سالم/.test(r)&&/المطبخ/.test(r)&&/(ليلاً|صباحاً|بعد الظهر|مساءً)/.test(r)&&/10 أيام/.test(r),r);
run("M.habits=[];M.prof.days={}");r=ask('ماذا تعرفين عن عاداتي');ok('honest when she has no habits yet',/لم أكوّن عادات/.test(r),r);
run("{M.ep=[];const n=Date.now();for(let i=0;i<50;i++)M.ep.push({t:n-(200-i)*864e5*.2,p:'مهم',w:'',o:[],a:'',m:'sad',v:-.8,s:'x',sal:.95,c:1});for(let i=0;i<260;i++)M.ep.push({t:n-i*6e4,p:'عادي',w:'',o:[],a:'',m:'calm',v:0,s:'',sal:.3,c:1});M.ep.sort((a,b)=>a.t-b.t)}");
run('epPrune()');ok('when memory is full it drops the unimportant, not the oldest (salience-weighted retention)',run('M.ep.length')===270&&run('M.ep.filter(e=>e.p==="مهم").length')===50,run('M.ep.length')+' kept, important kept: '+run('M.ep.filter(e=>e.p==="مهم").length')+'/50');
// ===== إعادة التشغيل العاطفي أثناء النوم
let sd=5;const rn=()=>{sd=(sd*1664525+1013904223)>>>0;return sd/4294967296-.5};const x1=Array.from({length:40},rn),x2=x1.map(v=>.7*v+.3*rn());ctx.__x1=x1;ctx.__x2=x2;
const R=run(`(function(){const zf=x=>{BR.r.fill(0);BR.s.fill(0);BR.yh=null;const v=BR.x;v.fill(0);for(let i=0;i<40;i++)v[i]=x[i];for(let t=0;t<40;t++)bcore(v,false);return Float32Array.from(BR.z)};
 const z1=zf(__x1),z2=zf(__x2),TA=[.8,.5,.5],TB=[-.7,.8,.1],err=(z,T)=>{let e=0;for(let k=0;k<3;k++){let a=0;for(let i=0;i<NZ;i++)a+=BR.Wa[k*NZ+i]*z[i];e+=Math.abs(Math.tanh(a)-T[k])}return e/3},W0=Float32Array.from(BR.Wa),out={};
 let cs=0,n1=0,n2=0;for(let i=0;i<NZ;i++){cs+=z1[i]*z2[i];n1+=z1[i]*z1[i];n2+=z2[i]*z2[i]}out.cos=cs/Math.sqrt(n1*n2);
 for(const mode of['none','replay']){BR.Wa.set(W0);RB=[];for(let i=0;i<40;i++){learnAffZ(z1,TA,1);RB.push({z:z1,T:TA,st:1})}const eA1=err(z1,TA);
  for(let i=0;i<200;i++){learnAffZ(z2,TB,1);if(i%10===0)RB.push({z:z2,T:TB,st:1})}const eA2=err(z1,TA);
  if(mode==='replay')replay(150);out[mode]={eA1,eA2,eA3:err(z1,TA),eB3:err(z2,TB)}}BR.Wa.set(W0);RB=[];return out})()`);
const f=x=>x.toFixed(3);console.log('   تشابه حالتي الدماغ للتجربتين (cos):',f(R.cos));
for(const m of['none','replay'])console.log(`   ${m==='none'?'بلا إعادة تشغيل':'مع إعادة تشغيل أثناء النوم'}: خطأ A بعد تعلّمه ${f(R[m].eA1)} ← بعد تعلم B المتداخل ${f(R[m].eA2)} ← بعد النوم ${f(R[m].eA3)} | خطأ B بعد النوم ${f(R[m].eB3)}`);
ok('interference is real: learning B makes her forget A',R.none.eA2>R.none.eA1+.1);
ok('without sleep replay the forgetting stays',R.none.eA3>R.none.eA2-.02);
ok('sleep replay recovers A (error cut by ≥ 40%) while keeping B',R.replay.eA3<.6*R.replay.eA2&&R.replay.eB3<.35,f(R.replay.eA2)+' → '+f(R.replay.eA3));
// ربط حقيقي: تُخزَّن التجارب القوية فقط وتُعاد أثناء النوم فقط
run('RB=[]');run('learnAff([.8,.5,.5],1)');run('learnAff([.2,.2,.2],.3)');ok('only strong emotional experiences enter the replay buffer',run('RB.length')===1);
const sumW=()=>run('(()=>{let s=0;for(const v of BR.Wa)s+=v*v;return s})()');run('asleep=false');const w0=sumW();tick(60);const w1=sumW();run('asleep=true;S.en=.1');tick(60);const w2=sumW();
ok('replay changes the network only while asleep',Math.abs(w1-w0)<1e-6*Math.max(1,w0)&&Math.abs(w2-w1)>0,w0.toFixed(4)+' | '+w1.toFixed(4)+' | '+w2.toFixed(4));
run('asleep=false');
// ===== دخان واسع للميزات القديمة
{let bad=0;const P=['مرحبا','كيف حالك','انتي جميله','احبك','انا حزين','كم الساعة','ماذا تفعلين','ما اسمك','احب القهوة','عيد ميلاد اخي سالم 5 مارس','في اي فصل نحن','ما خطتنا اليوم','كيف كان اسبوعي','ماذا فعلتي اليوم','لماذا انت حزينه','هل كل شيء يعمل','هل انت واعيه','اين الكوب','متي رايت سالم','ساعديني اختار بين القهوة والشاي','الغي','ساعديني لا استطيع النوم','لا','اريد ان اموت','غني لي','شطرنج','نامي','ذكرني بعد 10 دقائق ان اشرب الماء','ساعديني ان اخطط لانجاز تقرير العمل خلال 3 ايام','اقترحي'];
 for(const p of P){try{ctx.__p=p;run('understand(__p)');run('DLG=null;ASK=null')}catch(e){bad++;console.log('   EXC',p,e.message)}}ok('smoke: '+P.length+' representative phrases run without exceptions',bad===0)}
tick(300);ok('stable after 300 ticks',true);
