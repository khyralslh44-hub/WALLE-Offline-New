/*WEBEAR_START*/
/* ===== أذن المتصفح: التقاط الميكروفون عبر WebAudio ثم نفس الأذن المحلية. لا جوجل ولا أندرويد ولا إنترنت ===== */
var WE={rem:[],pre:[],acc:[],voiced:false,sil:0,frames:0,floor:.0076,fr:[]};
function webEarChunk(x,sr){const r=sr/16000,a=WE.rem.length?(()=>{const t=new Float32Array(WE.rem.length+x.length);t.set(WE.rem);t.set(x,WE.rem.length);return t})():x;
 let k=0;const out=[];while(Math.floor((k+1)*r)<=a.length){const i0=Math.floor(k*r),i1=Math.floor((k+1)*r);let s=0;for(let i=i0;i<i1;i++)s+=a[i];out.push(s/Math.max(1,i1-i0));k++}
 WE.rem=Array.from(a.subarray(Math.floor(k*r)));for(const v of out){WE.fr.push(v);if(WE.fr.length>=1600){webEarFrame(Float32Array.from(WE.fr));WE.fr=[]}}}
function webEarFrame(fr){let s=0;for(const v of fr)s+=v*v;const rms=Math.sqrt(s/fr.length);if(rms<WE.floor*1.6)WE.floor=WE.floor*.97+rms*.03;
 const busy=speakingNow||(typeof speechSynthesis!=='undefined'&&speechSynthesis.speaking),loud=rms>Math.max(.012,WE.floor*3)&&!busy;
 if(!WE.voiced){WE.pre.push(fr);if(WE.pre.length>4)WE.pre.shift();if(loud){WE.voiced=true;WE.sil=0;WE.frames=0;WE.acc=WE.pre.slice();WE.pre=[]}}
 else{WE.acc.push(fr);WE.frames++;if(loud)WE.sil=0;else WE.sil++;
  if(WE.sil>=5||WE.frames>=35){if(WE.frames-WE.sil>=2){const n=WE.acc.reduce((q,f)=>q+f.length,0),x=new Float32Array(n);let o=0;for(const f of WE.acc){x.set(f,o);o+=f.length}earHandleX(x)}WE.voiced=false;WE.sil=0;WE.acc=[]}}}
/*WEBEAR_END*/
