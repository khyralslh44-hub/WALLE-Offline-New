/*EAR_START*/
/* ===== أذن إيف المحلية الخفيفة: MFCC + DTW + معايرة ذاتية. تتعلم عباراتك بصوتك أنت (بلا نموذج جاهز ولا إنترنت) ===== */
const EAR={W:400,H:160,NF:512,NM:26,NC:12,T:{},thr:{},rej:0,p:{lift:0,dw:1,ew:1,cs:1,nc:12}};
const EAR_HAM=Float32Array.from({length:EAR.W},(_,i)=>.54-.46*Math.cos(2*Math.PI*i/(EAR.W-1)));
function earFFT(re,im){const n=re.length;for(let i=1,j=0;i<n;i++){let b=n>>1;for(;j&b;b>>=1)j^=b;j^=b;if(i<j){let t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t}}
 for(let len=2;len<=n;len<<=1){const a=-2*Math.PI/len,wr=Math.cos(a),wi=Math.sin(a),h=len>>1;for(let i=0;i<n;i+=len){let cr=1,ci=0;for(let j=0;j<h;j++){const p=i+j,q=p+h,vr=re[q]*cr-im[q]*ci,vi=re[q]*ci+im[q]*cr;re[q]=re[p]-vr;im[q]=im[p]-vi;re[p]+=vr;im[p]+=vi;const t=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=t}}}}
const earMel=f=>2595*Math.log10(1+f/700),earIMel=m=>700*(Math.pow(10,m/2595)-1);
const EAR_FB=(()=>{const lo=earMel(100),hi=earMel(7600),p=Array.from({length:EAR.NM+2},(_,i)=>Math.floor((EAR.NF+1)*earIMel(lo+(hi-lo)*i/(EAR.NM+1))/16000)),fb=[];
 for(let m=1;m<=EAR.NM;m++){const f=new Float32Array(EAR.NF/2+1);for(let k=p[m-1];k<p[m];k++)f[k]=(k-p[m-1])/((p[m]-p[m-1])||1);for(let k=p[m];k<p[m+1];k++)f[k]=(p[m+1]-k)/((p[m+1]-p[m])||1);fb.push(f)}return fb})();
const EAR_DCT=Array.from({length:EAR.NC},(_,c)=>Float32Array.from({length:EAR.NM},(_,m)=>Math.cos(Math.PI*(c+1)*(m+.5)/EAR.NM)));
const EAR_LIFT=Float32Array.from({length:EAR.NC},(_,k)=>1+11*Math.sin(Math.PI*(k+1)/22));
/** x: Float32 (16 kHz) → سلسلة سمات (25 بُعداً، خطوة 20 مللي ثانية) بعد قص الصمت؛ أو null إن لم يصلح الصوت */
function earFeat(x){const n=Math.floor((x.length-EAR.W)/EAR.H)+1;if(n<20)return null;const re=new Float32Array(EAR.NF),im=new Float32Array(EAR.NF),C=[],E=[];
 for(let f=0;f<n;f++){re.fill(0);im.fill(0);let e=0;for(let i=0;i<EAR.W;i++){const o=f*EAR.H+i,v=(x[o]-(o?x[o-1]:0)*.97)*EAR_HAM[i];re[i]=v;e+=v*v}
  earFFT(re,im);const me=new Float32Array(EAR.NM);for(let m=0;m<EAR.NM;m++){let s=0;const fb=EAR_FB[m];for(let k=0;k<=EAR.NF/2;k++)if(fb[k])s+=fb[k]*(re[k]*re[k]+im[k]*im[k]);me[m]=Math.log(s+1e-3)}
  const c=new Float32Array(EAR.NC);for(let k=0;k<EAR.NC;k++){let s=0;for(let m=0;m<EAR.NM;m++)s+=EAR_DCT[k][m]*me[m];c[k]=s*(EAR.p.lift?EAR_LIFT[k]:1)}C.push(c);E.push(Math.log(e/EAR.W+1e-3))}
 let emax=-1e9;for(const v of E)if(v>emax)emax=v;let a=0,b=n-1;while(a<n&&E[a]<emax-4.2)a++;while(b>a&&E[b]<emax-4.2)b--;a=Math.max(0,a-3);b=Math.min(n-1,b+3);
 if(b-a+1<14||b-a+1>260)return null;const mean=new Float32Array(EAR.NC);for(let f=a;f<=b;f++)for(let k=0;k<EAR.NC;k++)mean[k]+=C[f][k];for(let k=0;k<EAR.NC;k++)mean[k]/=(b-a+1);
 const S=[];for(let f=a;f+1<=b;f+=2){const v=new Float32Array(EAR.NC+1);for(let k=0;k<EAR.NC;k++)v[k]=((C[f][k]+C[f+1][k])/2-mean[k])*EAR.p.cs;v[EAR.NC]=((E[f]+E[f+1])/2-emax)*EAR.p.ew;S.push(v)}
 const T=S.length;if(T<7)return null;const out=[];for(let t=0;t<T;t++){const p=S[Math.max(0,t-1)],q=S[Math.min(T-1,t+1)],v=new Float32Array(2*EAR.NC+1);for(let k=0;k<EAR.NC;k++){if(k>=EAR.p.nc){v[k]=0;v[EAR.NC+1+k]=0;continue}v[k]=S[t][k];v[EAR.NC+1+k]=(q[k]-p[k])*EAR.p.dw}v[EAR.NC]=S[t][EAR.NC];out.push(v)}return out}
function earDTW(a,b){const n=a.length,m=b.length,w=Math.max(8,Math.ceil(.35*Math.max(n,m)),Math.abs(n-m)+2),INF=1e9;let prev=new Float32Array(m+1).fill(INF),cur=new Float32Array(m+1);prev[0]=0;
 for(let i=1;i<=n;i++){cur.fill(INF);const x=a[i-1],j0=Math.max(1,i-w),j1=Math.min(m,i+w);for(let j=j0;j<=j1;j++){const y=b[j-1];let d=0;for(let k=0;k<x.length;k++){const t=x[k]-y[k];d+=t*t}cur[j]=Math.sqrt(d)+Math.min(prev[j],prev[j-1],cur[j-1])}const t=prev;prev=cur;cur=t}return prev[m]/(n+m)}
/** توحيد مقياس كل بُعد بانحرافه المعياري في أمثلة المستخدم نفسه (يُخزَّن مع القوالب) */
function earSD(T){const d=2*EAR.NC+1,s=new Float32Array(d),s2=new Float32Array(d);let n=0;for(const L of Object.values(T))for(const f of L)for(const v of f){n++;for(let k=0;k<d;k++){s[k]+=v[k];s2[k]+=v[k]*v[k]}}
 const sd=new Float32Array(d);for(let k=0;k<d;k++){const m=s[k]/n,va=s2[k]/n-m*m;sd[k]=va>1e-8?1/Math.sqrt(va):0}return sd}
const earScale=(F,sd)=>F.map(v=>Float32Array.from(v,(x,k)=>x*sd[k]));
/** معايرة ذاتية لكل عبارة: عتبتها = أكبر تباين داخلي ×1.35، وبحيث تبقى أقل من 0.8 من أقرب عبارة أخرى */
function earCal(T){const thr={},labs=Object.keys(T);
 for(const l of labs){const L=T[l];let intra=0;if(L.length>=2){for(let i=0;i<L.length;i++){let mn=1e9;for(let j=0;j<L.length;j++)if(j!==i)mn=Math.min(mn,earDTW(L[i],L[j]));intra=Math.max(intra,mn)}}else intra=.5;
  let cross=1e9;for(const o of labs)if(o!==l)for(const a of L)for(const b of T[o])cross=Math.min(cross,earDTW(a,b));
  let t=intra*1.35+.02;if(cross<1e8)t=Math.min(t,Math.max(intra*1.05+.01,cross*.8));thr[l]={t,intra,cross}}return thr}
function earRecog(f,T,thr){let best=null,bd=1e9,sd=1e9;for(const l of Object.keys(T)){let d=1e9;for(const t of T[l])d=Math.min(d,earDTW(f,t));if(d<bd){sd=bd;bd=d;best=l}else if(d<sd)sd=d}
 if(!best)return{ok:false,label:null,d:bd};const t=thr[best]?thr[best].t:.5;return{ok:bd<=t&&(sd>=1e8||sd>=bd*1.08),label:best,d:bd,t,second:sd}}
/* تخزين مضغوط: Int16 بدقة 1/64 (مدى ±512): السمات قد تصل لعشرات القيم فلا يصلح Int8 */
function earPack(F){const n=F.length,d=F[0].length,u=new Int16Array(n*d);for(let i=0;i<n;i++)for(let k=0;k<d;k++)u[i*d+k]=Math.max(-32767,Math.min(32767,Math.round(F[i][k]*64)));const by=new Uint8Array(u.buffer);let s='';for(let i=0;i<by.length;i+=4096)s+=String.fromCharCode.apply(null,by.subarray(i,Math.min(by.length,i+4096)));return{n,d,b:btoa(s)}}
function earUnpack(o){const s=atob(o.b),F=[];for(let i=0;i<o.n;i++){const v=new Float32Array(o.d);for(let k=0;k<o.d;k++){const q=2*(i*o.d+k);let c=s.charCodeAt(q)|(s.charCodeAt(q+1)<<8);if(c>32767)c-=65536;v[k]=c/64}F.push(v)}return F}
/** تعلّم ذاتي حذر: قالب جديد من تعرّف واثق فقط (يكيّف القوالب مع ضجيج غرفتك) */
function earLearn(T,thr,label,f,d){const L=T[label];if(!L||!thr[label]||d>.7*thr[label].t||L.length>=6)return false;L.push(f);return true}
function earPcm(b64){const s=atob(b64),n=s.length>>1,x=new Float32Array(n);for(let i=0;i<n;i++){let v=s.charCodeAt(2*i)|(s.charCodeAt(2*i+1)<<8);if(v>32767)v-=65536;x[i]=v/32768}return x}
/*EAR_END*/
