const H=require('./h.js'),S=require('./synth.js');const {run,ctx,said,els,eng,ok,tick}=H;
const last=()=>said.slice(-1)[0];tick(30);
ok('app boots with the new modules',run('ELM.ready&&BR.ready&&typeof earFeat==="function"&&typeof arPack==="function"'));
// ===== أذن محلية: دورة التعليم الحقيقية داخل التطبيق
const LAB=['نعم','لا','ماذا ترى','كيف حالك','نامي','مرحبا','هيا نلعب','كم الساعة'],words=S.mkWords(LAB.length+6,5),NW=LAB.length;
S.setSeed(321);const u=(i,o)=>S.toB64(S.word(words[i],S.spk(o||{})));
run('earEnrollStart()');ok('enrollment starts and switches the native engine to "local"',eng[eng.length-1]==='local'&&/سنعلّم أذني صوتك/.test(said.find(x=>/سنعلّم/.test(x))||''));
ctx.__lab=LAB;run('ENR.list=__lab.slice()');
for(let i=0;i<NW;i++)for(let r=0;r<3;r++){ctx.__u=u(i);run('Eve.utt(__u)')}
ok('3 repetitions × '+NW+' phrases are stored and enrollment ends',run('ENR')===null&&Object.keys(run('M.voice')).length===NW&&run('M.voice["نعم"].length')===3&&/انتهينا/.test(last()),last());
run('var __calls=[];{const _s=Eve.speech;Eve.speech=function(t){__calls.push(t);return _s.call(Eve,t)}}');
const MAP={'نعم':'نعم','لا':'لا','ماذا ترى':'ماذا ترى','كيف حالك':'كيف حالك','نامي':'نامي','مرحبا':'مرحبا','هيا نلعب':'هيا نلعب','كم الساعة':'كم الساعة'};
let good=0,wrong=0,miss=0,N=0;for(let i=0;i<NW;i++)for(let r=0;r<12;r++){run('__calls.length=0');ctx.__u=u(i);run('Eve.utt(__u)');N++;const c=run('JSON.stringify(__calls)'),cc=JSON.parse(c);if(!cc.length)miss++;else if(cc[0]===MAP[LAB[i]])good++;else wrong++}
console.log('   تعرّف حي داخل التطبيق: صحيح',(100*good/N).toFixed(0)+'%','| خطأ',(100*wrong/N).toFixed(1)+'%','| رُفض',(100*miss/N).toFixed(0)+'%');
ok('recognises your enrolled phrases (synthetic speech) ≥ 85% with ≤ 3% wrong',good/N>=.85&&wrong/N<=.03);
let fa=0,NU=0;for(let i=NW;i<NW+6;i++)for(let r=0;r<10;r++){run('__calls.length=0');ctx.__u=u(i);run('Eve.utt(__u)');NU++;if(JSON.parse(run('JSON.stringify(__calls)')).length)fa++}
let fn=0;for(let r=0;r<30;r++){run('__calls.length=0');ctx.__u=S.toB64(S.noiseOnly());run('Eve.utt(__u)');if(JSON.parse(run('JSON.stringify(__calls)')).length)fn++}
console.log('   كلمات غير مُعلَّمة قُبلت:',fa,'/',NU,'| ضجيج قُبل:',fn,'/ 30');ok('rejects unknown words (≤ 8%) and never accepts pure noise',fa/NU<=.08&&fn===0);
ok('self-learning keeps ≤ 6 templates per phrase',Object.values(run('M.voice')).every(L=>L.length<=6)&&Object.values(run('M.voice')).some(L=>L.length>3),JSON.stringify(Object.fromEntries(Object.entries(run('M.voice')).map(([k,v])=>[k,v.length]))));
run('EAR.T={};EAR.thr={};earLoad()');run('__calls.length=0');ctx.__u=u(2);run('Eve.utt(__u)');ok('after reload from saved storage it still recognises (pack/unpack round-trip)',JSON.parse(run('JSON.stringify(__calls)'))[0]==='ماذا ترى');
ok('templates are compact',JSON.stringify(run('M.voice')).length<400*1024,Math.round(JSON.stringify(run('M.voice')).length/1024)+' KB for '+NW+' phrases');
// اختبار الأذن بصوتك
run('earTestStart()');ok('self-test starts',run('ENR&&ENR.mode')==='test');const order=run('ENR.list');for(const l of order){ctx.__u=u(LAB.indexOf(l));run('Eve.utt(__u)')}
ok('self-test reports a real accuracy figure',/دقة أذني المحلية على صوتك: (\d+)٪/.test(last())&&+last().match(/(\d+)٪/)[1]>=75,last());
// تخطي ولمس
run('earEnrollStart()');run('ENR.list=["نعم","لا"]');run('earSkip()');ok('tapping the screen skips a phrase during enrollment',run('ENR.i')===1&&/العبارة التالية/.test(last()),last());run('ENR=null');
// الزر والمحرك
run("M.cfg.stt='auto'");eng.length=0;els.bEng.onclick();els.bEng.onclick();els.bEng.onclick();run('M.cfg.stt');ok('engine button cycles google → local → auto',JSON.stringify(eng)==='["google","local","auto"]',JSON.stringify(eng));
run("M.cfg.stt='local';M.voice={};EAR.T={};EAR.thr={}");ok('health check tells her ear has no phrases yet when engine is "local"',run('healthProblems().some(p=>p[0]==="earT")'));
// ===== الحزمة اللغوية: تصحيح أخطاء التعرف
run("M.people={'سالم':'اخي','ليلى':'امي'};M.cfg.stt='auto'");
const SENT=['ذكرني بعد عشر دقائق ان اشرب الماء','ماذا ترى','ماذا تفعلين','متي رايت سالم','اين الكوب','عيد ميلاد سالم 5 مارس','ما خطتنا اليوم','كيف كان اسبوعي','هل كل شيء يعمل','حجر ورقه مقص','غني لي','نامي','ساعديني اختار بين القهوه والشاي','ماذا فعلتي اليوم'];
const CONF={'ت':'ث','ث':'ت','س':'ص','ص':'س','ز':'ذ','ذ':'ز','د':'ض','ض':'د','ط':'ت','ه':'ة','ك':'ق','ق':'ك','ح':'خ','خ':'ح','ع':'غ','غ':'ع'};
let sd=1;const rnd=()=>{sd=(sd*1664525+1013904223)>>>0;return sd/4294967296};
const ops={'خلط حرفين متشابهين (ت/ث، س/ص، ز/ذ…)':w=>{const ix=[...w].map((c,i)=>CONF[c]?i:-1).filter(i=>i>=0);if(!ix.length)return null;const i=ix[Math.floor(rnd()*ix.length)];return w.slice(0,i)+CONF[w[i]]+w.slice(i+1)},'حذف حرف':w=>{const i=1+Math.floor(rnd()*(w.length-2));return w.slice(0,i)+w.slice(i+1)},'إضافة حرف':w=>{const i=1+Math.floor(rnd()*(w.length-1));return w.slice(0,i)+'ا'+w.slice(i)},'تبديل حرفين متجاورين':w=>{const i=1+Math.floor(rnd()*(w.length-3));return w.slice(0,i)+w[i+1]+w[i]+w.slice(i+2)}};
const R={};let falseCh=0,cleanN=0;
for(const s of SENT){const toks=s.split(' ');for(let ti=0;ti<toks.length;ti++){const w=toks[ti];if(w.length<4||/\d/.test(w)||!run(`arpLex().has(nz(${JSON.stringify(w)}))`))continue;
  for(const[name,f]of Object.entries(ops)){const c=f(w);if(!c||c===w)continue;const bad=toks.slice();bad[ti]=c;ctx.__b=bad.join(' ');ctx.__g=s;const r=run('nz(arPack(__b))===nz(__g)');(R[name]=R[name]||[0,0])[1]++;if(r)R[name][0]++}}}
console.log('\n   استرجاع الجملة الصحيحة بعد خطأ تعرّف مُصطنع في كلمة واحدة (الحزمة اللغوية):');
for(const[k,[a,b]]of Object.entries(R))console.log('    ',k.padEnd(40),(100*a/b).toFixed(0)+'%','('+a+'/'+b+')');
const CLEAN=['اليوم ذهبت الي السوق','شاهدت فيلما جميلا مع احمد','زياد وفاطمه في الحديقه','يوسف يحب كرة القدم','سارة تدرس الهندسه','هذا كتاب مفيد جدا','لدي موعد مع الطبيب غدا',...SENT];
for(const s of CLEAN){ctx.__c=s;cleanN++;if(!run('nz(arPack(__c))===nz(__c)'))falseCh++}
console.log('   تغييرات خاطئة على جمل سليمة (أسماء وكلمات عادية خارج القاموس):',falseCh,'/',cleanN);
ok('language pack fixes most 1-word recognition errors',Object.values(R).reduce((s,[a])=>s+a,0)/Object.values(R).reduce((s,[,b])=>s+b,0)>=.6);
ok('and never rewrites clean sentences, names or ordinary words',falseCh===0);
// ===== دخان واسع: كل عائلات النوايا القديمة ما زالت تعمل دون استثناءات
{let bad=0;const P=['مرحبا','كيف حالك','انتي جميله','احبك','انا حزين','انا تعبان','كم الساعة','ماذا تفعلين','ما اسمك','كيف الجو اليوم','احكي لي نكتة','احب القهوة','لا احب الزحام','عيد ميلاد اخي سالم 5 مارس','في اي فصل نحن','ما تاريخ اليوم','ما خطتنا اليوم','كيف كان اسبوعي','ماذا فعلتي اليوم','لماذا انت حزينه','ماذا تفعلين','هل كل شيء يعمل','هل انت واعيه','هل يمكنني الاعتماد عليك','اين الكوب','متي رايت سالم','ساعديني اختار بين القهوة والشاي','الغي','ساعديني لا استطيع النوم','لا','اريد ان اموت','غني لي','شطرنج','نامي','هل تحبينني فعلا','القطه نائمه على الاريكه'];
 for(const p of P){try{ctx.__p=p;run('understand(__p)');run('DLG=null;ASK=null;openGames&&0')}catch(e){bad++;console.log('   EXC',p,e.message)}}
 ok('smoke: '+P.length+' representative phrases run without exceptions',bad===0)}
// ===== دخان: الميزات القديمة لم تتأثر
run("understand('مرحبا')");ok('smoke: greeting still answers',said.length>0&&typeof last()==='string');
run("understand('ذكرني بعد 10 دقائق ان اشرب الماء')");ok('smoke: reminders still work',run('M.rem.length')===1&&/سأذكّرك بعد 10 دقائق/.test(last()),last());
run("understand('ساعديني ان اخطط لانجاز تقرير العمل خلال 3 ايام')");ok('smoke: planning dialogue still works',/ما خطواتك/.test(last()),last());
tick(300);ok('stable after 300 ticks',true);
