const H=require('./h.js'),S=require('./synth.js');const {run,ctx,said,eng,ok,tick}=H;
const last=()=>said.slice(-1)[0];const ask=u=>{run(`understand(${JSON.stringify(u)})`);return last()};
tick(30);
// ===== تطبيع اللهجة (نصياً)
const N=u=>{ctx.__u=u;return run('nz(dialNorm(__u))')};
const cases=[['شن تسوي','ماذا تفعلين'],['شن اخبارك','كيف حالك'],['وين الكوب','اين الكوب'],['علاش انتي حزينه','لماذا انتي حزينه'],['نبي نلعب','اريد نلعب'],['ما نبيش','لا اريد'],['باهي','حسنا'],['توا نمشي','الان نمشي'],['شن اسمك','ما اسمك'],['ذكرني بعد نص ساعه','ذكرني بعد نصف ساعه'],['شبيك','ما بك'],['كيفاش الجو','كيف الجو'],['مانيش فرحان','لست فرحان'],['يعطيك الصحه','شكرا']];
let g=0;for(const[a,b]of cases){const r=N(a);if(r===b)g++;else console.log('   ✗',a,'→',r,'(المتوقع',b+')')}
ok('dialect normaliser maps '+cases.length+' Libyan forms to the Arabic the NLU already understands',g===cases.length,g+'/'+cases.length);
const MSA=['ماذا تفعلين','اين الكوب','ذهبت الى السوق','هل كل شيء يعمل','ذكرني بعد عشر دقائق ان اشرب الماء','ما خطتنا اليوم','اريد ان انجز التقرير'];let unchanged=0;for(const m of MSA){ctx.__u=m;if(run('dialNorm(__u)')===m)unchanged++}
ok('standard Arabic is left untouched',unchanged===MSA.length,unchanged+'/'+MSA.length);
// ===== أثرها على الفهم الفعلي
run("M.seenObj={cup:{t:Date.now()-36e5,p:'المطبخ',x:.7,y:.5}};M.places=[{v:[1],c:3,n:'المطبخ'}];hadPresent=true");
let r=ask('شن تسوي');ok('Libyan "what are you doing?" gets the grounded answer',/لأن|أراقب|أفكر|أحاول/.test(r)&&/«/.test(r),r);
r=ask('وين الكوب');ok('Libyan "where is the cup?" uses her object memory',/رأيت الكوب آخر مرة/.test(r),r);
run("emo='sad'");r=ask('علاش انتي حزينه');ok('Libyan "why are you sad?" gets her real explanation',/أشعر الآن بـ«الحزن»/.test(r),r);
r=ask('شن اخبارك');ok('Libyan "how are you?" is answered',typeof r==='string'&&r.length>2&&!/ماذا يعني/.test(r),r);
run("ASK={k:'confirm',name:'وعاء',vec:[1,2,3],until:Date.now()+9e4};M.things['وعاء']=[[1,2,3]]");r=ask('باهي');ok('Libyan "باهي" works as YES inside a yes/no question',/شكراً، تعلمت شكل «وعاء»/.test(r),r);
r=ask('ذكرني بعد نص ساعه اشرب الماء');ok('Libyan reminder ("نص ساعة") creates a reminder',run('M.rem.length')>=1&&/سأذكّرك بعد 30 دقيقة/.test(r),r);
r=ask('نبي نلعب');ok('Libyan "I want to play" starts the games flow',/(هيا|أطارد|ألعاب|نلعب|شطرنج|لعبة)/.test(r),r);
// ===== تعليم اللهجة من المستخدم
r=ask('في لهجتنا كابينه تعني حمام');ok('she learns a new dialect word from you',/تعلمت: «كابينه»/.test(r)&&run('M.dial["كابينه"]')==='حمام',r);
ok('and applies it afterwards, with or without the article "ال"',N('وين الكابينه')==='اين الحمام'&&N('كابينه جميله')==='حمام جميله',N('وين الكابينه'));
r=ask('ماذا تعرفين عن لهجتنا');ok('can say what she knows (and warns her lexicon may be wrong)',/كلمة من قاموسي الأولي/.test(r)&&/«كابينه» = حمام/.test(r)&&/فصحّحني/.test(r),r);
r=ask('انسي كلمه كابينه من لهجتنا');ok('can unlearn a word',/نسيت/.test(r)&&N('وين الكابينه')==='اين الكابينه');
// ===== الحزمة اللغوية لا تفسد كلمات اللهجة
for(const w of['شن تسوي','توا نمشي','نبي نلعبو','وين الكوب','باهي ياسر'])ok('ASR language pack leaves Libyan words alone: '+w,run(`nz(arPack(${JSON.stringify(w)}))===nz(${JSON.stringify(w)})`));
// ===== الأذن المحلية: حزمة العبارات الليبية بصوتك
const LAB=run('CMDS_LY.map(c=>c[0])'),NW=LAB.length;ok('Libyan phrase pack has '+NW+' phrases',NW===12);
const words=S.mkWords(NW+4,17);S.setSeed(77);const u=(i,o)=>S.toB64(S.word(words[i],S.spk(o||{})));
run('M.voice={};EAR.T={};EAR.thr={};earEnrollStart("ly")');ok('"Libyan ear" enrollment lists the Libyan phrases first',run('ENR.list[0]')==='شن تسوي'&&run('ENR.list.length')===NW&&eng[eng.length-1]==='local');
for(let i=0;i<NW;i++)for(let k=0;k<3;k++){ctx.__u=u(i);run('Eve.utt(__u)')}
ok('enrollment completes and stores every Libyan phrase',run('ENR')===null&&Object.keys(run('M.voice')).length===NW,said.slice(-1)[0]);
run('var __calls=[];{const _s=Eve.speech;Eve.speech=function(t){__calls.push(t);return _s.call(Eve,t)}}');
const MAP=Object.fromEntries(run('CMDS_LY.map(c=>[c[0],c[1]])'));let good=0,wrong=0,N2=0;
for(let i=0;i<NW;i++)for(let k=0;k<10;k++){run('__calls.length=0');ctx.__u=u(i);run('Eve.utt(__u)');N2++;const c=JSON.parse(run('JSON.stringify(__calls)'));if(c.length&&c[0]===MAP[LAB[i]])good++;else if(c.length)wrong++}
console.log('   تعرّف الأوامر الليبية (كلام مُصطنع):',(100*good/N2).toFixed(0)+'% صحيح |',(100*wrong/N2).toFixed(1)+'% خطأ');
ok('Libyan commands recognised via your own voice ≥ 85%, ≤ 3% wrong',good/N2>=.85&&wrong/N2<=.03);
run('__calls.length=0');ctx.__u=u(3);run('Eve.utt(__u)');ok('a spoken Libyan command reaches the right intent ("نبي نلعبو" → game)',JSON.parse(run('JSON.stringify(__calls)'))[0]==='هيا نلعب');
// ===== دخان
{let bad=0;for(const p of['مرحبا','كيف حالك','ماذا تفعلين','ماذا ترى','اين الكوب','ساعديني اختار بين القهوة والشاي','الغي','اريد ان اموت','ما خطتنا اليوم','متي رايت سالم']){try{ctx.__p=p;run('understand(__p)');run('DLG=null;ASK=null')}catch(e){bad++;console.log('EXC',p,e.message)}}ok('smoke: standard-Arabic phrases still run',bad===0)}
tick(200);ok('stable',true);
