/*LIFE6_START*/
/* ===== بنية أقرب للدماغ: ذاكرة عاملة وإحالة الضمائر، تثبيت الذكريات أثناء النوم، وإعادة تشغيل للتعلم العاطفي ===== */
M.habits=M.habits||[];var WM=[],RB=[];
/* ---- ذاكرة عاملة: سعة 5 عناصر وتخبو خلال دقائق، وتحلّ «هو/هي/هناك» ---- */
const wmAct=x=>x.a*Math.exp(-(Date.now()-x.t)/(4*6e4));
function wmAdd(k,v,a){if(!v)return;const it=WM.find(x=>x.k===k&&x.v===v),now=Date.now();if(it){it.a=Math.min(1,Math.max(wmAct(it),a)+.1);it.t=now}else{WM.push({k,v,a,t:now});if(WM.length>5){WM.sort((x,y)=>wmAct(y)-wmAct(x));WM.length=5}}}
function wmTop(kinds){let b=null,bs=.25;for(const x of WM){if(kinds&&!kinds.includes(x.k))continue;const a=wmAct(x);if(a>bs){bs=a;b=x}}return b}
function wmNote(q){for(const n of Object.keys(M.people).concat(Object.keys(M.bd).filter(k=>k!=='__me')))if(n&&q.includes(nz(n)))wmAdd('p',n,1);
 for(const pl of M.places)if(pl.n&&q.includes(nz(pl.n)))wmAdd('l',pl.n,.9);
 for(const w in OBJB)if(new RegExp('(^|\\s)(?:ال)?'+w+'(\\s|$)').test(q))wmAdd('o',w,.9);
 for(const n in M.things)if(q.includes(nz(n)))wmAdd('o',n,.9)}
const WMR=[[/(متي|كم مره)\s+(رايت)(?:ه|ها)(?=\s|$)/,null,(m,e)=>m[1]+' رايت '+e],[/(ماذا|متي)\s+(فعلنا|حدث|كنا)\s+(?:معه|معها|هناك|فيه|فيها)/,null,(m,e)=>m[1]+' '+m[2]+' مع '+e],[/(احكي لي|ماذا تذكرين|ماذا تعرفين)\s+(?:عنه|عنها)/,null,(m,e)=>m[1]+' عن '+e],[/اين\s+(?:هو|هي)(?=\s|$)/,['o'],(m,e)=>'اين '+e],[/وماذا\s+(?:عنه|عنها)/,null,(m,e)=>'ماذا تذكرين عن '+e]];
function wmRewrite(raw){const q=nz(raw);for(const[re,kinds,f]of WMR){const m=q.match(re);if(!m)continue;const top=wmTop(kinds);
  if(!top){say('عمّن أو عمّا تتحدث؟ ذكّرني بالاسم.','curious',null,true);return null}
  const e=top.k==='o'&&OBJB[top.v]?'ال'+top.v:top.v;wmAdd(top.k,top.v,.9);jlog('','أحلت الضمير إلى «'+top.v+'» من ذاكرتي العاملة','wm');return q.replace(re,f(m,e))}return raw}
/* ---- تثبيت الذكريات: دمج وتجريد عادات ونسيان انتقائي (يجري أثناء النوم) ---- */
const hbk=h=>h<6?'n':h<12?'m':h<18?'a':'e',HBN={n:'ليلاً',m:'صباحاً',a:'بعد الظهر',e:'مساءً'};
const retention=(e,n)=>(e.sal||.4)*Math.pow(e.c||1,.3)*Math.exp(-(n-e.t)/(14*864e5));
function epSal(e){const nw=e.w&&!M.ep.some(x=>x.w===e.w),np=e.p&&!M.ep.some(x=>x.p===e.p);return .3+.4*Math.min(1,Math.abs(e.v))+(e.s?.2:0)+(nw||np?.3:0)}
function epPrune(){const n=Date.now();M.ep.sort((a,b)=>retention(b,n)-retention(a,n));M.ep.length=Math.min(M.ep.length,270);M.ep.sort((a,b)=>a.t-b.t)}
function consolidate(){const n=Date.now(),out=[];
 for(const e of M.ep){const p=out[out.length-1];if(p&&p.w===e.w&&p.p===e.p&&p.a===e.a&&p.o.join()===e.o.join()&&e.t-p.t<20*6e4){p.c=(p.c||1)+(e.c||1);p.v=+((p.v+e.v)/2).toFixed(2);p.sal=Math.max(p.sal||0,e.sal||0)}else out.push(e)}M.ep=out;
 const g={};for(const e of M.ep){if(!e.w&&!e.p)continue;const k=(e.w||'')+'|'+(e.p||'')+'|'+hbk(new Date(e.t).getHours()),d=new Date(e.t).toDateString(),r=g[k]||(g[k]={n:0,days:new Set(),v:0});r.n+=e.c||1;r.days.add(d);r.v+=e.v*(e.c||1)}
 for(const k in g){if(g[k].days.size<3)continue;const[w,p,b]=k.split('|'),v=+(g[k].v/g[k].n).toFixed(2),H=M.habits.find(x=>x.w===w&&x.p===p&&x.b===b);if(H){H.n=g[k].n;H.d=g[k].days.size;H.v=v}else M.habits.push({w,p,b,n:g[k].n,d:g[k].days.size,v})}
 if(M.habits.length>40){M.habits.sort((a,b)=>b.d-a.d);M.habits.length=40}
 M.ep=M.ep.filter(e=>retention(e,n)>.04||n-e.t<3*864e5);save()}
function habitText(){if(!M.habits.length)return 'لم أكوّن عادات بعد؛ أحتاج أن أراك عدة أيام في أوقات متقاربة.';
 const H=M.habits.slice().sort((a,b)=>b.d-a.d).slice(0,3).map(h=>(h.w||'أنت')+' '+(h.p?'في «'+h.p+'» ':'')+HBN[h.b]+' ('+h.d+' أيام'+(h.v>.2?'، وعادةً بمزاج جيد':h.v<-.2?'، وعادةً بمزاج سيئ':'')+')');
 const ds=Object.values(M.prof.days);let t='';if(ds.length>=5){const mu=Math.round(ds.reduce((a,b)=>a+b,0)/ds.length);t=' وأول ظهور لك عادةً قرابة الساعة '+Math.floor(mu/60)+':'+String(mu%60).padStart(2,'0')+'.'}return 'ما لاحظته من عاداتنا: '+H.join('؛ ')+'.'+t}
/* ---- إعادة تشغيل التجارب العاطفية أثناء النوم: تمنع نسيان ما تعلمته حين يأتي تعلم جديد متداخل ---- */
function rbPush(T,st){if(!BR.ready||!Array.isArray(RB))return;RB.push({z:Float32Array.from(BR.z),T:T.slice(),st});if(RB.length>200){RB.sort((a,b)=>b.st-a.st);RB.length=150}}
function learnAffZ(z,T,st){let n2=1e-3;for(let i=0;i<NZ;i++)n2+=z[i]*z[i];for(let k=0;k<3;k++){let a=0;const o=k*NZ;for(let i=0;i<NZ;i++)a+=BR.Wa[o+i]*z[i];a=Math.tanh(a);const g=.4*st*(T[k]-a)*(1-a*a+.1)/n2;for(let i=0;i<NZ;i++)BR.Wa[o+i]+=g*z[i]}}
function replay(n){if(!RB.length)return 0;for(let i=0;i<n;i++){const r=RB[Math.floor(Math.random()*RB.length)];learnAffZ(r.z,r.T,r.st*.5)}return n}
/*LIFE6_END*/
