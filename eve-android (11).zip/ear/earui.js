/*EARUI_START*/
/* ===== تعليم الأذن المحلية واختبارها ===== */
M.voice=M.voice||{};var ENR=null,earSt={n:0,ok:0,rej:0,hint:0};
const CMDS=[['ايف','__wake'],['نعم','نعم'],['لا','لا'],['ماذا ترى','ماذا ترى'],['ماذا تفعلين','ماذا تفعلين'],['هل كل شيء يعمل','هل كل شيء يعمل'],['غني لي','غني لي'],['هيا نلعب','هيا نلعب'],['شطرنج','شطرنج'],['إكس أو','اكس او'],['حجر ورقة مقص','حجر ورقة مقص'],['نامي','نامي'],['استيقظي','__wake'],['ما خطتنا اليوم','ما خطتنا اليوم'],['ماذا فعلتِ اليوم','ماذا فعلتي اليوم'],['كيف حالك','كيف حالك'],['مرحبا','مرحبا'],['شكراً','شكرا'],['كم الساعة','كم الساعة'],['ما هي تذكيراتي','ما هي تذكيراتي'],['كيف كان أسبوعي','كيف كان اسبوعي'],['أين الكوب','اين الكوب']];
function earLoad(){EAR.T={};for(const l in M.voice)EAR.T[l]=M.voice[l].map(earUnpack);EAR.thr=Object.keys(EAR.T).length>1?earCal(EAR.T):{}}
function earCmd(txt){lastInteract=Date.now();if(asleep)wake();if(txt==='__wake'){bump('curious',.5);vox('ooh',.15);gaze.ty=0;return}Eve.speech(txt)}
Eve.utt=function(b64){if(!b64)return;let x;try{x=earPcm(b64)}catch(e){return}const f=earFeat(x);
 if(ENR)return ENR.mode==='test'?earTestStep(f):earEnrollStep(f);
 if(!f){earSt.rej++;return}if(Object.keys(EAR.T).length<2){if(Date.now()-earSt.hint>6e4){earSt.hint=Date.now();say('أذني المحلية لم تتعلم عباراتك بعد. قل «تعليم الأذن» أو اضغط الزر في الإعدادات.','curious',null,true)}return}
 const R=earRecog(f,EAR.T,EAR.thr);earSt.n++;if(!R.ok){earSt.rej++;DIAG.earRej=earSt.rej;return}
 earSt.ok++;if(earLearn(EAR.T,EAR.thr,R.label,f,R.d)){M.voice[R.label].push(earPack(f));EAR.thr=earCal(EAR.T);save()}
 const c=CMDS.find(c=>c[0]===R.label);if(c)earCmd(c[1])};
function earEnrollStart(){ENR={mode:'enroll',list:CMDS.map(c=>c[0]),i:0,rep:0,tmp:[]};if(NAT)nCall('sttEngine','local');M.cfg.stt='local';
 say('سنعلّم أذني صوتك. سأذكر عبارة وتكررها ثلاث مرات بصوت واضح بعد كل طلب. اضغط الشاشة لتخطي عبارة. العبارة الأولى: «'+ENR.list[0]+'»','curious',null,true)}
function earEnrollStep(f){const E_=ENR;if(!f){say('لم أسمعك جيداً، أعد العبارة من فضلك.','confused',null,true);return}E_.tmp.push(f);E_.rep++;
 if(E_.rep<3){say('مرة أخرى.','curious',null,true);return}
 M.voice[E_.list[E_.i]]=E_.tmp.map(earPack);E_.i++;E_.rep=0;E_.tmp=[];earNext()}
function earNext(){const E_=ENR;if(E_.i>=E_.list.length){ENR=null;earLoad();save();say('انتهينا! تعلمت '+Object.keys(M.voice).length+' عبارة بصوتك. قل «اختبار الأذن» لأقيس دقتها.','proud',null,true);return}say('جيد. العبارة التالية: «'+E_.list[E_.i]+'»','curious',null,true)}
function earSkip(){if(!ENR)return;if(ENR.mode==='test'){ENR.i++;earTestNext();return}ENR.i++;ENR.rep=0;ENR.tmp=[];earNext()}
function earTestStart(){const labs=Object.keys(M.voice);if(labs.length<2){say('أذني لم تتعلم بعد. قل «تعليم الأذن» أولاً.','curious',null,true);return}
 ENR={mode:'test',list:labs,i:0,hit:0,tot:0,bad:[]};say('سأختبر أذني: قل كل عبارة مرة واحدة. العبارة الأولى: «'+labs[0]+'»','curious',null,true)}
function earTestStep(f){const E_=ENR,want=E_.list[E_.i];E_.tot++;if(!f){E_.bad.push(want+' (لم أسمع)')}else{const R=earRecog(f,EAR.T,EAR.thr);if(R.ok&&R.label===want)E_.hit++;else E_.bad.push(want+(R.ok?' ← فهمتُها «'+R.label+'»':' (رفضتُها)'))}E_.i++;earTestNext()}
function earTestNext(){const E_=ENR;if(E_.i>=E_.list.length){const p=E_.tot?Math.round(100*E_.hit/E_.tot):0;ENR=null;say('دقة أذني المحلية على صوتك: '+p+'٪ ('+E_.hit+' من '+E_.tot+').'+(E_.bad.length?' أخطأت في: '+E_.bad.slice(0,4).join('، ')+'. يمكنك إعادة تعليم العبارات الضعيفة.':' ممتاز!'),p>=80?'proud':'confused',null,true);return}say('العبارة التالية: «'+E_.list[E_.i]+'»','curious',null,true)}
earLoad();
/*EARUI_END*/
