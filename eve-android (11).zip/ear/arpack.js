/*ARP_START*/
/* ===== الحزمة اللغوية العربية الخفيفة: تصحيح أخطاء أي محرك تعرّف بقاموس إيف الخاص (أوامر، أسماء من ذاكرتها، أشياء، أشهر، أرقام) ===== */
const ARP_CONF={'ت':'ثط','ث':'تس','س':'صث','ص':'س','ز':'ذظ','ذ':'ز','د':'ض','ض':'دظ','ظ':'ضز','ط':'ت','ه':'ةح','ة':'ه','ي':'ى','ى':'ي','ا':'أإآع','ك':'ق','ق':'ك','ح':'خه','خ':'ح','غ':'ع','ع':'غا','ء':'ا'};
const arpCost=(a,b)=>a===b?0:((ARP_CONF[a]&&ARP_CONF[a].includes(b))||(ARP_CONF[b]&&ARP_CONF[b].includes(a)))?.5:1;
function arpDist(a,b){const n=a.length,m=b.length;if(Math.abs(n-m)>1)return 9;const d=Array.from({length:n+1},()=>new Float32Array(m+1));for(let i=0;i<=n;i++)d[i][0]=i;for(let j=0;j<=m;j++)d[0][j]=j;
 for(let i=1;i<=n;i++)for(let j=1;j<=m;j++){d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+arpCost(a[i-1],b[j-1]));if(i>1&&j>1&&a[i-1]===b[j-2]&&a[i-2]===b[j-1])d[i][j]=Math.min(d[i][j],d[i-2][j-2]+.7)}return d[n][m]}
const ARP_BASE='ذكرني ساعديني اختار خطتي خطتنا اليوم امس ماذا لماذا متي كيف اين الساعه دقائق دقيقه ساعات ساعه ايف مرحبا شكرا اصمتي نامي استيقظي توقفي غني نلعب شطرنج عيد ميلاد تذكيرات ترين تفعلين فعلتي تشعرين بعد نصف ربع اسبوع اسبوعين خلال حجر ورقه مقص تعلمي اذنك'.split(' ');
function arpLex(){const L=new Set(),add=s=>String(s||'').split(/\s+/).forEach(w=>{w=nz(w);if(w.length>=3)L.add(w)});
 CMDS.forEach(c=>add(c[1]));Object.keys(OBJB).forEach(add);MONTHS.forEach(m=>m.forEach(add));Object.keys(NUMW).forEach(add);ARP_BASE.forEach(add);
 Object.keys(M.people).forEach(add);Object.keys(M.bd).forEach(add);M.places.forEach(p=>add(p.n));Object.keys(M.things).forEach(add);return L}
function arPack(t){if(!t)return t;const toks=nz(t).split(/\s+/),known=new Set([...(ELM.ready?ELM.vocab:[]),...Object.keys(M.words).filter(w=>M.words[w]>=2)]),lex=arpLex();let ch=0;
 const out=toks.map(w=>{if(w.length<3||lex.has(w)||known.has(w)||/\d/.test(w))return w;let best=null,bc=9;for(const c of lex){const d=arpDist(w,c);if(d<bc||(d===bc&&best&&c<best)){bc=d;best=c}}
  const lim=w.length<=4?.5:w.length<=6?1:1.5;if(best&&bc<=lim){ch++;return best}return w});return ch?out.join(' '):t}
/*ARP_END*/
