// مولّد كلام مُصطنع لاختبار خط الأذن (ليس كلاماً عربياً حقيقياً): أحرف علة بصيغ، احتكاكيات، أنفية، انفجارية، مع تنويع المتكلم
const SR=16000;let seed=1;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};const gauss=()=>{let u=0;while(!u)u=rnd();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*rnd())};
const VOW=[[800,1200],[500,900],[350,700],[310,2300],[520,1900],[650,1100],[420,1500]];
function res(f,bw){const r=Math.exp(-Math.PI*bw/SR),th=2*Math.PI*f/SR,b1=2*r*Math.cos(th),b2=-r*r,a=1-r;return{a,b1,b2}}
function seg(t,p,len,sp){const n=Math.round(len*SR),y=new Float32Array(n);
 if(t==='v'){const [f1,f2]=p.F.map(f=>f*sp.fs),r1=res(f1,90),r2=res(f2,130);let y11=0,y12=0,y21=0,y22=0,ph=0;for(let i=0;i<n;i++){ph+=sp.f0/SR;ph-=Math.floor(ph);const src=(ph*2-1)*.8,o1=r1.a*src+r1.b1*y11+r1.b2*y12;y12=y11;y11=o1;const o2=r2.a*src+r2.b1*y21+r2.b2*y22;y22=y21;y21=o2;const env=Math.min(1,i/200,(n-i)/200);y[i]=(o1+.7*o2)*env}}
 else if(t==='s'){let pv=0;for(let i=0;i<n;i++){const w=gauss();y[i]=(w-pv*.9)*.18*Math.min(1,i/150,(n-i)/150);pv=w}}
 else if(t==='n'){const r1=res(260*sp.fs,60);let y1=0,y2=0,ph=0;for(let i=0;i<n;i++){ph+=sp.f0/SR;ph-=Math.floor(ph);const o=r1.a*(ph*2-1)*.6+r1.b1*y1+r1.b2*y2;y2=y1;y1=o;y[i]=o*.8*Math.min(1,i/200,(n-i)/200)}}
 else if(t==='p'){for(let i=Math.floor(n*.7);i<n;i++)y[i]=gauss()*.25*Math.exp(-(i-n*.7)/60)}
 return y}
function word(spec,sp){const parts=[];for(const[t,vi,len]of spec)parts.push(seg(t,{F:VOW[vi%VOW.length]},len*sp.sp,sp));let tot=0;for(const p of parts)tot+=p.length;const lead=Math.round((.25+rnd()*.35)*SR),tail=Math.round((.3+rnd()*.4)*SR),x=new Float32Array(lead+tot+tail);let o=lead;for(const p of parts){x.set(p,o);o+=p.length}
 if(sp.amb!=null){let pk=0;for(const v of x)pk=Math.max(pk,Math.abs(v));const g=(.15+rnd()*.5)/pk;for(let i=0;i<x.length;i++)x[i]=x[i]*g+gauss()*sp.amb;return x}
 let e=0,c=0;for(let i=lead;i<lead+tot;i++){e+=x[i]*x[i];c++}const rms=Math.sqrt(e/c),nz=rms/Math.pow(10,sp.snr/20);for(let i=0;i<x.length;i++)x[i]+=gauss()*nz;let pk=0;for(const v of x)pk=Math.max(pk,Math.abs(v));const g=(.15+rnd()*.5)/pk;for(let i=0;i<x.length;i++)x[i]*=g;return x}
const spk=(o={})=>({f0:(o.f0||120)+gauss()*7,fs:(o.fs||1)*(1+gauss()*.025),sp:(o.sp||1)*(.88+rnd()*.26),snr:(o.snr||22)-rnd()*7,amb:o.amb!=null?o.amb[0]+rnd()*(o.amb[1]-o.amb[0]):null});
function mkWords(n,sd){const old=seed;seed=sd;const W=[];for(let i=0;i<n;i++){const k=3+Math.floor(rnd()*3),spec=[];for(let j=0;j<k;j++){const t=['v','v','v','s','n','p'][Math.floor(rnd()*6)];spec.push([t,Math.floor(rnd()*7),t==='v'?.12+rnd()*.12:.07+rnd()*.07])}if(!spec.some(s=>s[0]==='v'))spec.push(['v',0,.15]);W.push(spec)}seed=old;return W}
function noiseOnly(){const x=new Float32Array(Math.round(SR*(.8+rnd())));for(let i=0;i<x.length;i++)x[i]=gauss()*(.01+rnd()*.05)*(1+Math.sin(i/8000));return x}
const toB64=x=>{const b=Buffer.alloc(x.length*2);for(let i=0;i<x.length;i++)b.writeInt16LE(Math.max(-32768,Math.min(32767,Math.round(x[i]*32767))),2*i);return b.toString('base64')};
module.exports={word,spk,mkWords,noiseOnly,toB64,rnd,gauss,setSeed:s=>{seed=s}};
