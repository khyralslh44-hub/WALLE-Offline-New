const fs=require('fs');const src=fs.readFileSync('ear.js','utf8');
const E=new Function('btoa','atob',src+';return {earFeat,earDTW,earRecog,EAR}')(s=>Buffer.from(s,'binary').toString('base64'),s=>Buffer.from(s,'base64').toString('binary'));
const S=require('./synth.js');const V=12,words=S.mkWords(V+10,9);
function cal(T,mult,xr){const thr={},labs=Object.keys(T);for(const l of labs){const L=T[l];let intra=0;for(let i=0;i<L.length;i++){let mn=1e9;for(let j=0;j<L.length;j++)if(j!==i)mn=Math.min(mn,E.earDTW(L[i],L[j]));intra=Math.max(intra,mn)}
 let cross=1e9;for(const o of labs)if(o!==l)for(const a of L)for(const b of T[o])cross=Math.min(cross,E.earDTW(a,b));let t=intra*mult+.02;t=Math.min(t,Math.max(intra*1.05+.01,cross*xr));thr[l]={t}}return thr}
function recog(f,T,thr,mg){let best=null,bd=1e9,sd=1e9;for(const l of Object.keys(T)){let d=1e9;for(const t of T[l])d=Math.min(d,E.earDTW(f,t));if(d<bd){sd=bd;bd=d;best=l}else if(d<sd)sd=d}return{ok:bd<=thr[best].t&&sd>=bd*mg,label:best}}
const o={amb:[.002,.008]};
for(const[mult,xr,mg]of[[1.35,.8,1.08],[1.25,.8,1.08],[1.15,.8,1.08],[1.35,.7,1.08],[1.35,.8,1.15],[1.25,.75,1.12],[1.15,.75,1.12]]){let ok=0,wr=0,N=0,fa=0,NU=0;
 for(let rep=0;rep<4;rep++){S.setSeed(1000+rep);const T={};for(let i=0;i<V;i++){T['w'+i]=[];for(let r=0;r<3;r++){const f=E.earFeat(S.word(words[i],S.spk(o)));if(f)T['w'+i].push(f)}}const thr=cal(T,mult,xr);
  for(let i=0;i<V;i++)for(let r=0;r<10;r++){const f=E.earFeat(S.word(words[i],S.spk(o)));N++;if(!f)continue;const R=recog(f,T,thr,mg);if(R.ok){if(R.label==='w'+i)ok++;else wr++}}
  for(let i=V;i<V+10;i++)for(let r=0;r<8;r++){const f=E.earFeat(S.word(words[i],S.spk(o)));NU++;if(!f)continue;if(recog(f,T,thr,mg).ok)fa++}}
 console.log(`مضاعف ${mult} | نسبة العبور ${xr} | هامش ${mg}  →  صحيح ${(100*ok/N).toFixed(0)}% | خطأ ${(100*wr/N).toFixed(1)}% | غريب مقبول ${(100*fa/NU).toFixed(1)}%`)}
