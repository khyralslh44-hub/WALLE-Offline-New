package com.eve.companion

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** استماع مستمر بالتعرّف المحلي (يفضّل الحزمة العربية دون اتصال). لا يرسل شيئاً بنفسه. */
class Speech(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onState: (Boolean) -> Unit
) {
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var on = false
    private var backoff = 700L
    private var lastLevel = 0L

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onState(false); return }
        on = true; create()
    }

    fun stop() { on = false; h.removeCallbacksAndMessages(null); rec?.destroy(); rec = null }

    private fun create() {
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(ctx).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) onText(t)
                    backoff = 700; onState(true); again(250)
                }
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) { again(250); return }
                    if (e == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || e == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE) onState(false)
                    backoff = minOf(backoff * 2, 30000L); again(backoff, true)
                }
                override fun onRmsChanged(rms: Float) {
                    val n = System.currentTimeMillis()
                    if (n - lastLevel > 120) { lastLevel = n; onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        listen()
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        try { rec?.startListening(i) } catch (e: Exception) { again(2000, true) }
    }

    private fun again(d: Long, recreate: Boolean = false) {
        h.postDelayed({ if (on) { if (recreate) create() else listen() } }, d)
    }
}
