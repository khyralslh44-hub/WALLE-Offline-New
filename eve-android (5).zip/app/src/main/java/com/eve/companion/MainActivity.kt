package com.eve.companion

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    @Volatile private var speaking = false
    private var vision: Vision? = null
    private var speech: Speech? = null
    private val base = BtBase { l -> onBaseLine(l) }
    private val memFile by lazy { File(filesDir, "mem.json") }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startSenses() }
    private val btPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) base.connect() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        tts = TextToSpeech(this, this)
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(Bridge(), "Android")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/eve.html")
    }

    inner class Bridge {
        @JavascriptInterface fun speak(t: String, pitch: Float, rate: Float) {
            if (!ttsReady) return
            tts?.apply { stop(); setPitch(pitch); setSpeechRate(rate); speak(t, TextToSpeech.QUEUE_FLUSH, null, "eve") }
        }
        @JavascriptInterface fun ttsOk(): Boolean = ttsReady
        @JavascriptInterface fun setMode(m: String) { vision?.mode = m }
        @JavascriptInterface fun loadMem(): String = try { if (memFile.exists()) memFile.readText() else "" } catch (e: Exception) { "" }
        @JavascriptInterface fun saveMem(s: String) {
            try { val tmp = File(filesDir, "mem.tmp"); tmp.writeText(s); tmp.renameTo(memFile) } catch (e: Exception) { }
        }
        @JavascriptInterface fun baseSend(c: String) { base.send(c) }
        @JavascriptInterface fun baseConnect() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 31 && !has(Manifest.permission.BLUETOOTH_CONNECT)) btPerm.launch(Manifest.permission.BLUETOOTH_CONNECT)
                else base.connect()
            }
        }
    }

    private fun onBaseLine(l: String) {
        val p = l.split(":"); if (p.size < 2) return
        val v = p[1].toIntOrNull() ?: return
        when (p[0]) { "D" -> js("Eve.base({d:$v})"); "C" -> js("Eve.base({c:$v})") }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts?.setLanguage(Locale("ar"))
        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true; js("Eve.speaking(true)") }
            override fun onDone(id: String?) { speaking = false; js("Eve.speaking(false)") }
            override fun onError(id: String?) { speaking = false; js("Eve.speaking(false)") }
        })
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun js(c: String) { runOnUiThread { web.evaluateJavascript("window.Eve&&$c", null) } }

    private fun startSenses() {
        if (has(Manifest.permission.CAMERA) && vision == null)
            vision = Vision(this) { json -> js("Eve.vision($json)") }.also { it.start() }
        if (has(Manifest.permission.RECORD_AUDIO) && speech == null)
            speech = Speech(this,
                { t -> if (!speaking) js("Eve.speech(${JSONObject.quote(t)})") },
                { l -> js("Eve.rms($l)") },
                { ok -> js("Eve.stt($ok)") }).also { it.start() }
    }

    override fun onResume() {
        super.onResume(); web.onResume()
        if (!has(Manifest.permission.CAMERA) || !has(Manifest.permission.RECORD_AUDIO))
            perms.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        else startSenses()
    }

    override fun onPause() {
        base.close()
        vision?.stop(); vision = null
        speech?.stop(); speech = null
        web.onPause(); super.onPause()
    }

    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
