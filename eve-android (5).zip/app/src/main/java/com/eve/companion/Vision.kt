package com.eve.companion

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.imageclassifier.ImageClassifier
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

/**
 * الإدراك على الهاتف: كشف أشياء، وجه مع تعابير، إيماءات، وبصمات صور للتعلّم المحلي.
 * الصورة تُعالَج في الذاكرة فقط ولا تُحفظ ولا تُرسل. mode: "active" أو "idle" لتوفير الطاقة.
 */
class Vision(private val act: ComponentActivity, private val emit: (String) -> Unit) : ImageAnalysis.Analyzer {
    @Volatile var mode = "active"
    private val exec = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var det: ObjectDetector? = null
    private var face: FaceLandmarker? = null
    private var gest: GestureRecognizer? = null
    private var emb: ImageEmbedder? = null
    private var cls: ImageClassifier? = null
    private var tCls = 0L
    private var tFace = 0L; private var tObj = 0L; private var tGest = 0L
    private var tEF = 0L; private var tEO = 0L; private var tES = 0L
    private var prev: FloatArray? = null

    private fun base(p: String) = BaseOptions.builder().setModelAssetPath(p).build()

    private fun load() {
        try { det = ObjectDetector.createFromOptions(act, ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(base("models/objects.tflite")).setRunningMode(RunningMode.IMAGE).setMaxResults(5).setScoreThreshold(0.3f).build()) } catch (e: Exception) { }
        try { face = FaceLandmarker.createFromOptions(act, FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(base("models/face.task")).setRunningMode(RunningMode.IMAGE).setNumFaces(1).setOutputFaceBlendshapes(true).build()) } catch (e: Exception) { }
        try { gest = GestureRecognizer.createFromOptions(act, GestureRecognizer.GestureRecognizerOptions.builder()
            .setBaseOptions(base("models/gesture.task")).setRunningMode(RunningMode.IMAGE).setNumHands(1).build()) } catch (e: Exception) { }
        try { cls = ImageClassifier.createFromOptions(act, ImageClassifier.ImageClassifierOptions.builder()
            .setBaseOptions(base("models/classify.tflite")).setRunningMode(RunningMode.IMAGE).setMaxResults(4).setScoreThreshold(0.15f).build()) } catch (e: Exception) { }
        try { emb = ImageEmbedder.createFromOptions(act, ImageEmbedder.ImageEmbedderOptions.builder()
            .setBaseOptions(base("models/embed.tflite")).setRunningMode(RunningMode.IMAGE).setL2Normalize(true).build()) } catch (e: Exception) { }
    }

    fun start() {
        exec.execute {
            load()
            act.runOnUiThread {
                val f = ProcessCameraProvider.getInstance(act)
                f.addListener({
                    provider = f.get()
                    val ia = ImageAnalysis.Builder().setTargetResolution(Size(480, 360))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
                    ia.setAnalyzer(exec, this)
                    try { provider?.unbindAll(); provider?.bindToLifecycle(act, CameraSelector.DEFAULT_FRONT_CAMERA, ia) } catch (e: Exception) { }
                }, ContextCompat.getMainExecutor(act))
            }
        }
    }

    fun stop() {
        try { provider?.unbindAll() } catch (e: Exception) { }
        exec.execute { det?.close(); face?.close(); gest?.close(); emb?.close(); cls?.close() }
        exec.shutdown()
    }

    override fun analyze(img: ImageProxy) {
        try {
            val now = System.currentTimeMillis(); val active = mode != "idle"
            if (now - tFace < (if (active) 160 else 700)) return
            tFace = now
            val raw = img.toBitmap()
            val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()); postScale(-1f, 1f) }
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            val o = JSONObject(); val e = JSONObject()
            lum(bmp, o)
            val mp = BitmapImageBuilder(bmp).build()
            var fb: FloatArray? = null
            face?.detect(mp)?.let { r ->
                if (r.faceLandmarks().isNotEmpty()) {
                    var x0 = 1f; var y0 = 1f; var x1 = 0f; var y1 = 0f
                    for (p in r.faceLandmarks()[0]) { x0 = min(x0, p.x()); y0 = min(y0, p.y()); x1 = maxOf(x1, p.x()); y1 = maxOf(y1, p.y()) }
                    fb = floatArrayOf(x0, y0, x1 - x0, y1 - y0)
                    val bs = HashMap<String, Float>()
                    r.faceBlendshapes().ifPresent { l -> if (l.isNotEmpty()) for (c in l[0]) bs[c.categoryName()] = c.score() }
                    fun a(vararg k: String) = k.map { bs[it] ?: 0f }.average()
                    o.put("face", JSONObject().put("b", JSONArray(fb!!.map { it.toDouble() }))
                        .put("smile", a("mouthSmileLeft", "mouthSmileRight")).put("jaw", a("jawOpen"))
                        .put("frown", a("mouthFrownLeft", "mouthFrownRight")).put("brow", a("browDownLeft", "browDownRight"))
                        .put("wide", a("eyeWideLeft", "eyeWideRight")).put("blink", a("eyeBlinkLeft", "eyeBlinkRight")))
                }
            }
            if (active && now - tGest > (if (mode == "rps") 150 else 550)) {
                tGest = now
                gest?.recognize(mp)?.let { r ->
                    val g = r.gestures()
                    if (g.isNotEmpty() && g[0].isNotEmpty())
                        o.put("gest", JSONObject().put("n", g[0][0].categoryName()).put("s", g[0][0].score().toDouble()))
                }
            }
            var topObj: FloatArray? = null; var topLabel = ""
            if (now - tObj > (if (active) 900 else 3000)) {
                tObj = now
                det?.detect(mp)?.let { r ->
                    val arr = JSONArray(); val w = bmp.width.toFloat(); val h = bmp.height.toFloat()
                    for (d in r.detections()) {
                        val c = d.categories()[0]; val b = d.boundingBox()
                        val nb = floatArrayOf(b.left / w, b.top / h, b.width() / w, b.height() / h)
                        arr.put(JSONObject().put("l", c.categoryName()).put("s", c.score().toDouble()).put("b", JSONArray(nb.map { it.toDouble() })))
                        if (topObj == null && c.categoryName() != "person") { topObj = nb; topLabel = c.categoryName() }
                    }
                    o.put("objs", arr)
                }
            }
            if (active && mode != "rps" && now - tCls > 2500) {
                tCls = now
                cls?.classify(mp)?.let { r ->
                    val cs = r.classificationResult().classifications()
                    if (cs.isNotEmpty()) {
                        val a = JSONArray()
                        for (c in cs[0].categories()) a.put(JSONObject().put("l", c.categoryName()).put("s", c.score().toDouble()))
                        o.put("cls", a)
                    }
                }
            }
            if (active && mode != "rps") {
                fb?.let { if (now - tEF > 1200) { tEF = now; crop(bmp, it, 0.25f)?.let { c -> embed(c)?.let { v -> e.put("face", v) } } } }
                topObj?.let { if (now - tEO > 2500) { tEO = now; crop(bmp, it, 0.1f)?.let { c -> embed(c)?.let { v -> e.put("obj", v).put("ol", topLabel) } } } }
                if (now - tES > 4000) { tES = now; embed(bmp)?.let { v -> e.put("scene", v) } }
            }
            if (e.length() > 0) o.put("emb", e)
            emit(o.toString())
        } catch (ex: Exception) {
        } finally { img.close() }
    }

    private fun lum(b: Bitmap, o: JSONObject) {
        val s = Bitmap.createScaledBitmap(b, 4, 3, true); val px = IntArray(12)
        s.getPixels(px, 0, 4, 0, 0, 4, 3)
        val l = FloatArray(12) { (0.3f * Color.red(px[it]) + 0.59f * Color.green(px[it]) + 0.11f * Color.blue(px[it])) / 255f }
        var mo = 0f; prev?.let { p -> for (i in 0 until 12) mo += abs(l[i] - p[i]); mo = min(1f, mo / 12f * 4f) }
        prev = l
        o.put("lum", JSONArray(l.map { it.toDouble() })).put("bright", l.average()).put("mo", mo.toDouble())
    }

    private fun crop(b: Bitmap, r: FloatArray, pad: Float): Bitmap? {
        val l = ((r[0] - r[2] * pad) * b.width).toInt().coerceIn(0, b.width - 2)
        val t = ((r[1] - r[3] * pad) * b.height).toInt().coerceIn(0, b.height - 2)
        val w = (r[2] * (1 + 2 * pad) * b.width).toInt().coerceIn(2, b.width - l)
        val h = (r[3] * (1 + 2 * pad) * b.height).toInt().coerceIn(2, b.height - t)
        return try { Bitmap.createBitmap(b, l, t, w, h) } catch (e: Exception) { null }
    }

    private fun embed(b: Bitmap): JSONArray? {
        val v = emb?.embed(BitmapImageBuilder(b).build())?.embeddingResult()?.embeddings()?.firstOrNull()?.floatEmbedding() ?: return null
        val a = JSONArray(); for (x in v) a.put(Math.round(x * 1000) / 1000.0); return a
    }
}
