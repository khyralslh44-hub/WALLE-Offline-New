package com.eve.companion

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService
import kotlin.math.max
import kotlin.math.sqrt

/**
 * أذن مدمجة بالكامل: نموذج عربي داخل التطبيق (Vosk) يعمل بلا إنترنت وبلا نغمات.
 * نلتقط الصوت بأنفسنا مع ذاكرة سابقة 400 مللي ثانية فلا تضيع أول كلمة، ولا نشغّل المحرك إلا أثناء الكلام لتوفير الطاقة.
 */
class VoskSpeech(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onState: (Boolean) -> Unit,
    private val isBusy: () -> Boolean,
    private val diag: (String) -> Unit,
    private val onFail: () -> Unit
) : Ear {
    @Volatile private var on = false
    private var model: Model? = null

    override fun start() {
        on = true
        diag("{\"stt\":\"VOSK_LOADING\"}")
        StorageService.unpack(ctx, "vosk/model", "vosk-model",
            { m -> model = m; if (on) loop() else m.close() },
            { _ -> on = false; onState(false); diag("{\"stt\":\"VOSK_MODEL_ERROR\"}"); onFail() })
    }

    override fun stop() { on = false }

    private fun bytes(f: ShortArray, n: Int): ByteArray {
        val b = ByteArray(n * 2)
        for (i in 0 until n) { b[2 * i] = (f[i].toInt() and 255).toByte(); b[2 * i + 1] = (f[i].toInt() shr 8).toByte() }
        return b
    }

    private fun loop() {
        Thread {
            var ar: AudioRecord? = null
            var rec: Recognizer? = null
            try {
                val sr = 16000
                val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                ar = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 16000))
                if (ar.state != AudioRecord.STATE_INITIALIZED) { onState(false); diag("{\"stt\":\"NO_MIC\"}"); return@Thread }
                rec = Recognizer(model, sr.toFloat())
                ar.startRecording(); onState(true); diag("{\"stt\":\"VOSK\"}")
                val frame = ShortArray(1600)
                val pre = ArrayDeque<ByteArray>()
                var floor = 250.0; var voiced = false; var silence = 0; var frames = 0; var lastLevel = 0L
                while (on) {
                    val n = ar.read(frame, 0, frame.size); if (n <= 0) continue
                    val b = bytes(frame, n)
                    var s = 0.0; for (i in 0 until n) s += frame[i] * frame[i].toDouble()
                    val rms = sqrt(s / n)
                    val t = System.currentTimeMillis()
                    if (t - lastLevel > 120) { lastLevel = t; onLevel((rms / 4000.0).coerceIn(0.0, 1.0).toFloat()) }
                    if (rms < floor * 1.6) floor = floor * 0.97 + rms * 0.03
                    val loud = rms > max(900.0, floor * 3.0) && !isBusy()
                    if (!voiced) {
                        pre.addLast(b); if (pre.size > 4) pre.removeFirst()
                        if (loud) { voiced = true; silence = 0; frames = 0; for (p in pre) rec.acceptWaveForm(p, p.size); pre.clear() }
                    } else {
                        rec.acceptWaveForm(b, b.size); frames++
                        if (loud) silence = 0 else silence++
                        if (silence >= 7 || frames >= 150) {
                            val text = JSONObject(rec.finalResult).optString("text")
                            if (text.isNotBlank()) onText(text)
                            rec.reset(); voiced = false; silence = 0
                        }
                    }
                }
            } catch (e: Exception) {
                diag("{\"stt\":\"VOSK_ERR\"}"); onState(false)
            } finally {
                try { ar?.stop() } catch (e: Exception) { }
                try { ar?.release() } catch (e: Exception) { }
                try { rec?.close() } catch (e: Exception) { }
                try { model?.close() } catch (e: Exception) { }
                model = null
            }
        }.start()
    }
}
