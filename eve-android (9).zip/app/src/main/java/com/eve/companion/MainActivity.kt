package com.eve.companion

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    @Volatile private var speaking = false
    private var vision: Vision? = null
    private var speech: Ear? = null
    private var sttPref = "auto"
    private class Pend(val t: String, val pitch: Float, val rate: Float, val style: String)
    private val pending = ConcurrentHashMap<String, Pend>()
    private var seq = 0
    private var evoiceOn = true
    private val voice by lazy { EveVoice(h) { on -> speaking = on; js("Eve.speaking($on)") } }
    private var camWanted = true
    private var micWanted = true
    private var askedPerms = false
    private val h = Handler(Looper.getMainLooper())
    private val stopRun = Runnable { stopSenses() }
    private val base = BtBase { l -> onBaseLine(l) }
    private val memFile by lazy { File(filesDir, "mem.json") }
    private val bakFile by lazy { File(filesDir, "mem.bak") }
    private var lastBak = 0L
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refreshSenses() }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val btPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) base.connect() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        tts = TextToSpeech(this, this)
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            addJavascriptInterface(Bridge(), "Android")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/eve.html")
    }

    inner class Bridge {
        @JavascriptInterface fun speak(t: String, pitch: Float, rate: Float, style: String) {
            if (!ttsReady) return
            voice.stop()
            if (!evoiceOn) { plain(t, pitch, rate); return }
            val id = "evf" + (++seq); val f = File(cacheDir, "$id.wav")
            pending[id] = Pend(t, pitch, rate, style)
            tts?.apply { stop(); setPitch(1.0f); setSpeechRate((rate / voice.factor(style)).coerceIn(0.4f, 2.0f)) }
            val res = tts?.synthesizeToFile(t, null, f, id)
            if (res != TextToSpeech.SUCCESS) { pending.remove(id); plain(t, pitch, rate) }
            else h.postDelayed({ val p = pending.remove(id); if (p != null) plain(p.t, p.pitch, p.rate) }, 6000)
        }
        @JavascriptInterface fun voiceStyle(on: Boolean) { evoiceOn = on }
        /** محرك الاستماع: auto (المدمج إن وُجد) أو google. */
        @JavascriptInterface fun sttEngine(name: String) { runOnUiThread { sttPref = name; speech?.stop(); speech = null; refreshSenses() } }
        @JavascriptInterface fun sttEmbedded(): Boolean = hasEmbedded()
        @JavascriptInterface fun notifyPerm() {
            runOnUiThread { if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }
        @JavascriptInterface fun notifySchedule(id: String, at: Long, title: String, text: String, yearly: Boolean) { Notifier.schedule(this@MainActivity, id, at, title, text, yearly) }
        @JavascriptInterface fun notifyOk(): Boolean = try { getSystemService(android.app.NotificationManager::class.java).areNotificationsEnabled() } catch (e: Exception) { false }
        @JavascriptInterface fun notifyCancel(id: String) { Notifier.cancel(this@MainActivity, id) }
        @JavascriptInterface fun notifyNow(title: String, text: String) { Notifier.show(this@MainActivity, (System.currentTimeMillis() % 100000).toInt(), title, text) }
        @JavascriptInterface fun ttsOk(): Boolean = ttsReady
        @JavascriptInterface fun setMode(m: String) { vision?.mode = m }
        /** تفضيلات المستخدم: الكاميرا والاستماع (الافتراضي: يعملان تلقائياً). */
        @JavascriptInterface fun senses(cam: Boolean, mic: Boolean) {
            runOnUiThread { camWanted = cam; micWanted = mic; refreshSenses() }
        }
        /** الذاكرة: نقرأ الملف إن كان سليماً، وإلا النسخة الاحتياطية (تُحدَّث كل 10 دقائق من آخر حالة سليمة). */
        @JavascriptInterface fun loadMem(): String {
            fun ok(t: String) = try { JSONObject(t); true } catch (e: Exception) { false }
            return try {
                val a = if (memFile.exists()) memFile.readText() else ""
                if (a.isNotEmpty() && ok(a)) a
                else if (bakFile.exists()) (bakFile.readText().takeIf { ok(it) } ?: "") else ""
            } catch (e: Exception) { "" }
        }
        @JavascriptInterface fun saveMem(s: String) {
            try {
                val now = System.currentTimeMillis()
                if (memFile.exists() && now - lastBak > 600000) { memFile.copyTo(bakFile, true); lastBak = now }
                val tmp = File(filesDir, "mem.tmp"); tmp.writeText(s); tmp.renameTo(memFile)
            } catch (e: Exception) { }
        }
        @JavascriptInterface fun baseSend(c: String) { base.send(c) }
        @JavascriptInterface fun baseConnect() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 31 && !has(Manifest.permission.BLUETOOTH_CONNECT)) btPerm.launch(Manifest.permission.BLUETOOTH_CONNECT)
                else base.connect()
            }
        }
    }

    private fun plain(t: String, pitch: Float, rate: Float) {
        tts?.apply { stop(); setPitch(pitch); setSpeechRate(rate); speak(t, TextToSpeech.QUEUE_FLUSH, null, "eve") }
    }

    private fun synthDone(id: String, failed: Boolean) {
        val p = pending.remove(id) ?: return
        val f = File(cacheDir, "$id.wav")
        if (failed) { plain(p.t, p.pitch, p.rate); return }
        voice.play(f, p.style) { plain(p.t, p.pitch, p.rate) }
    }

    private fun onBaseLine(l: String) {
        val p = l.split(":"); if (p.size < 2) return
        val v = p[1].toIntOrNull() ?: return
        when (p[0]) { "D" -> js("Eve.base({d:$v})"); "C" -> js("Eve.base({c:$v})") }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts?.setLanguage(Locale("ar"))
        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { if (id == "eve") { speaking = true; js("Eve.speaking(true)") } }
            override fun onDone(id: String?) {
                if (id == "eve") { speaking = false; js("Eve.speaking(false)") }
                else if (id != null && id.startsWith("evf")) synthDone(id, false)
            }
            override fun onError(id: String?) {
                if (id == "eve") { speaking = false; js("Eve.speaking(false)") }
                else if (id != null && id.startsWith("evf")) synthDone(id, true)
            }
        })
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun js(c: String) { runOnUiThread { web.evaluateJavascript("window.Eve&&$c", null) } }

    /** يشغّل أو يوقف كل حاسة بحسب التفضيل والإذن؛ آمن للاستدعاء المتكرر (لا يعيد التشغيل إن كانت تعمل). */
    private fun refreshSenses() {
        val needCam = camWanted && !has(Manifest.permission.CAMERA)
        val needMic = micWanted && !has(Manifest.permission.RECORD_AUDIO)
        if ((needCam || needMic) && !askedPerms) {
            askedPerms = true
            perms.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
        if (camWanted && has(Manifest.permission.CAMERA)) {
            if (vision == null) vision = Vision(this, { j -> js("Eve.vision($j)") }, { d -> js("Eve.diag($d)") }).also { it.start() }
        } else if (vision != null) { vision?.stop(); vision = null }
        if (micWanted && has(Manifest.permission.RECORD_AUDIO)) {
            if (speech == null) {
                val onT: (String) -> Unit = { t -> if (!speaking) js("Eve.speech(${JSONObject.quote(t)})") }
                val onL: (Float) -> Unit = { l -> js("Eve.rms($l)") }
                val onS: (Boolean) -> Unit = { ok -> js("Eve.stt($ok)") }
                val onD: (String) -> Unit = { d -> js("Eve.diag($d)") }
                speech = if (hasEmbedded() && sttPref != "google")
                    VoskSpeech(this, onT, onL, onS, { speaking }, onD) { runOnUiThread { sttPref = "google"; speech = null; refreshSenses() } }
                else Speech(this, onT, onL, onS, { speaking }, onD)
                speech?.start()
            }
        } else if (speech != null) { speech?.stop(); speech = null }
    }

    private fun hasEmbedded(): Boolean = try { (assets.list("vosk/model")?.size ?: 0) > 0 } catch (e: Exception) { false }

    private fun stopSenses() {
        vision?.stop(); vision = null
        speech?.stop(); speech = null
        base.close()
    }

    // الحواس تبقى تعمل أثناء التوقفات العابرة (إشعار، نافذة…). لا نوقفها إلا إن غاب التطبيق أكثر من 20 ثانية.
    // CameraX نفسه يغلق الكاميرا ويفتحها تلقائياً مع دورة حياة الشاشة، فلا حاجة لإعادة بناء أي شيء.
    override fun onStart() { super.onStart(); h.removeCallbacks(stopRun); refreshSenses() }
    override fun onStop() { h.postDelayed(stopRun, 20000); super.onStop() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onDestroy() { h.removeCallbacks(stopRun); voice.stop(); stopSenses(); tts?.shutdown(); super.onDestroy() }
}
