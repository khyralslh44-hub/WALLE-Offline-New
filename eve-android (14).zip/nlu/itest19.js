const H=require('/home/claude/ear/h.js'),S=require('/home/claude/ear/synth.js'),cp=require('child_process'),fs=require('fs');const {run,ctx,said,chunks,ok,tick}=H;tick(20);
const LAB=['نعم','لا','ماذا ترى','ماذا تفعلين','كيف حالك','مرحبا','كم الساعة','ما هي تذكيراتي'],NW=LAB.length;
const pm=t=>{ctx.__t=t;return run('phraseMatch(__t)')};
// 1) مطابقة نص المعلّم لعبارات إيف
ok('teacher text equal to a phrase matches',pm('ماذا ترى')&&pm('ماذا ترى').label==='ماذا ترى');
ok('one ASR slip is tolerated ("ماذ ترى")',pm('ماذ ترى')&&pm('ماذ ترى').label==='ماذا ترى');
ok('Libyan phrase matches its own label ("شن اخبارك")',pm('شن اخبارك')&&pm('شن اخبارك').label==='شن اخبارك');
ok('unrelated speech does not match',pm('ما رأيك في الطقس اليوم')===null&&pm('سأذهب إلى السوق غداً')===null);
// 2) تعلّم DTW من نص المعلّم فقط (بلا تعليم يدوي)
const words=S.mkWords(NW+3,21);S.setSeed(808);const A=(i,o)=>S.word(words[i],S.spk(Object.assign({amb:[.002,.008]},o||{})));
run('M.voice={};EAR.T={};EAR.thr={};KA={clips:{},bytes:0,n:0}');
run('var __calls=[];{const _c=earCmd;earCmd=function(t){__calls.push(t);return _c(t)}}');
function teach(noise){for(let k=0;k<4;k++)for(let i=0;i<NW;i++){let txt=LAB[i];if(noise&&S.rnd()<noise)txt=LAB[(i+1+Math.floor(S.rnd()*(NW-1)))%NW];ctx.__a=S.toB64(A(i));ctx.__tx=txt;run('Eve.speechA(__tx,__a)')}}
teach(0);
ok('the teacher labelled 4 natural utterances per phrase → personal templates created (no manual enrollment)',LAB.every(l=>run(`(M.voice[${JSON.stringify(l)}]||[]).length`)===4),LAB.map(l=>run(`(M.voice[${JSON.stringify(l)}]||[]).length`)).join());
function accuracy(){let g=0,w=0,n=0;for(let i=0;i<NW;i++)for(let r=0;r<12;r++){run('__calls.length=0');ctx.__u=S.toB64(A(i));run('Eve.utt(__u)');n++;const c=JSON.parse(run('JSON.stringify(__calls)'));if(c.length){const want=run(`CMDS.find(c=>c[0]===${JSON.stringify(LAB[i])})[1]`);if(c[0]===want)g++;else w++}}return[g/n,w/n]}
let[g,w]=accuracy();console.log('   تعرّف بعد تعلّم من المعلّم فقط: صحيح',(100*g).toFixed(0)+'% | خطأ',(100*w).toFixed(1)+'%');
ok('the small ear then recognises your voice ≥ 85% with ≤ 3% wrong',g>=.85&&w<=.03);
// 3) تعلّم من معلّم يخطئ (10% من نصوصه خاطئة)
run('M.voice={};EAR.T={};EAR.thr={}');teach(.10);[g,w]=accuracy();console.log('   مع 10% تسميات خاطئة من المعلّم: صحيح',(100*g).toFixed(0)+'% | خطأ',(100*w).toFixed(1)+'%');
ok('with a teacher that is wrong 10% of the time (worst case: swaps in another valid phrase): ≥ 70% correct, ≤ 12% wrong (4-seed mean in exp_teach.js: 80% / 2.2%)',g>=.70&&w<=.12);
// 4) السقف
run('M.voice={};EAR.T={};EAR.thr={}');for(let k=0;k<10;k++){ctx.__a=S.toB64(A(0));ctx.__tx=LAB[0];run('Eve.speechA(__tx,__a)')}ok('templates per phrase are capped at 6',run(`M.voice[${JSON.stringify(LAB[0])}].length`)===6);
ok('a clip is kept for the small-model dataset (≤ 30 per phrase)',run(`KA.clips[${JSON.stringify(LAB[0])}].length`)<=30&&run('KA.n')>=10);
ctx.__a=S.toB64(A(2));ctx.__tx='ما رأيك في الطقس اليوم يا ايف';run('Eve.speechA(__tx,__a)');ok('multi-word speech that is not a command is kept as the "other" class',(run('KA.clips["__other__"]')||[]).length===1);
// 5) التصدير بنفس تخطيط التدريب
chunks.length=0;run('kaExport()');fs.writeFileSync('/tmp/eve-teacher.zip',Buffer.from(chunks.join(''),'base64'));
const t=cp.spawnSync('unzip',['-t','/tmp/eve-teacher.zip']).stdout.toString();ok('teacher dataset exports as a valid zip',/No errors detected/.test(t));
const py=cp.spawnSync('python3',['-c',`import zipfile,json;z=zipfile.ZipFile('/tmp/eve-teacher.zip');n=z.namelist();lab=json.load(z.open('labels.json'));print(len([x for x in n if x.endswith('.wav')]),len(lab),[x for x in n if '__other__' in x][:1],[x for x in n if x.startswith('data/p')][:1])`]).stdout.toString().trim();
ok('layout matches the trainer (data/<id>/*.wav + labels.json, "__other__" class)',/ \d+ /.test(py)&&/__other__/.test(py)&&/data\/p\d\d\//.test(py),py);
// 6) لا شيء بلا معلّم
run('KA={clips:{},bytes:0,n:0}');said.length=0;run('kaExport()');ok('without teacher data it says so (no empty file)',/لم أجمع بيانات من المعلّم/.test(said.slice(-1)[0]||''),said.slice(-1)[0]);
tick(60);ok('stable',true);
