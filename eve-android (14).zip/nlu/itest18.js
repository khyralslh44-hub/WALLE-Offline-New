const H=require('/home/claude/ear/h.js'),fs=require('fs');const {run,ctx,said,ok,tick}=H;const last=()=>said.slice(-1)[0];tick(20);
const T=JSON.parse(fs.readFileSync('/home/claude/nlu/nlu_tests.json','utf8')),D=require('/home/claude/nlu/nlu_data.js');
const ask=u=>{ctx.__u=u;run('understand(__u)');return last()};
const reset=()=>run("DLG=null;ASK=null;WM=[];lastUnknown=null;confusedN=0;NLU.busy=false;asleep=false");
run("M.people={'سالم':'x','سارة':'x','زياد':'x'};M.ep=[];hadPresent=true");
run("{const n=Date.now();for(let i=0;i<3;i++)M.ep.push({t:n-i*6e4,p:'المطبخ',w:'سالم',o:[],a:'',m:'joy',v:.5,s:'',sal:.6,c:1})}");
ok('the small intent model is embedded in the page and loaded',run('!!NLU.m&&NLU.m.K')===38&&run('NLU.m.tau')>0);
// 1) نية صريحة بثقة عالية تُنفَّذ مباشرة (نبحث عن عبارة اختبار لا تفهمها القواعد وتوجَّه مباشرة)
let DIR=null;for(const x of T){if(x.id==='__other__')continue;reset();run('JR.length=0');ctx.__u=x.text;run('understand(__u)');if(run('JR.some(j=>j.k==="nlu")')){DIR=x;break}}
ok('a held-out phrase the rules cannot parse is routed and executed directly by the small model',!!DIR,DIR&&DIR.text);
// 2) ثقة متوسطة: تسأل ثم تتعلم من «نعم»
const D2=[];for(const t of T){if(t.id==='__other__')continue;reset();ctx.__u=t.text;run('understand(__u)');if(run('ASK&&ASK.k==="nlu"?1:0')){D2.push({t:t.text,canon:run('ASK.canon'),id:t.id})}}
ok('medium-confidence phrases trigger a confirmation question ('+D2.length+' of the test phrases)',D2.length>10);
reset();const P=D2.find(d=>d.id==='health')||D2[0];r=ask(P.t);ok('asks "do you mean …?" instead of guessing',/^هل تقصد: «/.test(r),P.t+' → '+r);
const q0=run('nz(dialNorm(__u))');const p0=run('(()=>{const p=nluProbs(nz(dialNorm(__u)));return Math.max(...p)})()');
ctx.__keep=P.t;r=ask('نعم');ctx.__u=ctx.__keep;ok('"yes" executes the intended command and stores a training example',run('M.nluEx&&M.nluEx.length')===1&&!/ماذا يعني/.test(r),r);
const p1=run('(()=>{const p=nluProbs(nz(dialNorm(__u)));return Math.max(...p)})()');ok('the model learned from your confirmation (confidence ↑ '+p0.toFixed(2)+' → '+p1.toFixed(2)+')',p1>p0+.02);
reset();ctx.__u=P.t;run('understand(__u)');ok('next time the same phrase is executed directly (no question)',!run('ASK&&ASK.k==="nlu"')&&run('JR.slice(-3).some(j=>j.k==="nlu")'));
// 3) الاستمرار بعد إعادة التشغيل: نعيد تحميل الأوزان الأصلية ثم نعيد تشغيل الأمثلة المحفوظة
run("nluLoad(JSON.parse(document.getElementById('nlu0').textContent))");const pf=run('Math.max(...nluProbs(nz(dialNorm(__u))))');run('nluReplay()');const pr=run('Math.max(...nluProbs(nz(dialNorm(__u))))');
ok('learning survives restart (fresh weights ‘'+pf.toFixed(2)+'’ → replay ‘'+pr.toFixed(2)+'’)',pr>pf+.02);
// 4) نيات ذات أثر (نوم) تُسأل دائماً
reset();r=ask('اذهبي لترتاحي');ok('risky intent (sleep) is ALWAYS confirmed first',/^هل تقصد: «نامي»؟/.test(r)&&!run('asleep'),r);
r=ask('لا');ok('"no" → she does not act and asks what you meant',/ماذا تقصد إذن/.test(r)&&!run('asleep'),r);
reset();ask('اذهبي لترتاحي');ask('نعم');ok('"yes" → she goes to sleep',run('asleep')===true||/ارتاح|نوم|سأنام|حلم/.test(last()),last());run('asleep=false');
// 5) نيات بمُدخل (شخص/شيء)
reset();r=ask('هل رأيتِ سالم اليوم');ok('slot intent: "did you see Salem?" → episodic memory answer',/سجلتُ 3 لقطات|سالم/.test(r),r);
reset();r=ask('هل رأيتِ هذا الشيء');ok('slot intent without a known entity is NOT guessed',!run('ASK&&ASK.k==="nlu"'),r);
// 6) جمل ليست أوامر لا تُوجَّه
let bad=0;for(const n of D.NEG_TEST){reset();ctx.__u=n;run('__ru=0;understand(__u)');if(run('ASK&&ASK.k==="nlu"?1:0')||run('JR.slice(-1).some(j=>j.k==="nlu"&&Date.now()-j.t<50)'))bad++}
ok('ordinary sentences are rarely mistaken for commands (≤ 6% asked, none executed)',bad/D.NEG_TEST.length<=.07,bad+'/'+D.NEG_TEST.length);
// 7) لا تتجاوز القواعد، ولا تتجاوز الأمان
reset();run('JR.length=0');ask('كم الساعة');ok('rules still win when they understand (no routing)',!run('JR.some(j=>j.k==="nlu")'));
reset();r=ask('اريد ان اموت');ok('self-harm talk is handled before any routing',/اتصل/.test(r)&&/شخص تثق به/.test(r));
// 8) تحمّل الأعطال
run('NLU.m=null');reset();r=ask('شن تعملي توا');ok('with the model missing she falls back gracefully (no crash)',typeof r==='string'&&r.length>0,r);
run("nluLoad(JSON.parse(document.getElementById('nlu0').textContent));nluReplay()");
// 9) السرعة
const t0=process.hrtime.bigint();for(let i=0;i<300;i++){ctx.__u=T[i%T.length].text;run('nluDecide(nz(dialNorm(__u)))')}const ms=Number(process.hrtime.bigint()-t0)/1e6/300;ok('inference is fast ('+ms.toFixed(2)+' ms per sentence on this PC)',ms<5);
tick(100);ok('stable',true);
