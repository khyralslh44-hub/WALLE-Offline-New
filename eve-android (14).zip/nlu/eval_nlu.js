// قياس داخل التطبيق: هل تُفهم الصيغة الجديدة؟ (قواعد فقط ← قواعد + المصنّف الصغير)
const H=require('/home/claude/ear/h.js');const {run,ctx,said,tick}=H;const T=JSON.parse(require('fs').readFileSync('nlu_tests.json','utf8')),D=require('./nlu_data.js');
tick(20);const withModel=run('!!NLU.m');
run("M.people={'زياد':'x','مريم':'x','نادر':'x'};M.things={'الشاحن':[[1]],'القلم':[[1]]};M.seenObj={}");
run("var __um=0,__nest=[];{const _a=askMeaning;askMeaning=function(){__um++;return _a.apply(null,arguments)};const _u=understand;understand=function(t){if(NLU.busy)__nest.push(t);return _u.apply(null,arguments)}}");
const canonOf=Object.fromEntries(D.INTENTS.map(i=>[i.id,i]));
const R={pos:0,rules:0,direct_ok:0,ask_ok:0,wrong:0,wrong_direct:0,unknown:0,neg:0,neg_routed:0,neg_direct:0};const wrongs=[],misses=[];
for(const t of T){ctx.__t=t.text;run('DLG=null;ASK=null;WM=[];lastUnknown=null;confusedN=0;__um=0;__nest=[];NLU.busy=false');said.length=0;run('understand(__t)');
 const um=run('__um'),nest=JSON.parse(run('JSON.stringify(__nest)')),ask=run('ASK&&ASK.k==="nlu"?ASK.canon:null');
 if(t.id==='__other__'){R.neg++;if(nest.length||ask)R.neg_routed++;if(nest.length)R.neg_direct++;continue}
 R.pos++;const I=canonOf[t.id],want=I.slot?I.canon.replace('{e}',t.ent):I.canon;
 if(um===0&&!nest.length&&!ask){R.rules++;continue}
 const got=nest[0]||ask;if(got){if(got===want){nest.length?R.direct_ok++:R.ask_ok++}else{R.wrong++;if(nest.length)R.wrong_direct++;wrongs.push([t.text,got,nest.length?'مباشر':'سؤال'])}}else{R.unknown++;misses.push(t.text)}}
const pc=n=>(100*n/R.pos).toFixed(1)+'%';
console.log(withModel?'— مع المصنّف الصغير —':'— قواعد فقط (الأساس) —');
console.log(`جمل نية (صيغ جديدة): ${R.pos} | تُفهم بالقواعد: ${pc(R.rules)} | يوجّهها المصنّف مباشرة وصحيحاً: ${pc(R.direct_ok)} | يسأل «هل تقصد…؟» وصحيح: ${pc(R.ask_ok)} | توجيه خاطئ: ${pc(R.wrong)} (منه ينفَّذ مباشرة: ${pc(R.wrong_direct)}) | تسقط في «ماذا يعني؟»: ${pc(R.unknown)}`);
console.log(`مفهومة فعلاً (قواعد + مصنّف صحيح): ${pc(R.rules+R.direct_ok+R.ask_ok)}`);
console.log(`جمل ليست أوامر (${R.neg}): وُجِّهت خطأً: ${R.neg_routed} (${(100*R.neg_routed/R.neg).toFixed(1)}%) | منها تُنفَّذ مباشرة: ${R.neg_direct}`);
if(process.argv[2]==='v'){console.log('أخطاء التوجيه:',wrongs.slice(0,12));console.log('أمثلة فائتة:',misses.slice(0,25))}
