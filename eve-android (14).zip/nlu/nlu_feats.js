// توليد بيانات التدريب: توسيع الصيغ + استخراج سمات هاشية بنفس كود التطبيق
const H=require('/home/claude/ear/h.js'),D=require('./nlu_data.js'),fs=require('fs');const {run,ctx}=H;
run("function __nf(t){const q=nz(dialNorm(t));const f=nluFeats(q);return JSON.stringify([f.idx,f.val.map(v=>+v.toFixed(5))])}");
let sd=17;const rnd=()=>{sd=(sd*1664525+1013904223)>>>0;return sd/4294967296},pick=a=>a[Math.floor(rnd()*a.length)];
const CONF={'ت':'ث','ث':'ت','س':'ص','ص':'س','ز':'ذ','ذ':'ز','د':'ض','ض':'د','ط':'ت','ه':'ة','ك':'ق','ق':'ك','ح':'خ','خ':'ح','ع':'غ','غ':'ع'};
const PRE=['','','','يا ايف ','ايف ','لو سمحتي ','ممكن ','من فضلك ','يا إيف '],SUF=['','','','',' يا ايف',' لو سمحتي',' الآن',' بسرعة',' توا'];
function noisy(t){const a=[...t];if(!a.length)return t;const r=rnd();const i=Math.floor(rnd()*a.length);
 if(r<.25&&CONF[a[i]])a[i]=CONF[a[i]];else if(r<.4&&a.length>4)a.splice(i,1);else if(r<.5&&i+1<a.length){const x=a[i];a[i]=a[i+1];a[i+1]=x}return a.join('')}
run("function __syn(t){const w=t.split(/\\s+/);const idx=w.map((x,i)=>nluCon()[nz(x)]?i:-1).filter(i=>i>=0);return JSON.stringify(idx.map(i=>[i,nluCon()[nz(w[i])]]))}");
const GROUPS=run("JSON.stringify(Object.fromEntries(Object.keys(NLU_CON_RAW).map(k=>[k,NLU_CON_RAW[k].split(' ').filter(Boolean)])))");const G=JSON.parse(GROUPS);
function synSwap(t){ctx.__t=t;const hits=JSON.parse(run('__syn(__t)'));if(!hits.length)return t;const[i,k]=pick(hits),w=t.split(/\s+/);const cand=G[k].filter(x=>!['من','ما','انا','انت','انتي','يوم','اسم'].includes(x));w[i]=pick(cand);return w.join(' ')}
function variants(t,n){const out=[t];for(let k=0;k<n;k++){let v=t;if(rnd()<.5)v=synSwap(v);v=pick(PRE)+v+pick(SUF);if(rnd()<.3)v=noisy(v);out.push(v)}return out}
const labels=[...D.INTENTS.map(i=>({id:i.id,canon:i.canon,slot:!!i.slot})),{id:'__other__',canon:'',slot:false}];const lid=Object.fromEntries(labels.map((l,i)=>[l.id,i]));
const rows=[];const add=(text,id,split)=>{rows.push({text,y:lid[id],split})};
for(const I of D.INTENTS){
 if(!I.slot){const seeds=[I.canon,...I.train];seeds.forEach((s,i)=>{const val=i%7===3;for(const v of variants(s,val?3:12))add(v,I.id,val?'va':'tr')})}
 else{for(const e of D.ENT_TRAIN)for(const t of I.tpl){const val=(t.length+e.length)%7===3;const s=t.replace('{e}',e);for(const v of variants(s,val?1:2))add(v,I.id,val?'va':'tr')}}}
D.NEG_TRAIN.forEach((s,i)=>{const val=i%7===3;for(const v of variants(s,val?3:11))add(v,'__other__',val?'va':'tr')});
// قوالب الاختبار تُبنى بكيانات لم تُرَ، بلا تضخيم
const tests=[];for(const I of D.INTENTS){if(!I.slot)for(const t of I.test)tests.push({text:t,id:I.id});else for(const e of D.ENT_TEST)for(const t of I.testTpl)tests.push({text:t.replace('{e}',e),id:I.id,ent:e})}
for(const t of D.NEG_TEST)tests.push({text:t,id:'__other__'});
const feat=t=>{ctx.__t=t;return JSON.parse(run('__nf(__t)'))};
const out={labels,tr:[],va:[]};for(const r of rows){const [idx,val]=feat(r.text);out[r.split].push({y:r.y,idx,val})}
out.test=tests.map(t=>{const [idx,val]=feat(t.text);return{y:lid[t.id],idx,val,text:t.text,id:t.id}});
fs.writeFileSync('nlu_feat.json',JSON.stringify(out));fs.writeFileSync('nlu_tests.json',JSON.stringify(tests));
console.log('تدريب',out.tr.length,'| تحقق',out.va.length,'| اختبار (صيغ مختلفة عمداً)',out.test.length,'| أصناف',labels.length);
