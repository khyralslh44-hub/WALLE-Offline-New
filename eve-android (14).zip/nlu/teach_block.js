/*TEACH_START*/
/* ===== معلّم كبير ← تلميذ صغير: حين يعمل Vosk (النكهة الكاملة) يسمّي كلامك الحقيقي، فتتعلم أذن إيف الصغيرة منه بلا تسجيل يدوي ===== */
var KA={clips:{},bytes:0,n:0},TDEF=0;
function levd(a,b){const m=a.length,n=b.length,d=Array.from({length:m+1},(_,i)=>[i]);for(let j=1;j<=n;j++)d[0][j]=j;for(let i=1;i<=m;i++)for(let j=1;j<=n;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[m][n]}
/** هل نصّ المعلّم هو إحدى عبارات إيف؟ (بعد الحزمة اللغوية واللهجة، تطابق ≥ 85٪) */
function phraseMatch(text){const t0=nz(arPack(text||'')).trim(),t1=nz(dialNorm(t0)).trim();if(t0.length<2)return null;let best=null,bs=0;const sim=(a,b)=>1-levd(a,b)/Math.max(a.length,b.length,1);
 for(const c of CMDS.concat(CMDS_LY))for(const cand of[c[0],c[1]]){if(!cand||cand==='__wake')continue;const u0=nz(cand).trim(),u1=nz(dialNorm(cand)).trim();if(!u0)continue;const s=Math.max(sim(t0,u0),sim(t1,u1)-.001);if(s>bs){bs=s;best=c[0]}}
 return bs>=.85?{label:best,score:bs}:null}
function kaAdd(label,x){const L=(KA.clips[label]=KA.clips[label]||[]);if(L.length>=30||KA.bytes>3e7)return;const i16=Int16Array.from(x,v=>Math.max(-32768,Math.min(32767,Math.round(v*32767))));L.push(i16);KA.bytes+=i16.length*2;KA.n++}
function teachFrom(text,b64){if(!b64)return false;const x=earPcm(b64),f=earFeat(x);if(!f)return false;const m=phraseMatch(text);
 if(m){const L=(M.voice[m.label]=M.voice[m.label]||[]),T=EAR.T[m.label]||[];
  // دفاع من تسمية المعلّم الخاطئة: لا نضيف ما يخالف أذنك أو ما لا ينسجم مع قوالب عبارته
  if(TDEF>=1&&Object.keys(EAR.T).length>=2){const R=earRecog(f,EAR.T,EAR.thr);if(R.ok&&R.label!==m.label)return false}
  if(TDEF>=2&&T.length>=2&&EAR.thr[m.label]){let d=1e9;for(const t of T)d=Math.min(d,earDTW(f,t));if(d>EAR.thr[m.label].t*1.3)return false}
  if(L.length<6){L.push(earPack(f));(EAR.T[m.label]=EAR.T[m.label]||[]).push(f);if(Object.keys(EAR.T).length>1)EAR.thr=earCal(EAR.T);save()}kaAdd(m.label,x);return true}
 if(text.trim().split(/\s+/).length>=2&&text.length>6)kaAdd('__other__',x);return false}
Eve.speechA=function(text,b64){Eve.speech(text);try{teachFrom(text,b64)}catch(e){}};
function kaExport(){const ph=CMDS.concat(CMDS_LY),list=ph.map((c,i)=>({id:'p'+String(i).padStart(2,'0'),phrase:c[0],intent:c[1]})).concat([{id:'__other__',phrase:null}]),idOf={};ph.forEach((c,i)=>{idOf[c[0]]='p'+String(i).padStart(2,'0')});idOf.__other__='__other__';
 const clips={};for(const l in KA.clips)if(idOf[l])clips[idOf[l]]=KA.clips[l];if(!KA.n){say('لم أجمع بيانات من المعلّم بعد. تعمل هذه الميزة مع نكهة Vosk الكاملة.','calm',null,true);return false}
 const{zip,n}=kcZip({list,clips,spk:'teacher'});kcSave(zip,n,'eve-teacher-'+new Date().toISOString().slice(0,10)+'.zip');return true}
/*TEACH_END*/
