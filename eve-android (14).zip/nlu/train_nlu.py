#!/usr/bin/env python3
"""مصنّف النيات الصغير: انحدار softmax على سمات هاشية (numpy فقط). يعايِر العتبات على التحقق، ثم يقيس على صيغ اختبار مختلفة."""
import json,sys,base64,numpy as np,scipy.sparse as sp
pre=sys.argv[1]; out=sys.argv[2]; D=4096
d=json.load(open(pre)); labels=d['labels']; K=len(labels); OTH=[l['id'] for l in labels].index('__other__')
def mat(rows):
    ip=[0]; ix=[]; vv=[]
    for r in rows: ix+=r['idx']; vv+=r['val']; ip.append(len(ix))
    return sp.csr_matrix((vv,ix,ip),shape=(len(rows),D),dtype=np.float32), np.array([r['y'] for r in rows])
Xtr,ytr=mat(d['tr']); Xva,yva=mat(d['va']); Xte,yte=mat(d['test'])
rs=np.random.RandomState(3); W=np.zeros((D,K),np.float32); b=np.zeros(K,np.float32)
mW=np.zeros_like(W); vW=np.zeros_like(W); mb=np.zeros_like(b); vb=np.zeros_like(b); t=0
cw=np.ones(K,np.float32); cw[OTH]=1.4
def softmax(z): z=z-z.max(1,keepdims=True); e=np.exp(z); return e/e.sum(1,keepdims=True)
Y1=np.eye(K,dtype=np.float32); best=(1e9,None); BS=256; EP=60
for ep in range(EP):
    lr=0.08*(0.5*(1+np.cos(np.pi*ep/EP))*0.9+0.1); perm=rs.permutation(Xtr.shape[0])
    for s in range(0,len(perm),BS):
        ix=perm[s:s+BS]; x=Xtr[ix]; yt=Y1[ytr[ix]]*0.92+0.08/K
        p=softmax(x@W+b); g=(p-yt)*cw[ytr[ix]][:,None]/len(ix)
        gW=(x.T@g)+2e-5*W; gb=g.sum(0); t+=1
        for P,G,m,v in ((W,gW,mW,vW),(b,gb,mb,vb)):
            m*=0.9; m+=0.1*G; v*=0.999; v+=0.001*G*G; P-=lr*(m/(1-0.9**t))/(np.sqrt(v/(1-0.999**t))+1e-8)
    pv=softmax(Xva@W+b); vl=-np.log(pv[np.arange(len(yva)),yva]+1e-9).mean()
    if vl<best[0]: best=(vl,(W.copy(),b.copy()),ep)
    if ep%10==0 or ep==EP-1: print(f'  دورة {ep:2d} خسارة تحقق {vl:.3f} دقة {np.mean(pv.argmax(1)==yva)*100:.1f}%')
W,b=best[1]; print('أفضل دورة',best[2])
def metrics(X,y,tau,mg):
    p=softmax(X@W+b); top=p.argmax(1); s=np.sort(p,1); pm=s[:,-1]; m=s[:,-1]-s[:,-2]
    ok=(top!=OTH)&(pm>=tau)&(m>=mg); pos=y!=OTH
    rec=(ok&(top==y)&pos).sum()/max(1,pos.sum()); wr=(ok&(top!=y)&pos).sum()/max(1,pos.sum()); fa=(ok&~pos).sum()/max(1,(~pos).sum()); return rec,wr,fa
# عتبتان: tau للسؤال «هل تقصد…؟» (قبول الغريب ≤ 4%)، auto للتنفيذ المباشر (≤ 0.5%)
def calib(maxfa,maxwr):
    bestc=None
    for tau in np.arange(.2,.99,.01):
        for mg in (0.0,.05,.1,.2):
            rec,wr,fa=metrics(Xva,yva,tau,mg)
            if fa<=maxfa and wr<=maxwr and (bestc is None or rec>bestc[0]): bestc=(rec,tau,mg)
    return bestc or (0,.9,.2)
c1=calib(.04,.03); c2=calib(.005,.005); tau,mg=float(c1[1]),float(c1[2]); auto=float(max(c2[1],tau))
print(f'عتبة السؤال p≥{tau:.2f} (هامش {mg}) | عتبة التنفيذ المباشر p≥{auto:.2f}')
for nm,(X,y) in (('تحقق',(Xva,yva)),('اختبار: صيغ مختلفة عمداً',(Xte,yte))):
    rec,wr,fa=metrics(X,y,tau,mg); r2,w2,f2=metrics(X,y,auto,mg)
    print(f'{nm}: [سؤال/تنفيذ]  استرجاع {rec*100:.1f}%/{r2*100:.1f}% | توجيه خاطئ {wr*100:.1f}%/{w2*100:.1f}% | جملة غريبة وُجِّهت {fa*100:.1f}%/{f2*100:.1f}%')
sw=float(np.abs(W).max()/127+1e-12); Wq=np.round(W.T/sw).astype(np.int8)
model={'labels':[{'id':l['id'],'canon':l['canon'],**({'slot':1} if l['slot'] else {})} for l in labels],'W':base64.b64encode(Wq.tobytes()).decode(),'sw':sw,'b':[round(float(v),4) for v in b],'tau':tau,'auto':auto,'margin':mg}
json.dump(model,open(out,'w'),separators=(',',':')); import os; print('حجم النموذج',os.path.getsize(out)//1024,'KB | معاملات',W.size+b.size)
