const H=require('/home/claude/ear/h.js'),S=require('/home/claude/ear/synth.js');const {run,ctx}=H;
const LAB=['نعم','لا','ماذا ترى','ماذا تفعلين','كيف حالك','مرحبا','كم الساعة','ما هي تذكيراتي'],NW=LAB.length,words=S.mkWords(NW,21);
run('var __calls=[];{const _c=earCmd;earCmd=function(t){__calls.push(t);return _c(t)}}');
const INT=Object.fromEntries(LAB.map(l=>[l,run(`CMDS.find(c=>c[0]===${JSON.stringify(l)})[1]`)]));
function trial(seed,tdef,noise,nteach){S.setSeed(seed);const A=i=>S.word(words[i],S.spk({amb:[.002,.008]}));run(`M.voice={};EAR.T={};EAR.thr={};KA={clips:{},bytes:0,n:0};TDEF=${tdef}`);
 for(let k=0;k<nteach;k++)for(let i=0;i<NW;i++){let t=LAB[i];if(noise&&S.rnd()<noise)t=LAB[(i+1+Math.floor(S.rnd()*(NW-1)))%NW];ctx.__a=S.toB64(A(i));ctx.__tx=t;run('Eve.speechA(__tx,__a)')}
 let g=0,w=0,n=0;for(let i=0;i<NW;i++)for(let r=0;r<10;r++){run('__calls.length=0');ctx.__u=S.toB64(A(i));run('Eve.utt(__u)');n++;const c=JSON.parse(run('JSON.stringify(__calls)'));if(c.length){if(c[0]===INT[LAB[i]])g++;else w++}}
 const nt=LAB.map(l=>run(`(M.voice[${JSON.stringify(l)}]||[]).length`)).reduce((a,b)=>a+b,0);return[g/n,w/n,nt]}
const SEEDS=[101,102,103,104],NT=+process.argv[2]||4;
for(const noise of JSON.parse(process.argv[3]||'[0.1,0.2]'))for(const tdef of JSON.parse(process.argv[4]||'[0,1,2]')){const R=SEEDS.map(s=>trial(s,tdef,noise,NT));const m=i=>R.reduce((a,r)=>a+r[i],0)/R.length;
 console.log(`معلّم يخطئ ${String(noise*100).padStart(2)}% | ${['بلا دفاع','دفاع التعارض','دفاعان   '][tdef]} | صحيح ${(100*m(0)).toFixed(1)}% | خطأ ${(100*m(1)).toFixed(1)}% | قوالب مقبولة ${m(2).toFixed(1)} من ${NW*NT}`)}
