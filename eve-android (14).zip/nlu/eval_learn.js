const H=require('/home/claude/ear/h.js');const {run,ctx,said,tick}=H;const T=JSON.parse(require('fs').readFileSync('nlu_tests.json','utf8')),D=require('./nlu_data.js');tick(20);
run("M.people={'زياد':'x','مريم':'x','نادر':'x'};M.things={'الشاحن':[[1]],'القلم':[[1]]};M.seenObj={}");
run("var __um=0,__nest=[];{const _a=askMeaning;askMeaning=function(){__um++;return _a.apply(null,arguments)};const _u=understand;understand=function(t){if(NLU.busy)__nest.push(t);return _u.apply(null,arguments)}}");
const canonOf=Object.fromEntries(D.INTENTS.map(i=>[i.id,i]));
function evalSet(items){const R={pos:0,ok:0,wrongDirect:0,wrongAsk:0,negN:0,negAsk:0,negDirect:0};
 for(const t of items){ctx.__t=t.text;run('DLG=null;ASK=null;WM=[];lastUnknown=null;confusedN=0;__um=0;__nest=[];NLU.busy=false;PQ=null');said.length=0;run('understand(__t)');
  const um=run('__um'),nest=JSON.parse(run('JSON.stringify(__nest)')),ask=run('ASK&&ASK.k==="nlu"?ASK.canon:null');
  if(t.id==='__other__'){R.negN++;if(nest.length)R.negDirect++;else if(ask)R.negAsk++;continue}R.pos++;const I=canonOf[t.id],want=I.slot?I.canon.replace('{e}',t.ent):I.canon;
  if(um===0&&!nest.length&&!ask){R.ok++;continue}const got=nest[0]||ask;if(got===want)R.ok++;else if(got){nest.length?R.wrongDirect++:R.wrongAsk++}}return R}
const fs=require('fs');let conf;
if(process.argv[2]==='collect'){const askOK=[];for(const t of T){if(t.id==='__other__')continue;ctx.__t=t.text;run('DLG=null;ASK=null;WM=[];NLU.busy=false;PQ=null');run('understand(__t)');const a=run('ASK&&ASK.k==="nlu"?ASK.canon:null'),I=canonOf[t.id];if(a&&a===(I.slot?I.canon.replace('{e}',t.ent):I.canon))askOK.push(t)}
 fs.writeFileSync('askok.json',JSON.stringify(askOK.slice(0,15)));console.log('جمعتُ',Math.min(15,askOK.length),'عبارة يسأل عنها إيف صحيحاً');process.exit(0)}
conf=JSON.parse(fs.readFileSync('askok.json','utf8'));const confSet=new Set(conf.map(t=>t.text)),rest=T.filter(t=>!confSet.has(t.text));
const before=evalSet(rest);
for(const t of conf){ctx.__t=t.text;run('DLG=null;ASK=null;WM=[];NLU.busy=false');run('understand(__t)');if(run('ASK&&ASK.k==="nlu"'))run('understand("نعم")')}
const after=evalSet(rest);const f=(R)=>`مفهومة صحيحاً ${(100*R.ok/R.pos).toFixed(1)}% | خطأ مباشر ${(100*R.wrongDirect/R.pos).toFixed(1)}% | خطأ بسؤال ${(100*R.wrongAsk/R.pos).toFixed(1)}% | سلبيات: مباشر ${R.negDirect} وبسؤال ${R.negAsk} من ${R.negN}`;
console.log('أؤكد',conf.length,'صيغة صحيحة ثم أقيس الصيغ الأخرى التي لم أؤكدها (',rest.filter(t=>t.id!=='__other__').length,'نية +',rest.filter(t=>t.id==='__other__').length,'سلبية )');
console.log('قبل التعلم  :',f(before));console.log('بعد التعلم  :',f(after));
