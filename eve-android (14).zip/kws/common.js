// يحمّل نفس كود الأذن من التطبيق + كتلة KWS، فلا يوجد تحويل بين لغتين ولا فرق بين التدريب والتشغيل
const fs=require('fs');
const app=fs.readFileSync(process.env.EVE_HTML||'/mnt/user-data/outputs/eve.html','utf8');
const ear=app.slice(app.indexOf('/*EAR_START*/'),app.indexOf('/*EAR_END*/'));
const kws=fs.readFileSync(__dirname+'/kws_block.js','utf8');
const atob_=s=>Buffer.from(s,'base64').toString('binary'),btoa_=s=>Buffer.from(s,'binary').toString('base64');
const M={voice:{}};
const api=new Function('M','atob','btoa',ear+kws+';return {earFeat,earDTW,earCal,earRecog,kwsVec,kwsLoad,kwsProbs,kwsProbsVec,kwsDecide,KWS,EAR}')(M,atob_,btoa_);
function readWav(p){const b=fs.readFileSync(p);if(b.toString('ascii',0,4)!=='RIFF')throw new Error('not wav '+p);let o=12,sr=16000,data=null;while(o+8<=b.length){const id=b.toString('ascii',o,o+4),n=b.readUInt32LE(o+4);if(id==='fmt ')sr=b.readUInt32LE(o+12);if(id==='data'){data=b.subarray(o+8,o+8+n);break}o+=8+n+(n&1)}
 const x=new Float32Array(data.length>>1);for(let i=0;i<x.length;i++)x[i]=data.readInt16LE(2*i)/32768;return{x,sr}}
function writeWav(p,x,sr=16000){const b=Buffer.alloc(44+x.length*2);b.write('RIFF',0);b.writeUInt32LE(36+x.length*2,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(sr,24);b.writeUInt32LE(sr*2,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(x.length*2,40);
 for(let i=0;i<x.length;i++)b.writeInt16LE(Math.max(-32768,Math.min(32767,Math.round(x[i]*32767))),44+2*i);fs.writeFileSync(p,b)}
function resample(x,sr){if(sr===16000)return x;const r=sr/16000,n=Math.floor(x.length/r),y=new Float32Array(n);for(let k=0;k<n;k++){const i0=Math.floor(k*r),i1=Math.max(i0+1,Math.floor((k+1)*r));let s=0;for(let i=i0;i<i1&&i<x.length;i++)s+=x[i];y[k]=s/(i1-i0)}return y}
module.exports=Object.assign(api,{readWav,writeWav,resample,fs});
