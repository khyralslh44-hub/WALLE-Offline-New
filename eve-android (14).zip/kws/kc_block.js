/*KC_START*/
/* ===== جمع بيانات الصوت لتدريب نموذج إيف الصغير: تسجيلات WAV منظمة داخل ملف zip (تبقى على جهازك حتى ترسلها أنت) ===== */
const KC_OTHER=['احكي لي عن يومك','ما رأيك بالطقس اليوم','أريد كوباً من الشاي','أين وضعت مفاتيحي','هذا كتاب جميل جداً','سنذهب إلى السوق غداً','تعال هنا قليلاً','لا أعرف ماذا أقول','الجو بارد هذا الصباح','هل رأيت ما حدث'];
var KC=null;
const CRCT=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
function crc32(b){let c=0xFFFFFFFF;for(let i=0;i<b.length;i++)c=CRCT[(c^b[i])&255]^(c>>>8);return(c^0xFFFFFFFF)>>>0}
function wavBytes(i16,sr){const n=i16.length,b=new Uint8Array(44+2*n),dv=new DataView(b.buffer);const W=(o,s)=>{for(let i=0;i<s.length;i++)b[o+i]=s.charCodeAt(i)};W(0,'RIFF');dv.setUint32(4,36+2*n,true);W(8,'WAVEfmt ');dv.setUint32(16,16,true);dv.setUint16(20,1,true);dv.setUint16(22,1,true);dv.setUint32(24,sr,true);dv.setUint32(28,sr*2,true);dv.setUint16(32,2,true);dv.setUint16(34,16,true);W(36,'data');dv.setUint32(40,2*n,true);for(let i=0;i<n;i++)dv.setInt16(44+2*i,i16[i],true);return b}
function zipStore(files){const enc=new TextEncoder(),parts=[],cd=[];let off=0;const u16=v=>[v&255,(v>>8)&255],u32=v=>[v&255,(v>>8)&255,(v>>16)&255,(v>>>24)&255];
 for(const f of files){const nm=enc.encode(f.name),crc=crc32(f.data),sz=f.data.length;
  const lh=Uint8Array.from([0x50,0x4b,3,4,...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0x21),...u32(crc),...u32(sz),...u32(sz),...u16(nm.length),...u16(0)]);parts.push(lh,nm,f.data);
  cd.push(Uint8Array.from([0x50,0x4b,1,2,...u16(20),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0x21),...u32(crc),...u32(sz),...u32(sz),...u16(nm.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(off)]),nm);off+=lh.length+nm.length+sz}
 let cdl=0;for(const c of cd)cdl+=c.length;parts.push(...cd,Uint8Array.from([0x50,0x4b,5,6,0,0,0,0,...u16(files.length),...u16(files.length),...u32(cdl),...u32(off),0,0]));
 let tot=0;for(const p of parts)tot+=p.length;const out=new Uint8Array(tot);let o=0;for(const p of parts){out.set(p,o);o+=p.length}return out}
function kcPrompt(){const E=KC.list[KC.i],txt=E.phrase!==null?E.phrase:KC_OTHER[KC.k%KC_OTHER.length],tip=KC.k%5===4?' (غيّر المسافة أو نبرة صوتك قليلاً)':'';say((KC.k===0?'العبارة «'+txt+'»':'«'+txt+'»')+' — '+(KC.k+1)+' من '+KC.n+tip,'curious',null,true)}
function kcStart(n){const ph=CMDS.concat(CMDS_LY);KC={list:ph.map((c,i)=>({id:'p'+String(i).padStart(2,'0'),phrase:c[0],intent:c[1]})).concat([{id:'__other__',phrase:null}]),i:0,n:n||10,k:0,clips:{},spk:'u'+(M.kcSess=(M.kcSess||0)+1),bytes:0};
 if(!NAT&&!micOn)micToggle();say('سنسجّل بياناتك الصوتية لتدريب نموذج إيف الصغير: كل عبارة '+KC.n+' مرات (وجمل عشوائية في النهاية). التسجيلات تبقى على جهازك. اضغط الشاشة لتخطي عبارة. قل بصوتك الطبيعي.','curious',null,true);setTimeout(kcPrompt,1800)}
function kcStep(x){const K=KC,E=K.list[K.i];if(x.length<4800||x.length>56000||!earFeat(x)){say('لم أسمعك جيداً، أعد من فضلك.','confused',null,true);return}
 const i16=Int16Array.from(x,v=>Math.max(-32768,Math.min(32767,Math.round(v*32767))));(K.clips[E.id]=K.clips[E.id]||[]).push(i16);K.bytes+=i16.length*2;K.k++;
 if(K.bytes>60e6){kcFinish();return}if(K.k>=K.n)kcNext();else kcPrompt()}
function kcNext(){KC.i++;KC.k=0;if(KC.i>=KC.list.length){kcFinish();return}kcPrompt()}
function kcSkip(){if(KC)kcNext()}
function kcZip(K){K=K||KC;const files=[],labels=K.list.map(e=>({id:e.id,phrase:e.phrase,intent:e.intent||null}));let n=0;
 for(const e of K.list)(K.clips[e.id]||[]).forEach((c,j)=>{files.push({name:'data/'+e.id+'/'+K.spk+'_'+j+'.wav',data:wavBytes(c,16000)});n++});
 files.push({name:'labels.json',data:new TextEncoder().encode(JSON.stringify(labels))});files.push({name:'README.txt',data:new TextEncoder().encode('Eve voice data. 16 kHz mono WAV, speaker='+K.spk+', clips='+n+'. Folder id -> labels.json. __other__ = random speech.')});return{zip:zipStore(files),n}}
function kcSave(zip,n,name){let bin='';for(let i=0;i<zip.length;i+=8192)bin+=String.fromCharCode.apply(null,zip.subarray(i,Math.min(zip.length,i+8192)));const b64=btoa(bin);let where='';
 if(NAT&&Android.saveChunk){const CH=393216;for(let i=0;i<b64.length;i+=CH)where=Android.saveChunk(name,b64.slice(i,i+CH),i+CH>=b64.length)||where}
 else if(typeof document!=='undefined'&&document.createElement){try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([zip],{type:'application/zip'}));a.download=name;a.click();where='التنزيلات'}catch(e){}}
 say(where?'حفظت '+n+' تسجيلاً في «'+where+'» باسم '+name+' ('+Math.round(zip.length/1024)+' كيلوبايت). أرسله لي لأدرّب النموذج.':'جمعت '+n+' تسجيلاً لكن تعذّر حفظ الملف على هذا الجهاز.','proud',null,true)}
function kcFinish(){const{zip,n}=kcZip(KC),name='eve-voice-'+KC.spk+'-'+new Date().toISOString().slice(0,10)+'.zip';KC=null;kcSave(zip,n,name)}
/*KC_END*/
