// يقرأ WAV ويستخرج متجهات التدريب بنفس كود الأذن في التطبيق، مع تضخيم البيانات. المخرج: ملف ثنائي float32 + قائمة وصفية
const C=require('./common.js'),S=require('/home/claude/ear/synth.js');
const [,, DIR, OUT, AUG='4', SEED='11']=process.argv;const AU=+AUG;
let sd=+SEED;const rnd=()=>{sd=(sd*1664525+1013904223)>>>0;return sd/4294967296},gauss=()=>{let u=0;while(!u)u=rnd();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*rnd())};
const labels=C.fs.readdirSync(DIR).filter(d=>C.fs.statSync(DIR+'/'+d).isDirectory()).sort((a,b)=>a==='__other__'?1:b==='__other__'?-1:a<b?-1:1);
function augment(x){// سرعة، كسب، ضجيج، إزاحة زمنية
 const r=.9+rnd()*.2,n=Math.floor(x.length/r),y=new Float32Array(n);for(let i=0;i<n;i++){const p=i*r,k=Math.floor(p),f=p-k;y[i]=x[k]*(1-f)+(x[Math.min(k+1,x.length-1)])*f}
 const g=.5+rnd()*1.2,amb=.002+rnd()*.012,lead=Math.floor(rnd()*4000),out=new Float32Array(n+lead+3000);for(let i=0;i<out.length;i++)out[i]=gauss()*amb;for(let i=0;i<n;i++)out[lead+i]+=y[i]*g;return out}
const rows=[],meta=[];let skipped=0;
for(let li=0;li<labels.length;li++){const dir=DIR+'/'+labels[li];for(const f of C.fs.readdirSync(dir).filter(f=>f.endsWith('.wav')).sort()){const{x,sr}=C.readWav(dir+'/'+f),x16=C.resample(x,sr);
  for(let a=0;a<=AU;a++){const F=C.earFeat(a===0?x16:augment(x16));if(!F){skipped++;continue}rows.push(C.kwsVec(F));meta.push({y:li,spk:f.split('_')[0],aug:a})}}}
const D=rows[0].length,buf=Buffer.alloc(rows.length*D*4);rows.forEach((r,i)=>{for(let k=0;k<D;k++)buf.writeFloatLE(r[k],(i*D+k)*4)});
C.fs.writeFileSync(OUT+'.bin',buf);C.fs.writeFileSync(OUT+'.json',JSON.stringify({labels,D,n:rows.length,meta}));
console.log('متجهات',rows.length,'× بُعد',D,'| عبارات',labels.length,'| مرفوض (قصير/طويل)',skipped);
