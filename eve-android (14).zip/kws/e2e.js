// من ملف WAV خام إلى القرار، بنفس كود التطبيق، على متكلمين الاختبار فقط
const C=require('./common.js'),fs=require('fs');C.kwsLoad(JSON.parse(fs.readFileSync('kws_model.json','utf8')));
const meta=JSON.parse(fs.readFileSync('feat_synth.json','utf8'));const spks=[...new Set(meta.meta.map(m=>m.spk))].filter(s=>s!=='s99').sort();
// نفس تقسيم التدريب (البذرة 7): نعيد اشتقاق متكلمي الاختبار من الملف المحفوظ ليتطابق
const te=process.argv.slice(2);let N=0,ok=0,wr=0,vocN=0,othN=0,fa=0,ms=0;
for(const lab of fs.readdirSync('data_synth')){for(const f of fs.readdirSync('data_synth/'+lab)){const sp=f.split('_')[0];if(!te.includes(sp))continue;const{x}=C.readWav('data_synth/'+lab+'/'+f);const t0=process.hrtime.bigint();const F=C.earFeat(x);const d=F?C.kwsDecide(F):null;ms+=Number(process.hrtime.bigint()-t0)/1e6;N++;
 if(lab==='__other__'){othN++;if(d&&d.ok)fa++}else{vocN++;if(d&&d.ok){if(d.label===lab)ok++;else wr++}}}}
console.log(`WAV→قرار على ${te.length} متكلمين لم يُرَوا (${N} مقطعاً): استرجاع ${(100*ok/vocN).toFixed(1)}% | تبديل خاطئ ${(100*wr/vocN).toFixed(1)}% | غريب مقبول ${(100*fa/Math.max(1,othN)).toFixed(1)}% | ${(ms/N).toFixed(1)} ms/مقطع (سمات+نموذج)`);
