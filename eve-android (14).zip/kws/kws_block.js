/*KWS_START*/
/* ===== نموذج إيف الصغير للعبارات (MLP على سمات MFCC المطوية زمنياً). يُدرَّب خارج الجهاز ويُشحن كملف صغير (~0.1 ميجابايت) ===== */
const KWS={m:null,SEG:16};
/** تحويل تسلسل سمات متغير الطول إلى متجه ثابت: متوسط 16 مقطعاً زمنياً + لوغاريتم المدة */
function kwsVec(F){const T=F.length,D=F[0].length,S=KWS.SEG,v=new Float32Array(S*D+1);for(let s=0;s<S;s++){const a=Math.floor(s*T/S),b=Math.max(a+1,Math.floor((s+1)*T/S));for(let t=a;t<b;t++)for(let k=0;k<D;k++)v[s*D+k]+=F[t][k];const n=b-a;for(let k=0;k<D;k++)v[s*D+k]/=n}v[S*D]=Math.log(T)/5;return v}
function kwsLoad(o){const q=(a,s)=>{const b=atob(a),r=new Float32Array(b.length);for(let i=0;i<b.length;i++){let c=b.charCodeAt(i);if(c>127)c-=256;r[i]=c*s}return r};
 KWS.m={labels:o.labels,mean:Float32Array.from(o.mean),std:Float32Array.from(o.std),tau:o.tau,margin:o.margin,L:o.layers.map(l=>({i:l.i,o:l.o,W:q(l.W,l.sw),b:Float32Array.from(l.b)}))}}
function kwsProbs(F){return KWS.m?kwsProbsVec(kwsVec(F)):null}
function kwsProbsVec(x){const m=KWS.m;let h=new Float32Array(x.length);for(let i=0;i<h.length;i++)h[i]=(x[i]-m.mean[i])/m.std[i];
 for(let li=0;li<m.L.length;li++){const L=m.L[li],y=new Float32Array(L.o);for(let o=0;o<L.o;o++){let s=L.b[o];const w=o*L.i;for(let i=0;i<L.i;i++)s+=L.W[w+i]*h[i];y[o]=s}if(li<m.L.length-1){for(let o=0;o<L.o;o++)if(y[o]<0)y[o]=0}h=y}
 let mx=-1e9;for(const v of h)if(v>mx)mx=v;let z=0;const p=new Float32Array(h.length);for(let i=0;i<h.length;i++){p[i]=Math.exp(h[i]-mx);z+=p[i]}for(let i=0;i<p.length;i++)p[i]/=z;return p}
/** قرار: العبارة الأعلى احتمالاً بشرط عتبة وهامش، و«أخرى» تُرفض */
function kwsDecide(F){const p=kwsProbs(F);if(!p)return null;const m=KWS.m;let b=0,s=-1;for(let i=0;i<p.length;i++)if(p[i]>p[b])b=i;for(let i=0;i<p.length;i++)if(i!==b&&p[i]>s)s=p[i];
 return{label:m.labels[b],p:p[b],ok:m.labels[b]!=='__other__'&&p[b]>=m.tau&&p[b]-s>=m.margin}}
/*KWS_END*/
