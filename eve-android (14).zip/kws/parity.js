const C=require('./common.js'),fs=require('fs');
C.kwsLoad(JSON.parse(fs.readFileSync('kws_model.json','utf8')));
const X=fs.readFileSync('kws_model.json.testX.bin'),P=fs.readFileSync('kws_model.json.testP.bin'),D=401,K=C.KWS.m.labels.length,n=X.length/(4*D);
let md=0,agree=0;for(let i=0;i<n;i++){const v=new Float32Array(D);for(let k=0;k<D;k++)v[k]=X.readFloatLE((i*D+k)*4);const p=C.kwsProbsVec?C.kwsProbsVec(v):null;
 let bj=0,bp=0;for(let c=0;c<K;c++){const pj=p[c],pp=P.readFloatLE((i*K+c)*4);md=Math.max(md,Math.abs(pj-pp));if(pj>p[bj])bj=c;if(pp>P.readFloatLE((i*K+bp)*4))bp=c}if(bj===bp)agree++}
console.log('تطابق JS(int8) مع Python(float32) على',n,'عينة: أكبر فرق احتمال',md.toFixed(4),'| اتفاق الصنف',agree+'/'+n);
