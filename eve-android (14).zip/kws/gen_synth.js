// مجموعة بيانات تركيبية بنفس بنية الجمع الحقيقي: data/<عبارة>/<متكلم>_<رقم>.wav  (للتحقق من سلامة الخط فقط، ليست كلاماً عربياً)
const C=require('./common.js'),S=require('/home/claude/ear/synth.js'),fs=require('fs');
const OUT=process.argv[2]||'/home/claude/kws/data_synth',NV=+process.argv[3]||20,NO=+process.argv[4]||12,NSPK=+process.argv[5]||26,REP=+process.argv[6]||6;
const words=S.mkWords(NV+NO,5);S.setSeed(2024);fs.rmSync(OUT,{recursive:true,force:true});
// متكلمون: كل متكلم له نبرة وحنجرة وسرعة وضجيج غرفة ثابت خاص به (كما في الواقع)
const spks=Array.from({length:NSPK},(_,i)=>({f0:95+S.rnd()*130,fs:.9+S.rnd()*.28,sp:.9+S.rnd()*.25,amb:[.002+S.rnd()*.006,.004+S.rnd()*.01]}));
let n=0;for(let w=0;w<NV+NO;w++){const lab=w<NV?'w'+String(w).padStart(2,'0'):'__other__';const d=OUT+'/'+lab;fs.mkdirSync(d,{recursive:true});
 for(let s=0;s<NSPK;s++)for(let r=0;r<(w<NV?REP:Math.ceil(REP/2));r++){const x=S.word(words[w],S.spk(spks[s]));C.writeWav(d+'/s'+String(s).padStart(2,'0')+'_'+w+'_'+r+'.wav',x);n++}}
// ضجيج خالص كذلك
fs.mkdirSync(OUT+'/__other__',{recursive:true});for(let i=0;i<60;i++){C.writeWav(OUT+'/__other__/s99_noise_'+i+'.wav',S.noiseOnly());n++}
console.log('كُتب',n,'ملف WAV في',OUT,'| عبارات',NV,'| كلمات أخرى',NO,'| متكلمون',NSPK);
