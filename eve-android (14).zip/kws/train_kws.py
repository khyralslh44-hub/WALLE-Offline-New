#!/usr/bin/env python3
"""تدريب نموذج إيف الصغير للعبارات (MLP) بـ numpy فقط. يدخل: ملف السمات من feats.js. يخرج: kws_model.json (int8) + تقرير.
   التقسيم بحسب المتكلم: التدريب والتحقق والاختبار متكلمون مختلفون (لا تسرب)."""
import json,sys,base64,time,numpy as np
rs=np.random.RandomState(7)
pre=sys.argv[1]; out=sys.argv[2] if len(sys.argv)>2 else 'kws_model.json'
H1=int(sys.argv[3]) if len(sys.argv)>3 else 192; H2=int(sys.argv[4]) if len(sys.argv)>4 else 96
meta=json.load(open(pre+'.json')); D=meta['D']; N=meta['n']; labels=meta['labels']; C=len(labels)
X=np.fromfile(pre+'.bin',dtype='<f4').reshape(N,D); y=np.array([m['y'] for m in meta['meta']]); spk=np.array([m['spk'] for m in meta['meta']]); aug=np.array([m['aug'] for m in meta['meta']])
S=sorted(set(spk)); real=[s for s in S if s!='s99']
FEWSPK=len(real)<6
rs.shuffle(real); nte=max(2,len(real)//6); nva=max(2,len(real)//6)
if FEWSPK: nte=nva=0; print('تحذير: أقل من 6 متكلمين، التقسيم بالمقاطع لا بالمتكلمين، فالأرقام التالية متفائلة ولا تدل على متكلمين جدد.')
te=set(real[:nte]); va=set(real[nte:nte+nva]); tr=set(real[nte+nva:])|{'s99'}
if FEWSPK: tr=set(real)|{'s99'}
# ضجيج s99: نوزّعه على الثلاث مجموعات
idx99=np.where(spk=='s99')[0]; rs.shuffle(idx99); k=len(idx99)//4
sets={'tr':[],'va':[],'te':[]}
for i in range(N):
    s=spk[i]
    if s=='s99': continue
    sets['te' if s in te else 'va' if s in va else 'tr'].append(i)
sets['te']+=list(idx99[:k]); sets['va']+=list(idx99[k:2*k]); sets['tr']+=list(idx99[2*k:])
if FEWSPK:
    allv=np.array(sets['tr']+list(idx99)); rs.shuffle(allv)
    base=[i for i in allv if aug[i]==0]; aug_ix=[i for i in allv if aug[i]!=0]
    # التحقق والاختبار من المقاطع الأصلية فقط (بلا تضخيم)، والتدريب من الباقي
    rs.shuffle(base); h=len(base)//4; sets['va']=base[:h]; sets['te']=base[h:2*h]; sets['tr']=base[2*h:]+aug_ix
for k_ in sets: sets[k_]=np.array(sets[k_])
print(f'متكلمون: تدريب {len(tr)-1} | تحقق {len(va)} | اختبار (لم يُرَ) {len(te)} | عينات {len(sets["tr"])}/{len(sets["va"])}/{len(sets["te"])}')
mean=X[sets['tr']].mean(0); std=X[sets['tr']].std(0)+1e-3
Z=((X-mean)/std).astype(np.float32)
def init(i,o): return (rs.randn(i,o)*np.sqrt(2.0/i)).astype(np.float32), np.zeros(o,np.float32)
W1,b1=init(D,H1); W2,b2=init(H1,H2); W3,b3=init(H2,C)
P=[W1,b1,W2,b2,W3,b3]; m_=[np.zeros_like(p) for p in P]; v_=[np.zeros_like(p) for p in P]; t=0
def fwd(x,train=False,drop=.25):
    a1=np.maximum(0,x@P[0]+P[1]); 
    if train: mk1=(rs.rand(*a1.shape)>drop)/(1-drop); a1=a1*mk1
    else: mk1=None
    a2=np.maximum(0,a1@P[2]+P[3]); 
    if train: mk2=(rs.rand(*a2.shape)>drop)/(1-drop); a2=a2*mk2
    else: mk2=None
    lg=a2@P[4]+P[5]; return a1,a2,lg,mk1,mk2
def softmax(lg): e=np.exp(lg-lg.max(1,keepdims=True)); return e/e.sum(1,keepdims=True)
def evalset(ix):
    p=softmax(fwd(Z[ix])[2]); return p
Y1=np.eye(C,dtype=np.float32)
best=(1e9,None); t0=time.time(); EP=int(sys.argv[5]) if len(sys.argv)>5 else 45; BS=128; lr0=2e-3
for ep in range(EP):
    lr=lr0*(0.5*(1+np.cos(np.pi*ep/EP))*0.95+0.05)
    perm=rs.permutation(sets['tr'])
    for b in range(0,len(perm),BS):
        ix=perm[b:b+BS]; x=Z[ix]; yt=Y1[y[ix]]*0.95+0.05/C
        a1,a2,lg,mk1,mk2=fwd(x,True); p=softmax(lg); g=(p-yt)/len(ix)
        gW3=a2.T@g; gb3=g.sum(0); g2=(g@P[4].T)*(a2>0)*(mk2 if mk2 is not None else 1)
        # ملاحظة: القناع مطبّق على a2 قبل الضرب؛ نمرّر التدرج عبر الجزء الفعّال فقط
        g2=(g@P[4].T)*mk2*((a2>0)); gW2=a1.T@g2; gb2=g2.sum(0)
        g1=(g2@P[2].T)*mk1*(a1>0); gW1=x.T@g1; gb1=g1.sum(0)
        G=[gW1+1e-4*P[0],gb1,gW2+1e-4*P[2],gb2,gW3+1e-4*P[4],gb3]; t+=1
        for i,(p_,g_) in enumerate(zip(P,G)):
            m_[i]=0.9*m_[i]+0.1*g_; v_[i]=0.999*v_[i]+0.001*g_*g_
            p_-=lr*(m_[i]/(1-0.9**t))/(np.sqrt(v_[i]/(1-0.999**t))+1e-8)
    pv=evalset(sets['va']); vl=-np.log(pv[np.arange(len(sets['va'])),y[sets['va']]]+1e-9).mean(); va_acc=(pv.argmax(1)==y[sets['va']]).mean()
    if vl<best[0]: best=(vl,[p.copy() for p in P],ep)
    if ep%5==0 or ep==EP-1: print(f'  دورة {ep:2d}  خسارة تحقق {vl:.3f}  دقة تحقق {va_acc*100:.1f}%  ({time.time()-t0:.0f}ث)')
P=best[1]; print('أفضل دورة:',best[2])
OTH=labels.index('__other__')
def metrics(ix,tau,margin):
    p=evalset(ix); yy=y[ix]; top=p.argmax(1); srt=np.sort(p,1); pm=srt[:,-1]; mg=srt[:,-1]-srt[:,-2]
    ok=(top!=OTH)&(pm>=tau)&(mg>=margin); voc=yy!=OTH
    rec=(ok&(top==yy)&voc).sum()/max(1,voc.sum()); wrong=(ok&(top!=yy)&voc).sum()/max(1,voc.sum()); fa=(ok&~voc).sum()/max(1,(~voc).sum())
    return rec,wrong,fa
# معايرة العتبة على التحقق: أعلى استرجاع بشرط قبول الغريب ≤ 1% وخطأ التبديل ≤ 1%
bestc=None
for tau in np.arange(.5,.99,.01):
    for mg in (0.0,0.1,0.2,0.3):
        rec,wr,fa=metrics(sets['va'],tau,mg)
        if fa<=.01 and wr<=.01 and (bestc is None or rec>bestc[0]): bestc=(rec,tau,mg)
if bestc is None: bestc=(0,.9,.3)
tau,mg=float(bestc[1]),float(bestc[2]); print(f'عتبة معايرة على التحقق: p≥{tau:.2f} هامش≥{mg:.1f}')
for nm in('va','te'):
    rec,wr,fa=metrics(sets[nm],tau,mg); top1=(evalset(sets[nm]).argmax(1)==y[sets[nm]]).mean()
    print(f'{"تحقق" if nm=="va" else "اختبار (متكلمون لم يُرَوا)"}: استرجاع {rec*100:.1f}% | تبديل خاطئ {wr*100:.1f}% | غريب مقبول {fa*100:.1f}% | دقة صنف {top1*100:.1f}%')
# تصدير int8
def q(W): s=float(np.abs(W).max()/127+1e-12); return base64.b64encode(np.round(W/s).astype(np.int8).T.tobytes()).decode(),s   # المخزَّن [out][in]
layers=[]
for Wi,bi in ((P[0],P[1]),(P[2],P[3]),(P[4],P[5])):
    b64,s=q(Wi); layers.append({'i':int(Wi.shape[0]),'o':int(Wi.shape[1]),'W':b64,'sw':s,'b':[float(round(v,5)) for v in bi]})
if len(sys.argv)>6:
    mp={d['id']:d['phrase'] for d in json.load(open(sys.argv[6])) if d['phrase']}
    labels=[mp.get(l,l) for l in labels]
model={'labels':labels,'mean':[float(round(v,5)) for v in mean],'std':[float(round(v,5)) for v in std],'tau':tau,'margin':mg,'layers':layers}
json.dump(model,open(out,'w'),separators=(',',':')); import os; print('حجم النموذج',os.path.getsize(out)//1024,'KB | عدد المعاملات',sum(p.size for p in P))
# عينات اختبار للتحقق من تطابق JS/Python
X[sets['te'][:64]].astype('<f4').tofile(out+'.testX.bin'); evalset(sets['te'][:64]).astype('<f4').tofile(out+'.testP.bin')
