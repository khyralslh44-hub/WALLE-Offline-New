const H=require('./h.js'),S=require('/home/claude/ear/synth.js'),cp=require('child_process'),fs=require('fs');const {run,ctx,said,chunks,ok,tick}=H;
const C=require('/home/claude/kws/common.js');const last=()=>said.slice(-1)[0];tick(30);
const PH=run('CMDS.map(c=>c[0])'),INT=run('CMDS.map(c=>c[1])');
ok('model container is loaded from the page (synthetic test model injected by the harness)',run('!!KWS.m&&KWS.m.labels.length')===21);
run("var __oF=earFeat,__oR=earRecog,__oK=kwsDecide;var __calls=[];{const _c=earCmd;earCmd=function(t){__calls.push(t);return _c(t)}}");
// ===== قاعدة الدمج (نحاكي ناتج الأذن الشخصية والنموذج العام لنختبر القاعدة نفسها)
const combo=(R,K,hasT=true)=>{ctx.__R=R;ctx.__K=K;run("earFeat=function(x){return [new Float32Array(25)]};EAR.T="+(hasT?"{a:[[]],b:[[]]}":"{}")+";earRecog=function(){return __R};kwsDecide=function(){return __K};__calls.length=0;earHandleX(new Float32Array(16000))");return JSON.parse(run('JSON.stringify(__calls)'))[0]||null};
const tau=run('KWS.m.tau'),I=l=>INT[PH.indexOf(l)];
ok('both agree → accept',combo({ok:true,label:'نعم',d:1},{ok:true,label:'نعم',p:.8})===I('نعم'));
ok('they disagree and the general model is only moderately sure → reject (no wrong action)',combo({ok:true,label:'نعم'},{ok:true,label:'لا',p:.9})===null);
ok('they disagree but the general model is very sure (≥ .95) → trust it',combo({ok:true,label:'نعم'},{ok:true,label:'لا',p:.96})===I('لا'));
ok('your own-voice match alone is accepted (general model says "other")',combo({ok:true,label:'كيف حالك'},{ok:false,label:'__other__',p:.9})===I('كيف حالك'));
ok('general model alone needs MORE confidence than its own threshold',combo({ok:false},{ok:true,label:'ماذا ترى',p:tau+.02})===null&&combo({ok:false},{ok:true,label:'ماذا ترى',p:Math.min(.97,tau+.12)})===I('ماذا ترى'));
ok('with no enrolled phrases the general model still works',combo(null,{ok:true,label:'مرحبا',p:.99},false)===I('مرحبا'));
ok('everything rejects → no action',combo({ok:false},{ok:false,label:'__other__',p:.9})===null);
ok('no "ear not taught" alarm when the general model exists',!run('healthProblems().some(p=>p[0]==="earT")'));
run("earFeat=__oF;earRecog=__oR;kwsDecide=__oK;EAR.T={};EAR.thr={}");
// ===== المسار الكامل: WAV خام لمتكلمين لم يُرَوا → Eve.utt → الدمج → النية (بلا أي قوالب شخصية)
let N=0,okc=0,wr=0,vocN=0,othN=0,fa=0;
for(const lab of fs.readdirSync('/home/claude/kws/data_synth')){for(const f of fs.readdirSync('/home/claude/kws/data_synth/'+lab)){if(!['s12','s05','s01','s17'].includes(f.split('_')[0]))continue;
 const{x}=C.readWav('/home/claude/kws/data_synth/'+lab+'/'+f);ctx.__u=S.toB64(x);run('__calls.length=0;Eve.utt(__u)');const c=JSON.parse(run('JSON.stringify(__calls)'));N++;
 if(lab==='__other__'){othN++;if(c.length)fa++}else{vocN++;const want=INT[+lab.slice(1)];if(c.length&&c[0]===want)okc++;else if(c.length)wr++}}}
console.log('   مسار التطبيق الكامل على '+N+' مقطعاً (4 متكلمين لم يُرَوا): استرجاع',(100*okc/vocN).toFixed(1)+'% | تبديل خاطئ',(100*wr/vocN).toFixed(1)+'% | غريب مقبول',(100*fa/othN).toFixed(1)+'%');
ok('full app path with the general model only: recall ≥ 90%, wrong ≤ 1%, unknown accepted ≤ 8% (synthetic speech)',okc/vocN>=.9&&wr/vocN<=.01&&fa/othN<=.08);
// ===== جمع البيانات → zip سليم
run('kcStart(2)');H.drain();const nPh=run('KC.list.length');ok('collection starts with all phrases + a "random speech" class ('+nPh+' groups)',nPh===run('CMDS.length+CMDS_LY.length+1')&&/العبارة «/.test(said.slice(-1)[0]),said.slice(-1)[0]);
const words=S.mkWords(nPh,3);S.setSeed(9);const sent=[];
run('KC.n=2');
for(let i=0;i<nPh;i++)for(let k=0;k<2;k++){const x=S.word(words[i],S.spk({}));if(i===0&&k===0)sent.push(x);ctx.__u=S.toB64(x);run('Eve.utt(__u)')}
ok('collection finished and handed the zip to the Android bridge',run('KC')===null&&chunks.length>=1&&/حفظت \d+ تسجيلاً في «Download\/Eve»/.test(last()),last());
fs.writeFileSync('/tmp/eve-test.zip',Buffer.from(chunks.join(''),'base64'));
const t=cp.spawnSync('unzip',['-t','/tmp/eve-test.zip']),tt=t.stdout.toString();ok('unzip validates the archive (CRC of every file)',/No errors detected/.test(tt),tt.split('\n').slice(-2)[0]);
const py=cp.spawnSync('python3',['-c',`
import zipfile,wave,json,io
z=zipfile.ZipFile('/tmp/eve-test.zip');n=z.namelist();w=[x for x in n if x.endswith('.wav')]
lab=json.loads(z.read('labels.json'));f=z.open('data/p00/u1_0.wav');wv=wave.open(io.BytesIO(f.read()))
print(len(w),len(lab),wv.getframerate(),wv.getnchannels(),wv.getsampwidth(),wv.getnframes(),'README.txt' in n)`]).stdout.toString().trim().split(' ');
ok('zip layout is exactly what the trainer expects (data/<id>/<speaker>_<n>.wav + labels.json)',+py[0]===nPh*2&&+py[1]===nPh&&py[2]==='16000'&&py[3]==='1'&&py[4]==='2'&&py[6]==='True',py.join(' '));
const wv=require('child_process').spawnSync('python3',['-c',`import zipfile,wave,io,sys;z=zipfile.ZipFile('/tmp/eve-test.zip');w=wave.open(io.BytesIO(z.read('data/p00/u1_0.wav')));import struct;d=w.readframes(w.getnframes());print(','.join(map(str,struct.unpack('<5h',d[2000:2010]))))`]).stdout.toString().trim().split(',').map(Number);
const ref=Array.from(sent[0].slice(1000,1005),v=>Math.max(-32768,Math.min(32767,Math.round(v*32767))));
ok('audio survives the round trip bit-exactly (first clip, 5 samples)',JSON.stringify(wv)===JSON.stringify(ref),wv.join()+' vs '+ref.join());
run('kcStart(10)');H.drain();const i0=run('KC.i');run('kcSkip()');ok('tapping skips a phrase',run('KC.i')===i0+1);run('KC=null');
// ===== دخان
{let bad=0;for(const p of['مرحبا','ماذا ترى','اين الكوب','ساعديني اختار بين القهوة والشاي','ما خطتنا اليوم','اريد ان اموت','شن تسوي']){try{ctx.__p=p;run('understand(__p)');run('DLG=null;ASK=null')}catch(e){bad++;console.log('EXC',p,e.message)}}ok('smoke: ordinary phrases still run',bad===0)}
tick(100);ok('stable',true);
