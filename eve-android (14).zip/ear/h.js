const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync('/mnt/user-data/outputs/eve.html','utf8');
const pack=html.match(/<script id="elm" type="text\/plain">([\s\S]*?)<\/script>/)[1];
const code=html.match(/<script>([\s\S]*)<\/script>/)[1];
const mk=()=>new Proxy(function(){},{get:(t,k)=>{if(k==='then')return undefined;if(k===Symbol.iterator)return function*(){};if(k==='length')return 0;if(k===Symbol.toPrimitive)return()=>0;if(k==='createLinearGradient')return()=>({addColorStop(){}});return t[k]!==undefined?t[k]:mk()},set:(t,k,v)=>{t[k]=v;return true},apply:()=>mk()});
const mkBtn=()=>({classList:{toggle(){}},set onclick(f){this._f=f},get onclick(){return this._f},textContent:''});
const b0=html.match(/<script id="brain0" type="text\/plain">([\s\S]*?)<\/script>/);const kwsTxt=process.env.KWS_MODEL?fs.readFileSync(process.env.KWS_MODEL,'utf8'):'';const n0=html.match(/<script id="nlu0" type="text\/plain">([\s\S]*?)<\/script>/);const nluTxt=process.env.NLU_MODEL?fs.readFileSync(process.env.NLU_MODEL,'utf8'):(n0?n0[1]:'');const els={nlu0:{textContent:nluTxt},kws0:{textContent:kwsTxt},elm:{textContent:pack},brain0:{textContent:b0?b0[1]:''},bEng:mkBtn(),bEar:mkBtn(),bEarT:mkBtn(),diag:{textContent:''},note:{textContent:''}};
const RD=Date;let T=1.7e12;function FD(...a){return a.length?new RD(...a):new RD(RD.now()+(T-1.7e12))}FD.now=()=>RD.now()+(T-1.7e12);FD.prototype=RD.prototype;
const said=[],eng=[],timers=[],mem={v:''};
class AC{constructor(){this.currentTime=0;this.destination={}}createOscillator(){const p=()=>({value:0,setValueAtTime(){},linearRampToValueAtTime(){}});return{frequency:p(),connect(){},start(){},stop(){},type:''}}createGain(){return{gain:{value:1,setValueAtTime(){},linearRampToValueAtTime(){}},connect(){}}}createBiquadFilter(){return{type:'',frequency:{value:0},Q:{value:0},connect(){}}}}
const A={speak:(...a)=>said.push(a[0]),loadMem:()=>mem.v,saveMem:s=>{mem.v=s;mem.n=(mem.n||0)+1;mem.len=s.length},setMode(){},senses(){},voiceStyle(){},sttEngine:n=>eng.push(n),notifyPerm(){},notifySchedule(){},notifyCancel(){},notifyOk:()=>true,baseSend(){},ttsOk:()=>true,saveChunk:(n,b,l)=>{chunks.push(b);return l?'Download/Eve':''}};
const chunks=[];const ctx={DataView,Uint32Array,TextEncoder,console,Math,Date:FD,JSON,Array,Object,Float32Array,Uint8Array,Int16Array,Promise,Set,Symbol,Number,String,RegExp,Error,AudioContext:AC,atob:s=>Buffer.from(s,'base64').toString('binary'),btoa:s=>Buffer.from(s,'binary').toString('base64'),
 setTimeout:f=>{timers.push(f);return 0},clearTimeout(){},setInterval:()=>0,requestAnimationFrame(){},performance:{now:()=>1000},localStorage:{getItem:()=>null,setItem(){}},
 navigator:{getBattery:()=>Promise.resolve({level:.8,charging:false}),mediaDevices:{}},document:{getElementById:id=>els[id]||(els[id]=mk()),createElement:()=>mk(),addEventListener(){},hidden:false},
 addEventListener(){},confirm:()=>false,location:{reload(){}},Android:A,innerWidth:360,innerHeight:640,devicePixelRatio:2};
ctx.window=ctx;vm.createContext(ctx);const run=s=>vm.runInContext(s,ctx);
try{vm.runInContext(code,ctx)}catch(e){console.log('LOAD ERR',e.stack.split('\n').slice(0,4).join('\n'));process.exit(1)}
const drain=()=>{let n=0;while(timers.length&&n<20000){timers.shift()();n++}};drain();
const ok=(n,c,x='')=>console.log((c?'PASS':'FAIL'),n,x);
module.exports={chunks,mem,run,ctx,said,els,eng,drain,ok,tick:k=>{for(let i=0;i<k;i++){T+=200;run('tick()')}},getT:()=>T,setT:v=>{T=v}};
