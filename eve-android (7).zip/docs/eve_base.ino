// قاعدة إيف المتحركة (اختيارية): Arduino + HC-05 + L298N + HC-SR04 + حساس حافة IR
// اضبط اسم البلوتوث ليبدأ بـ EVE:  AT+NAME=EVE-BASE  ثم اقرنه بالهاتف من إعدادات البلوتوث.
// الأوامر من إيف: F أمام، L يسار، R يمين، S توقف. القاعدة ترسل: D:<سم> و C:<0|1>.
// السلامة: توقف تلقائي عند أي عائق أقل من 20 سم أو حافة، وبعد 800 مللي ثانية دون أمر.
#include <SoftwareSerial.h>
SoftwareSerial bt(10, 11);            // RX, TX نحو HC-05
const int ENA = 5, IN1 = 6, IN2 = 7, ENB = 3, IN3 = 8, IN4 = 9;
const int TRIG = 12, ECHO = 13, CLIFF = A0;   // CLIFF: LOW = لا يوجد سطح تحت الحساس (عدّله لحساسك)
const int SPEED = 140;                          // 0-255 سرعة هادئة
unsigned long lastCmd = 0, lastTel = 0; char cur = 'S'; int lastCliff = -1;

void drive(int l, int r) {
  digitalWrite(IN1, l > 0); digitalWrite(IN2, l < 0); analogWrite(ENA, abs(l));
  digitalWrite(IN3, r > 0); digitalWrite(IN4, r < 0); analogWrite(ENB, abs(r));
}
long distCm() {
  digitalWrite(TRIG, LOW); delayMicroseconds(3); digitalWrite(TRIG, HIGH); delayMicroseconds(10); digitalWrite(TRIG, LOW);
  long d = pulseIn(ECHO, HIGH, 20000); return d ? d / 58 : 200;
}
void setup() {
  bt.begin(9600);
  pinMode(ENA, OUTPUT); pinMode(ENB, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT); pinMode(CLIFF, INPUT);
  drive(0, 0);
}
void loop() {
  unsigned long now = millis();
  if (bt.available()) { char c = bt.read(); if (c == 'F' || c == 'L' || c == 'R' || c == 'S') { cur = c; lastCmd = now; } }
  long d = distCm(); int cliff = digitalRead(CLIFF) == LOW;
  if (now - lastTel > 120) { bt.print("D:"); bt.println(d); lastTel = now; }
  if (cliff != lastCliff) { bt.print("C:"); bt.println(cliff); lastCliff = cliff; }
  bool stopNow = (now - lastCmd > 800) || cliff || (cur == 'F' && d < 20);
  if (stopNow || cur == 'S') drive(0, 0);
  else if (cur == 'F') drive(SPEED, SPEED);
  else if (cur == 'L') drive(-SPEED, SPEED);
  else if (cur == 'R') drive(SPEED, -SPEED);
}
