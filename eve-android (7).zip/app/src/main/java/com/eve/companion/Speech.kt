package com.eve.companion

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlin.math.max
import kotlin.math.sqrt

/**
 * استماع «ذكي»: نصغي بكاشف نشاط صوتي خفيف (VAD) بلا أي نغمة، ولا نفتح مستمع الكلام إلا عند سماع صوت بشري،
 * فلا تتكرر النغمات كل بضع ثوانٍ. إن لم تتوفر الحزمة العربية دون اتصال نتوقف بهدوء ولا نعيد المحاولة تلقائياً.
 */
class Speech(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onState: (Boolean) -> Unit,
    private val isBusy: () -> Boolean,
    private val diag: (String) -> Unit
) {
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var on = false
    @Volatile private var phase = "stopped"
    private var disabled = false
    private var errCount = 0
    private var sessions = 0
    private var lastErr = 0
    private var lastLevel = 0L

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { fail("NO_SERVICE"); return }
        on = true; disabled = false; errCount = 0; vad()
    }

    fun stop() { on = false; phase = "stopped"; h.removeCallbacksAndMessages(null); try { rec?.destroy() } catch (e: Exception) { }; rec = null }

    private fun fail(why: String) { disabled = true; phase = "stopped"; onState(false); report(why) }
    private fun report(s: String) = diag("{\"stt\":\"$s\",\"sessions\":$sessions,\"err\":$lastErr}")

    /** مرحلة الإصغاء الصامت: AudioRecord + طاقة الصوت. عند صوت متواصل نحو 160 مللي ثانية نفتح المستمع. */
    private fun vad() {
        if (!on || disabled) return
        phase = "vad"; onState(true); report("VAD")
        Thread {
            var ar: AudioRecord? = null
            var trig = false
            try {
                val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                ar = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 4096))
                if (ar.state != AudioRecord.STATE_INITIALIZED) { h.post { if (on && phase == "vad") listen() }; return@Thread }
                ar.startRecording()
                val buf = ShortArray(320); var floor = 250.0; var run = 0
                while (on && phase == "vad") {
                    val n = ar.read(buf, 0, buf.size); if (n <= 0) continue
                    var s = 0.0; for (i in 0 until n) s += buf[i] * buf[i].toDouble()
                    val rms = sqrt(s / n)
                    val t = System.currentTimeMillis()
                    if (t - lastLevel > 120) { lastLevel = t; onLevel((rms / 4000.0).coerceIn(0.0, 1.0).toFloat()) }
                    if (rms < floor * 1.6) floor = floor * 0.98 + rms * 0.02
                    if (isBusy()) { run = 0; continue }
                    if (rms > max(1100.0, floor * 3.5)) run++ else run = max(0, run - 1)
                    if (run >= 8) { trig = true; break }
                }
            } catch (e: Exception) {
            } finally { try { ar?.stop() } catch (e: Exception) { }; try { ar?.release() } catch (e: Exception) { } }
            if (trig) h.post { if (on && phase == "vad") listen() }
        }.start()
    }

    /** مرحلة التعرّف: مرة واحدة لكل جملة. */
    private fun listen() {
        phase = "stt"; sessions++
        try { rec?.destroy() } catch (e: Exception) { }
        rec = SpeechRecognizer.createSpeechRecognizer(ctx).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) onText(t)
                    errCount = 0; back(350)
                }
                override fun onError(e: Int) {
                    lastErr = e
                    when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> back(500)
                        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> fail("LANG_PACK_MISSING")
                        else -> { errCount++; if (errCount >= 4) fail("ERR_$e") else back(2000L * errCount) }
                    }
                }
                override fun onRmsChanged(rms: Float) {}
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        report("STT")
        try { rec?.startListening(i) } catch (e: Exception) { errCount++; back(2000) }
    }

    private fun back(d: Long) {
        try { rec?.destroy() } catch (e: Exception) { }; rec = null
        h.postDelayed({ if (on && !disabled) vad() }, d)
    }
}
