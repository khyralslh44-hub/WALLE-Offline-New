package com.eve.companion

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID

/** وصلة بلوتوث اختيارية بقاعدة متحركة (HC-05 اسمها يبدأ بـ EVE). لا شيء يعمل دون جهاز مقترن. */
class BtBase(private val line: (String) -> Unit) {
    private var sock: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null

    @SuppressLint("MissingPermission")
    fun connect() {
        if (sock != null) return
        Thread {
            try {
                val ad = BluetoothAdapter.getDefaultAdapter() ?: return@Thread
                val dev = ad.bondedDevices.firstOrNull { it.name?.startsWith("EVE", true) == true } ?: return@Thread
                ad.cancelDiscovery()
                val s = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                s.connect(); sock = s; out = s.outputStream
                val r = BufferedReader(InputStreamReader(s.inputStream))
                while (true) { val l = r.readLine() ?: break; line(l.trim()) }
            } catch (e: Exception) { }
            close()
        }.start()
    }

    fun send(c: String) { try { out?.write(c.toByteArray()); out?.flush() } catch (e: Exception) { close() } }
    fun close() { try { out?.write("S".toByteArray()) } catch (e: Exception) { }; try { sock?.close() } catch (e: Exception) { }; sock = null; out = null }
}
