package com.eve.companion

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.util.Calendar

/** إشعارات محلية بالكامل (بلا إنترنت): قناة، مؤقّتات تبقى بعد إعادة التشغيل، وتكرار سنوي لأعياد الميلاد. */
object Notifier {
    private const val CH = "eve_msgs"
    private const val PREFS = "eve"
    private const val KEY = "alarms"

    fun channel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            val c = NotificationChannel(CH, "رسائل إيف", NotificationManager.IMPORTANCE_DEFAULT)
            c.description = "تذكيرات وتهاني ورسائل قصيرة من إيف"
            nm.createNotificationChannel(c)
        }
    }

    fun show(ctx: Context, id: Int, title: String, text: String) {
        channel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(ctx, CH).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true).build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(id, n) } catch (e: Exception) { }
    }

    private fun pending(ctx: Context, id: String, flags: Int): PendingIntent? =
        PendingIntent.getBroadcast(ctx, id.hashCode(), Intent(ctx, AlarmReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or flags)

    private fun arm(ctx: Context, id: String, at: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, id, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        try {
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: Exception) { try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) } catch (e2: Exception) { } }
    }

    private fun load(ctx: Context) = JSONObject(ctx.getSharedPreferences(PREFS, 0).getString(KEY, "{}") ?: "{}")
    private fun save(ctx: Context, o: JSONObject) { ctx.getSharedPreferences(PREFS, 0).edit().putString(KEY, o.toString()).apply() }

    fun schedule(ctx: Context, id: String, at: Long, title: String, text: String, yearly: Boolean) {
        val o = load(ctx); o.put(id, JSONObject().put("t", at).put("ti", title).put("tx", text).put("y", yearly)); save(ctx, o)
        arm(ctx, id, at)
    }

    fun cancel(ctx: Context, id: String) {
        val o = load(ctx); o.remove(id); save(ctx, o)
        try { pending(ctx, id, PendingIntent.FLAG_UPDATE_CURRENT)?.let { ctx.getSystemService(AlarmManager::class.java).cancel(it) } } catch (e: Exception) { }
    }

    /** يُستدعى عند وصول المؤقّت: يعرض الإشعار ويجدول العام القادم إن كان سنوياً. */
    fun fire(ctx: Context, id: String) {
        val o = load(ctx); val j = o.optJSONObject(id) ?: return
        show(ctx, id.hashCode(), j.optString("ti"), j.optString("tx"))
        if (j.optBoolean("y")) {
            val c = Calendar.getInstance(); c.timeInMillis = j.optLong("t"); c.add(Calendar.YEAR, 1)
            j.put("t", c.timeInMillis); save(ctx, o); arm(ctx, id, c.timeInMillis)
        } else { o.remove(id); save(ctx, o) }
    }

    /** بعد إعادة تشغيل الهاتف: نعيد جدولة المستقبلي، ونعرض الفائت فوراً. */
    fun restore(ctx: Context) {
        val o = load(ctx); val now = System.currentTimeMillis()
        for (id in o.keys().asSequence().toList()) {
            val j = o.optJSONObject(id) ?: continue
            if (j.optLong("t") > now) arm(ctx, id, j.optLong("t")) else fire(ctx, id)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { i.getStringExtra("id")?.let { Notifier.fire(c, it) } }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { if (i.action == Intent.ACTION_BOOT_COMPLETED) Notifier.restore(c) }
}
