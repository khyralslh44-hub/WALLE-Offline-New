package com.eve.companion

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

/**
 * صوت إيف الخاص: كلام الهاتف يُركَّب إلى ملف ثم يُعاد تشكيل طابعه (طبقة طفولية، اهتزاز لطيف، إشراق، بريق
 * يلمع مع الكلام) ويُشغَّل. الخوارزمية مطابقة لنموذج Python المُتحقَّق منه (voice/dsp_proto.py).
 * إن فشل أي شيء يُستعمل صوت الهاتف العادي تلقائياً.
 */
class EveVoice(private val h: Handler, private val onPlay: (Boolean) -> Unit) {
    private class Sty(val r: Float, val vib: Float, val spark: Float, val bright: Float)
    private val styles = mapOf(
        "joy" to Sty(1.30f, .5f, .07f, .35f), "love" to Sty(1.22f, .9f, .06f, .25f), "sad" to Sty(1.12f, .8f, .03f, .10f),
        "shy" to Sty(1.34f, .6f, .06f, .30f), "sleepy" to Sty(1.10f, .3f, .02f, .05f), "excited" to Sty(1.40f, .4f, .09f, .45f),
        "fear" to Sty(1.38f, 1.2f, .05f, .40f), "angry" to Sty(1.12f, .2f, .04f, .30f), "curious" to Sty(1.30f, .5f, .07f, .35f),
        "calm" to Sty(1.20f, .5f, .04f, .20f))
    private val def = Sty(1.25f, .5f, .05f, .25f)
    @Volatile private var track: AudioTrack? = null

    fun factor(style: String): Float = (styles[style] ?: def).r

    fun stop() {
        val t = track; track = null
        try { t?.stop() } catch (e: Exception) { }
        try { t?.release() } catch (e: Exception) { }
    }

    private class Wav(val pcm: FloatArray, val sr: Int)

    private fun le16(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p + 1].toInt() and 255) shl 8)
    private fun le32(b: ByteArray, p: Int) = le16(b, p) or (le16(b, p + 2) shl 16)

    private fun readWav(f: File): Wav? {
        val b = f.readBytes()
        if (b.size < 44 || String(b, 0, 4) != "RIFF") return null
        var p = 12; var sr = 22050; var ch = 1; var bits = 16; var off = -1; var len = 0
        while (p + 8 <= b.size) {
            val id = String(b, p, 4); val l = le32(b, p + 4)
            if (id == "fmt ") { ch = le16(b, p + 10); sr = le32(b, p + 12); bits = le16(b, p + 22) }
            else if (id == "data") { off = p + 8; len = if (l <= 0 || off + l > b.size) b.size - off else l; break }
            p += 8 + max(l, 0) + (max(l, 0) and 1)
        }
        if (off < 0 || bits != 16 || ch < 1 || len < 400) return null
        val frames = len / (2 * ch)
        val x = FloatArray(frames)
        for (i in 0 until frames) {
            var s = 0f
            for (c in 0 until ch) { val q = off + (i * ch + c) * 2; s += ((b[q].toInt() and 255) or (b[q + 1].toInt() shl 8)).toShort() / 32768f }
            x[i] = s / ch
        }
        return Wav(x, sr)
    }

    private fun process(x: FloatArray, sr: Int, st: Sty): FloatArray {
        val n = x.size; val m = (n / st.r).toInt(); if (m < 200) return x
        val y = FloatArray(m)
        for (i in 0 until m) { val p = i * st.r; val j = p.toInt(); val f = p - j; val a = if (j < n) x[j] else 0f; val b = if (j + 1 < n) x[j + 1] else 0f; y[i] = a + (b - a) * f }
        val depth = st.vib * 0.0005f * sr; val z = FloatArray(m)
        for (i in 0 until m) {
            val p = i + depth * sin(2 * PI * 5.5 * i / sr).toFloat(); val j = floor(p).toInt(); val f = p - j
            val a = if (j in 0 until m) y[j] else 0f; val b = if (j + 1 in 0 until m) y[j + 1] else 0f; z[i] = a + (b - a) * f
        }
        val a1 = exp(-2 * PI * 1500 / sr).toFloat(); var lp = 0f; val out = FloatArray(m)
        for (i in 0 until m) { lp = a1 * lp + (1 - a1) * z[i]; out[i] = z[i] + st.bright * (z[i] - lp) }
        var env = 0f
        for (i in 0 until m) { env = .995f * env + .005f * abs(out[i]); out[i] += st.spark * env * 6f * sin(2 * PI * 2800 * i / sr).toFloat() }
        val th = tanh(1.2).toFloat(); var pk = 1e-9f
        for (i in 0 until m) { out[i] = tanh(1.2f * out[i]) / th; pk = max(pk, abs(out[i])) }
        val g = .85f / pk; val k = min(80, m / 2)
        for (i in 0 until m) { var v = out[i] * g; if (i < k) v *= i / k.toFloat(); if (i >= m - k) v *= (m - 1 - i) / k.toFloat(); out[i] = v }
        return out
    }

    /** يعالج ملف WAV ويشغّله. عند أي فشل يستدعي onFail (لاستعمال الصوت العادي). */
    fun play(f: File, style: String, onFail: () -> Unit) {
        Thread {
            try {
                val w = readWav(f)
                if (w == null) { h.post { onFail() }; return@Thread }
                val out = process(w.pcm, w.sr, styles[style] ?: def)
                val pcm = ShortArray(out.size) { (out[it] * 32767f).toInt().coerceIn(-32768, 32767).toShort() }
                val t = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(w.sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(pcm.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
                t.write(pcm, 0, pcm.size)
                stop(); track = t; t.play(); h.post { onPlay(true) }
                val ms = pcm.size * 1000L / w.sr
                h.postDelayed({ if (track === t) onPlay(false) }, ms + 150)
            } catch (e: Exception) { h.post { onFail() } }
            finally { try { f.delete() } catch (e: Exception) { } }
        }.start()
    }
}
