import numpy as np
# نموذج مرجعي لمعالجة «صوت إيف» — نفس الخوارزمية التي ستُكتب بـ Kotlin
STY={'joy':(1.30,.5,.07,.35),'love':(1.22,.9,.06,.25),'sad':(1.12,.8,.03,.10),'shy':(1.34,.6,.06,.30),'sleepy':(1.10,.3,.02,.05),
     'excited':(1.40,.4,.09,.45),'fear':(1.38,1.2,.05,.40),'angry':(1.12,.2,.04,.30),'curious':(1.30,.5,.07,.35),'calm':(1.20,.5,.04,.20)}
DEF=(1.25,.5,.05,.25)
def process(x,sr,style):
    r,vib,spark,bright=STY.get(style,DEF)
    n=len(x);m=int(n/r);y=np.zeros(m,np.float32)
    # 1) إعادة تعيين العينات: رفع الطبقة وتصغير «حجم الفم» (طابع طفولي)
    for i in range(m):
        p=i*r;j=int(p);f=p-j;a=x[j] if j<n else 0;b=x[j+1] if j+1<n else 0;y[i]=a+(b-a)*f
    # 2) اهتزاز لطيف (vibrato): تأخير كسري متذبذب
    depth=vib*0.0005*sr;z=np.zeros_like(y)
    for i in range(m):
        d=depth*np.sin(2*np.pi*5.5*i/sr);p=i+d;j=int(np.floor(p));f=p-j
        a=y[j] if 0<=j<m else 0;b=y[j+1] if 0<=j+1<m else 0;z[i]=a+(b-a)*f
    # 3) إشراق: رفع الترددات العليا (high-shelf من مرشح أحادي القطب)
    a=np.exp(-2*np.pi*1500/sr);lp=0;out=np.zeros_like(z)
    for i in range(m):
        lp=a*lp+(1-a)*z[i];out[i]=z[i]+bright*(z[i]-lp)
    # 4) بريق: حامل 2800Hz بمغلف الصوت (يلمع مع الكلام فقط)
    env=0;
    for i in range(m):
        env=.995*env+.005*abs(out[i]);out[i]+=spark*env*6*np.sin(2*np.pi*2800*i/sr)
    # 5) تنعيم قصّ ثم تطبيع
    out=np.tanh(1.2*out)/np.tanh(1.2);pk=np.max(np.abs(out))+1e-9;out=out*(.85/pk)
    k=min(80,m//2);out[:k]*=np.linspace(0,1,k);out[-k:]*=np.linspace(1,0,k)
    return out.astype(np.float32)
def f0(x,sr,lo=80,hi=500):
    x=x-x.mean();ac=np.correlate(x,x,'full')[len(x)-1:];i0=int(sr/hi);i1=int(sr/lo);k=np.argmax(ac[i0:i1])+i0;return sr/k
if __name__=='__main__':
    sr=22050;t=np.arange(int(sr*1.2))/sr;F0=140.0
    # إشارة تشبه حرفاً صائتاً: توافقيات بمغلف مقاطع
    x=sum(np.sin(2*np.pi*F0*h*t)/h for h in range(1,25))*(0.5+0.5*np.sin(2*np.pi*3*t)**2);x=(x/np.abs(x).max()*.6).astype(np.float32)
    print(f'الأصل: f0={f0(x,sr):.1f}Hz  المدة={len(x)/sr:.2f}s  ذروة={np.abs(x).max():.2f}')
    for st in ['joy','sad','excited','sleepy','fear']:
        y=process(x,sr,st);r=STY[st][0]
        print(f'{st:8s} f0={f0(y,sr):6.1f}Hz (متوقع {F0*r:5.1f})  المدة={len(y)/sr:.2f}s (متوقع {len(x)/sr/r:.2f})  ذروة={np.abs(y).max():.2f}  NaN={bool(np.isnan(y).any())}')
