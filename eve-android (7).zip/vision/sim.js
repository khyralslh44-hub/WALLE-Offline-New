const fs=require('fs');const src=fs.readFileSync('sight.js','utf8');
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
function cos(a,b){let d=0,x=0,y=0;const n=Math.min(a.length,b.length);for(let i=0;i<n;i++){d+=a[i]*b[i];x+=a[i]*a[i];y+=b[i]*b[i]}return d/(Math.sqrt(x*y)||1)}
const {osrDecide,selfTrain}=new Function('cos','clamp',src+';return{osrDecide,selfTrain}')(cos,clamp);
let seed=12345;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
const gauss=()=>{let u=0,v=0;while(!u)u=rnd();v=rnd();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};
const D=256,unit=v=>{const m=Math.hypot(...v);return v.map(x=>x/m)},rv=()=>unit(Array.from({length:D},gauss));
function regime(common,sep,pose,noise){const C=rv();const mkId=()=>unit(C.map((c,i)=>common*c+sep*gauss()/Math.sqrt(D)));
 const frame=(c,p)=>unit(c.map((x,i)=>x+pose*p[i]+noise*gauss()/Math.sqrt(D)));return{mkId,frame}}
const R={'E نفس الشخص يتغير كثيراً بين الجلسات (0.75) والغريب بعيد':[0,1,.5,.3],'F ميزات عامة: صاحبه 0.89 والغريب 0.71':[1,.5,.3,.2],'G صاحبه 0.94 والغريب 0.81':[1,.4,.2,.15],'H الوجوه متشابهة جداً: صاحبه 0.98 والغريب 0.92':[1,.25,.1,.1]};
function run(name,[common,sep,pose,noise],mode,diverse){seed=777;const {mkId,frame}=regime(common,sep,pose,noise);
 const NE=+process.env.NE||5;const ids=Array.from({length:NE},mkId),strangers=Array.from({length:25},mkId);
 const store={};ids.forEach((c,i)=>{const p=rv();store['p'+i]=Array.from({length:5},()=>frame(c,diverse?rv():p))});   // تسجيل: جلسة واحدة بوضعية واحدة
 let genTrue=0,genWrong=0,genMiss=0,strAcc=0,N=0,S=0;const now0=1e6;let t=now0;
 const visit=(c,label)=>{const p=rv();let cand='',cnt=0,acc=null;
  for(let f=0;f<10;f++){t+=1500;const v=frame(c,p);let ok=false,nm='';
   if(mode==='old'){const names=Object.keys(store);let b='',bs=-2,s2=-2;for(const n of names){const L=store[n].map(e=>cos(e,v)).sort((a,b)=>b-a),s=(L[0]+L[1])/2;if(s>bs){s2=bs;bs=s;b=n}else if(s>s2)s2=s}ok=bs>=.86&&bs-s2>=.04;nm=b}
   else{const d=osrDecide(store,v,3,.60,.03);ok=d.ok;nm=d.name;if(ok&&mode==='new+self'&&d.s>=d.tau+.04&&d.margin>=.06&&cnt>=2)selfTrain(nm,v,t,store)}
   if(ok){cnt=nm===cand?cnt+1:1;cand=nm}else{cnt=0;cand=''}
   if(cnt>=3&&!acc){acc=nm}}
  return acc};
 for(let s=0;s<12;s++){ids.forEach((c,i)=>{const a=visit(c);N++;if(a==='p'+i)genTrue++;else if(a)genWrong++;else genMiss++});
  for(let k=0;k<5;k++){const a=visit(strangers[(s*5+k)%25]);S++;if(a)strAcc++}}
 return{TAR:genTrue/N,wrong:genWrong/N,miss:genMiss/N,FAR:strAcc/S}}
const f=x=>(100*x).toFixed(0).padStart(3)+'%';
console.log('نتائج على مستوى «زيارة» (3 إطارات متتالية متفقة). TAR=يعرف صاحبه، خطأ=ينسبه لغيره، FAR=يقبل غريباً');
for(const diverse of (process.env.DIV?[true]:[false,true])){console.log('\n========== التسجيل: '+(diverse?'موجَّه (5 وضعيات مختلفة)':'وضعية واحدة (5 لقطات متطابقة تقريباً)')+' ==========');
console.log('النظام'.padEnd(26),'| TAR  خطأ  فوّت | FAR(غريب)');
for(const [name,p] of Object.entries(R)){console.log('\n'+name);for(const m of ['old','new','new+self']){const r=run(name,p,m,diverse);console.log(('  '+{old:'قديم: عتبة ثابتة 0.86',new:'جديد: معايرة ذاتية','new+self':'جديد + تعلّم ذاتي حذر'}[m]).padEnd(26),'|',f(r.TAR),f(r.wrong),f(r.miss),' |',f(r.FAR))}}}
