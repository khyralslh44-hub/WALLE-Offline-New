/*SIGHT_START*/
/* ===== EveSight: تعرّف مفتوح المجموعة ذاتي المعايرة (وجوه، أشياء) — يعاير عتبته من أمثلتك أنت ===== */
function top2(L,v){let a=-2,b=-2;for(const e of L){const s=cos(e,v);if(s>a){b=a;a=s}else if(s>b)b=s}return b<-1?a:(a+b)/2}
const mean=a=>a.reduce((x,y)=>x+y,0)/a.length,sdev=(a,m)=>Math.sqrt(a.reduce((x,y)=>x+(y-m)*(y-m),0)/a.length);
function osrCalib(L,others,floor){
 let tau=floor,mu=.9,sd=.05;
 if(L.length>=3){const intra=L.map((e,i)=>top2(L.filter((_,j)=>j!==i),e));mu=mean(intra);sd=Math.max(.03,sdev(intra,mu));tau=Math.max(floor,mu-(others.length>=3?3:1.5)*sd)}
 if(others.length>=3){const imp=others.map(o=>top2(L,o)),m=mean(imp),s=Math.max(.01,sdev(imp,m)),guard=Math.max(m+2.5*s,Math.max(...imp)+.01);tau=Math.max(tau,Math.min(mu-.5*sd,guard))}
 return{mu,sd,tau:Math.min(.98,tau)}}
function osrDecide(groups,v,minEx,floor,margin){
 const names=Object.keys(groups).filter(n=>groups[n].length>=minEx);if(!names.length)return null;
 const sc=names.map(n=>({n,s:top2(groups[n],v)})).sort((a,b)=>b.s-a.s),b=sc[0],second=sc[1]?sc[1].s:-1,oth=[];
 for(const n of names)if(n!==b.n)for(const e of groups[n])oth.push(e);
 const c=osrCalib(groups[b.n],oth,floor);
 return{name:b.n,s:b.s,tau:c.tau,margin:second<-1?9:b.s-second,ok:b.s>=c.tau&&(names.length<2||b.s-second>=margin)}}
var lastSelf={};
function selfTrain(n,v,now,store){const L=store[n];if(!L||L.length<3||now-(lastSelf[n]||0)<3e4)return false;
 if(Math.max(...L.map(e=>cos(e,v)))>.985)return false;lastSelf[n]=now;const r=Array.from(v,x=>Math.round(x*1e3)/1e3);
 if(L.length<8)L.push(r);else{let bi=0,bs=-2;for(let i=0;i<L.length;i++){let m=-2;for(let j=0;j<L.length;j++)if(j!==i)m=Math.max(m,cos(L[i],L[j]));if(m>bs){bs=m;bi=i}}L[bi]=r}
 return true}
/*SIGHT_END*/
