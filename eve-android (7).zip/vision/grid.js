let seed=1;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
const gauss=()=>{let u=0,v=0;while(!u)u=rnd();v=rnd();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)};
const D=256,unit=v=>{const m=Math.hypot(...v);return v.map(x=>x/m)},rv=()=>unit(Array.from({length:D},gauss));
const cos=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
function stats(common,sep,pose,noise){seed=5;const C=rv();const mk=()=>unit(C.map(c=>common*c+sep*gauss()/Math.sqrt(D)));const fr=(c,p)=>unit(c.map((x,i)=>x+pose*p[i]+noise*gauss()/Math.sqrt(D)));
 const g=[],s=[],w=[];for(let k=0;k<60;k++){const c=mk(),c2=mk(),p1=rv(),p2=rv();g.push(cos(fr(c,p1),fr(c,p2)));w.push(cos(fr(c,p1),fr(c,p1)));s.push(cos(fr(c,p1),fr(c2,p2)))}
 const m=a=>a.reduce((x,y)=>x+y,0)/a.length;return[m(w),m(g),m(s)]}
for(const p of [[0,1,.5,.3],[0,1,.6,.4],[0,1,.7,.5],[0,1,.8,.6],[1,.5,.3,.2],[1,.3,.15,.1],[1,.25,.1,.1],[1,.2,.1,.08],[1,.4,.2,.15],[1,.15,.12,.1]])
 console.log(JSON.stringify(p).padEnd(18),'نفس الجلسة %s | نفس الشخص جلسة أخرى %s | غريب %s',...stats(...p).map(x=>x.toFixed(2)));
