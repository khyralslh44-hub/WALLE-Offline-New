import numpy as np,json,time,sys,os,pickle
from gru import LM
vocab=json.load(open('vocab.json',encoding='utf-8'));ix={w:i for i,w in enumerate(vocab)};V=len(vocab)
data=json.load(open('data.json',encoding='utf-8'))
PAD,BOS,SEP,EOS,UNK=0,1,2,3,4
def enc(e):
    seq=[BOS]+[ix[t] for t in e['c']]+[ix.get(t,UNK) for t in e['u']]+[SEP]+[ix[t] for t in e['r']]+[EOS]
    nc=1+len(e['c']);nu=len(e['u']);w=[0]*nc+[.1]*nu+[0]+[1]*(len(e['r'])+1)  # وزن الهدف عند كل رمز (الهدف = الرمز نفسه)
    return seq,w
S=[enc(e) for e in data];n=len(S);cut=int(n*.96);train,val=S[:cut],S[cut:]
def batch(items,drop=0.0,rs=None):
    T=max(len(s) for s,_ in items);X=np.zeros((len(items),T),np.int64);W=np.zeros((len(items),T),np.float32)
    for i,(s,w) in enumerate(items):
        s=list(s)
        if drop and rs is not None:
            for j in range(9,len(s)):
                if s[j]==SEP:break
                if rs.rand()<drop:s[j]=UNK
        X[i,:len(s)]=s
        for t in range(len(s)-1):W[i,t]=w[t+1]
    return X,W
def evaluate(m,items):
    tot=0;sw=0
    for i in range(0,len(items),128):
        X,W=batch(items[i:i+128]);l,c=m.fwd(X,W);tot+=l*c[2];sw+=c[2]
    return tot/sw
class Adam:
    def __init__(s,p,lr):s.m={k:np.zeros_like(v) for k,v in p.items()};s.v={k:np.zeros_like(v) for k,v in p.items()};s.t=0;s.lr=lr
    def step(s,p,g,lr,clip=1.0):
        s.t+=1;nrm=np.sqrt(sum((x*x).sum() for x in g.values()));f=min(1,clip/(nrm+1e-9))
        for k in p:
            gk=g[k]*f;s.m[k]=.9*s.m[k]+.1*gk;s.v[k]=.99*s.v[k]+.01*gk*gk
            p[k]-=lr*(s.m[k]/(1-.9**s.t))/(np.sqrt(s.v[k]/(1-.99**s.t))+1e-8)
        return nrm
if __name__=='__main__':
    EP=int(sys.argv[1]);B=int(sys.argv[2]);H=int(sys.argv[3]);E=int(sys.argv[4]);BUD=float(sys.argv[5])
    m=LM(V,E=E,H=H,seed=1);opt=Adam(m.p,3e-3);rs=np.random.RandomState(5);steps_per=len(train)//B;total=EP*steps_per;step=0;ep0=0;t0=time.time()
    if os.path.exists('state.pkl'):
        st=pickle.load(open('state.pkl','rb'));m.p=st['p'];opt.m,opt.v,opt.t=st['m'],st['v'],st['t'];step=st['step'];ep0=st['ep'];rs=np.random.RandomState(100+ep0)
        print('resumed at epoch',ep0,'step',step,flush=True)
    else:print('params',sum(v.size for v in m.p.values()),'V',V,'train',len(train),'val',len(val),'steps/epoch',steps_per,flush=True)
    def save(ep):
        pickle.dump({'p':m.p,'m':opt.m,'v':opt.v,'t':opt.t,'step':step,'ep':ep},open('state.pkl','wb'));pickle.dump({'p':m.p,'E':E,'H':H,'V':V},open('ckpt.pkl','wb'))
    for ep in range(ep0,EP):
        idx=rs.permutation(len(train));chunks=[sorted(idx[i:i+B*20],key=lambda j:len(train[j][0])) for i in range(0,len(idx),B*20)]
        bl=[c[i:i+B] for c in chunks for i in range(0,len(c),B) if len(c[i:i+B])==B];rs.shuffle(bl);ls=[];paused=False
        for b in bl:
            lr=3e-3*(.1+.9*.5*(1+np.cos(np.pi*step/total)));X,W=batch([train[j] for j in b],.1,rs)
            l,c=m.fwd(X,W);g=m.bwd(c);opt.step(m.p,g,lr);ls.append(l);step+=1
            if time.time()-t0>BUD:paused=True;break
        if paused:save(ep);print(f'paused inside epoch {ep}, step {step}/{total}, recent loss {np.mean(ls[-50:]):.3f}',flush=True);sys.exit(0)
        vl=evaluate(m,val);print(f'== epoch {ep} train {np.mean(ls):.3f} val {vl:.3f} ppl {np.exp(vl):.2f} t={time.time()-t0:.0f}s',flush=True);save(ep+1)
    print('done',flush=True)
