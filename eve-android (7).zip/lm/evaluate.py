import numpy as np,json,random,re,sys,pickle
from sample import Gen,detok
from gen_data import I,EMO,STY,TOD,BOND,tok,nz,R,reply,CLS
g=Gen(sys.argv[1] if len(sys.argv)>1 else 'ckpt.pkl');rs=np.random.RandomState(11)
data=json.load(open('data.json',encoding='utf-8'));known={' '.join(e['r']) for e in data}
res={'n':0,'novel':0,'slot_bad':0,'loop':0,'empty':0,'intent_ok':0};per={}
SL=re.compile(r'<(\w+)>')
for intent in I:
    d=I[intent];ok=0;tot=0;ex=[]
    for _ in range(40):
        emo=random.choice(EMO);style=random.choice(STY);tod=random.choice(TOD);bond=random.choice(BOND)
        fl={'name':random.random()<.5,'like':random.random()<.5,'thing':random.random()<.5}
        u=random.choice(d['u']);us=SL.findall(u)
        cond=['<s_%s>'%style,'<t_%s>'%tod,'<b_%s>'%bond,'<e_%s>'%emo,'<i_%s>'%intent,'<n%d>'%fl['name'],'<l%d>'%fl['like'],'<v%d>'%fl['thing']]
        out,lp=g.gen(cond,tok(nz(u)) if u else [],rs=rs);txt=' '.join(out);res['n']+=1;tot+=1
        if txt not in known:res['novel']+=1
        avail=set(us)|{k for k,v in fl.items() if v}|{'act','time'}
        bad=[t for t in SL.findall(txt) if t not in avail]
        if bad:res['slot_bad']+=1
        w=txt.split()
        if len(set(w))<len(w)*.6 and len(w)>6:res['loop']+=1
        if not out:res['empty']+=1
        # هل الجواب من عائلة النية؟ (نتحقق أن أغلب كلماته ظهرت في ردود هذه النية في التدريب)
        fam={x for e in data if e['i']==intent for x in e['r']}
        if all((x in fam) for x in out):ok+=1;res['intent_ok']+=1
        if len(ex)<2:ex.append((emo,style,detok(out)))
    per[intent]=(ok/tot,ex)
print('samples',res['n'],'| novel combos %.0f%%'%(100*res['novel']/res['n']),'| slot misuse %.1f%%'%(100*res['slot_bad']/res['n']),'| loops %d | empty %d'%(res['loop'],res['empty']),'| in-intent vocabulary %.1f%%'%(100*res['intent_ok']/res['n']))
for k,(a,ex) in per.items():
    print(f'{k:9s} {a*100:3.0f}%  ',' || '.join(f'[{e}/{s[:3]}] {t}' for e,s,t in ex))
