import numpy as np,json,pickle,base64,sys
from gru import LM
import train as T
d=pickle.load(open('ckpt.pkl','rb'));p=d['p'];E,H,V=d['E'],d['H'],d['V']
vocab=json.load(open('vocab.json',encoding='utf-8'))
pack={'E':E,'H':H,'V':V,'vocab':vocab,'q':{},'f':{}};deq={}
for k in ['Emb','Wx','Wh','Wp']:
    w=p[k].astype(np.float32);sc=np.maximum(np.abs(w).max(1),1e-8)/127.0;q=np.clip(np.round(w/sc[:,None]),-127,127).astype(np.int8)
    pack['q'][k]={'shape':list(w.shape),'scale':[float(f'{x:.6g}') for x in sc],'data':base64.b64encode(q.tobytes()).decode()};deq[k]=q.astype(np.float32)*sc[:,None]
for k in ['bx','bh','bo']:
    pack['f'][k]=[float(f'{x:.5g}') for x in p[k]];deq[k]=np.array(pack['f'][k],np.float32)
m=LM(V,E=E,H=H);m.p={k:v.astype(np.float32) for k,v in p.items()};l0=T.evaluate(m,T.val)
m.p=deq;l1=T.evaluate(m,T.val)
print(f'val loss float32 {l0:.4f} -> int8 {l1:.4f}  (ppl {np.exp(l0):.3f} -> {np.exp(l1):.3f})')
s=json.dumps(pack,ensure_ascii=False,separators=(',',':'));open('eve_lm.json','w',encoding='utf-8').write(s)
pickle.dump({'p':deq,'E':E,'H':H,'V':V},open('ckpt_int8.pkl','wb'))
print('pack size KB',len(s.encode())//1024,'| int8 weights KB',sum(len(base64.b64decode(v['data'])) for v in pack['q'].values())//1024)
