# يحقن أوزان eve_lm.json داخل app/src/main/assets/eve.html بعد إعادة التدريب:  python3 lm/embed_lm.py
import re
html="app/src/main/assets/eve.html";s=open(html,encoding="utf-8").read();p=open("lm/eve_lm.json",encoding="utf-8").read()
assert "</script" not in p
s2=re.sub(r"(<script id=\"elm\" type=\"text/plain\">)[\s\S]*?(</script>)",lambda m:m.group(1)+p+m.group(2),s,count=1)
open(html,"w",encoding="utf-8").write(s2);print("embedded",len(p)//1024,"KB")
