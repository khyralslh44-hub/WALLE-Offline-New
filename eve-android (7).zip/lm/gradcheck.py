import numpy as np
from gru import LM
m=LM(9,E=5,H=6,seed=1,dtype=np.float64)
for k in m.p:m.p[k]=m.p[k]+np.random.RandomState(2).randn(*m.p[k].shape)*.1
r=np.random.RandomState(3);X=r.randint(0,9,(4,7));W=(r.rand(4,7)>.3).astype(np.float64)
loss,c=m.fwd(X,W);g=m.bwd(c);worst=0
for k,v in m.p.items():
    for _ in range(6):
        idx=tuple(r.randint(0,d) for d in v.shape);o=v[idx];eps=1e-6
        v[idx]=o+eps;lp,_=m.fwd(X,W);v[idx]=o-eps;lm,_=m.fwd(X,W);v[idx]=o
        num=(lp-lm)/(2*eps);an=g[k][idx];rel=abs(num-an)/max(1e-8,abs(num)+abs(an));worst=max(worst,rel)
    print(k,'ok' if worst<1e-5 else 'CHECK',f'{worst:.2e}')
print('max relative error',f'{worst:.2e}')
