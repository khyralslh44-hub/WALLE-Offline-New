import numpy as np
def sig(x):return 1/(1+np.exp(-x))
class LM:
    def __init__(s,V,E=64,H=256,seed=0,dtype=np.float32):
        r=np.random.RandomState(seed);s.V,s.E,s.H,s.dt=V,E,H,dtype
        s.p={'Emb':r.randn(V,E)*.1,'Wx':r.uniform(-1,1,(E,3*H))/np.sqrt(E),'Wh':r.uniform(-1,1,(H,3*H))/np.sqrt(H),'bx':np.zeros(3*H),'bh':np.zeros(3*H),'Wp':r.randn(H,E)/np.sqrt(H),'bo':np.zeros(V)}
        for k in s.p:s.p[k]=s.p[k].astype(dtype)
    def fwd(s,X,W):
        """X:(B,T) ints, W:(B,T) وزن الهدف عند كل موضع (الهدف X[:,t+1]). يعيد الخسارة والذاكرة."""
        p=s.p;B,T=X.shape;H=s.H;h=np.zeros((B,H),s.dt);C=[]
        xs=p['Emb'][X[:,:-1]]  # (B,T-1,E)
        for t in range(T-1):
            gx=xs[:,t]@p['Wx']+p['bx'];gh=h@p['Wh']+p['bh']
            z=sig(gx[:,:H]+gh[:,:H]);r=sig(gx[:,H:2*H]+gh[:,H:2*H]);n=np.tanh(gx[:,2*H:]+r*gh[:,2*H:])
            hn=(1-z)*n+z*h;C.append((h,z,r,n,gh[:,2*H:]));h=hn;C[-1]=C[-1]+(hn,)
        hs=np.stack([c[5] for c in C],1)  # (B,T-1,H)
        pr=hs@p['Wp'];lg=pr@p['Emb'].T+p['bo']
        m=lg.max(-1,keepdims=True);e=np.exp(lg-m);sm=e/e.sum(-1,keepdims=True)
        tg=X[:,1:];w=W[:,:T-1] if W.shape[1]>=T-1 else W
        nll=-np.log(np.take_along_axis(sm,tg[...,None],-1)[...,0]+1e-12)
        sw=max(w.sum(),1e-9);loss=(nll*w).sum()/sw
        return loss,(X,w,sw,xs,C,hs,pr,sm)
    def bwd(s,cache):
        X,w,sw,xs,C,hs,pr,sm=cache;p=s.p;B,T1=X.shape[0],X.shape[1]-1;H=s.H;g={k:np.zeros_like(v) for k,v in p.items()}
        dl=sm.copy();tg=X[:,1:]
        np.put_along_axis(dl,tg[...,None],np.take_along_axis(dl,tg[...,None],-1)-1,-1)
        dl*=(w/sw)[...,None]
        dp=dl@p['Emb'];g['Emb']+=dl.reshape(-1,s.V).T@pr.reshape(-1,s.E);g['bo']+=dl.sum((0,1))
        g['Wp']+=hs.reshape(-1,H).T@dp.reshape(-1,s.E);dhs=dp@p['Wp'].T
        dh=np.zeros((B,H),s.dt);DGX=np.zeros((B,T1,3*H),s.dt);DGH=np.zeros((B,T1,3*H),s.dt);HP=np.zeros((B,T1,H),s.dt)
        for t in range(T1-1,-1,-1):
            h,z,r,n,ghn,hn=C[t];dh=dh+dhs[:,t]
            dn=dh*(1-z);dz=dh*(h-n);dhp=dh*z
            dnp=dn*(1-n*n);dr=dnp*ghn;drp=dr*r*(1-r);dzp=dz*z*(1-z)
            DGX[:,t]=np.concatenate([dzp,drp,dnp],1);DGH[:,t]=np.concatenate([dzp,drp,dnp*r],1);HP[:,t]=h
            dh=dhp+DGH[:,t]@p['Wh'].T
        g['Wx']+=xs.reshape(-1,s.E).T@DGX.reshape(-1,3*H);g['Wh']+=HP.reshape(-1,H).T@DGH.reshape(-1,3*H)
        g['bx']+=DGX.sum((0,1));g['bh']+=DGH.sum((0,1))
        dx=DGX@p['Wx'].T;np.add.at(g['Emb'],X[:,:-1].ravel(),dx.reshape(-1,s.E))
        return g
