import numpy as np,json,pickle,re
from gen_data import nz,tok,EMO
def sig(x):return 1/(1+np.exp(-x))
class Gen:
    def __init__(s,ck='ckpt.pkl',p=None):
        d=pickle.load(open(ck,'rb')) if p is None else p;s.p={k:v.astype(np.float32) for k,v in d['p'].items()};s.H=d['H'];s.E=d['E']
        s.vocab=json.load(open('vocab.json',encoding='utf-8'));s.ix={w:i for i,w in enumerate(s.vocab)}
    def step(s,h,t,out=True):
        p=s.p;H=s.H;x=p['Emb'][t];gx=x@p['Wx']+p['bx'];gh=h@p['Wh']+p['bh']
        z=sig(gx[:H]+gh[:H]);r=sig(gx[H:2*H]+gh[H:2*H]);n=np.tanh(gx[2*H:]+r*gh[2*H:]);h=(1-z)*n+z*h
        if not out:return h,None
        return h,(h@p['Wp'])@p['Emb'].T+p['bo']
    def gen(s,cond,user,temp=.7,topp=.9,maxn=28,rs=None,greedy=False):
        rs=rs or np.random;h=np.zeros(s.H,np.float32);seq=[1]+[s.ix[c] for c in cond]+[s.ix.get(u,4) for u in user]+[2]
        lg=None
        for i,t in enumerate(seq):h,lg=s.step(h,t,out=(i==len(seq)-1))
        out=[];lp=0
        for _ in range(maxn):
            l=lg.copy();l[[0,1,2,4]]=-1e9
            if greedy:t=int(l.argmax());pr=np.exp(l-l.max());pr/=pr.sum()
            else:
                l=l/temp;pr=np.exp(l-l.max());pr/=pr.sum();o=np.argsort(-pr);c=np.cumsum(pr[o]);k=int((c<topp).sum())+1;q=np.zeros_like(pr);q[o[:k]]=pr[o[:k]];q/=q.sum();t=int(rs.choice(len(q),p=q))
            lp+=np.log(max(pr[t],1e-9))
            if t==3:break
            out.append(s.vocab[t]);h,lg=s.step(h,t)
        return out,lp/max(1,len(out)+1)
def detok(ts):
    s=' '.join(ts);s=re.sub(r' ([،؟!.…:])',r'\1',s);return s
