package com.example.walle

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions

class MainActivity : Activity() {
    private lateinit var tvStatus: TextView
    private lateinit var tvEmotionText: TextView
    private lateinit var pbHappiness: ProgressBar
    private lateinit var ivWallEFace: ImageView
    private lateinit var btnTalk: Button
    private var robotCuriosity = 50

    companion object { private const val REQUEST_IMAGE_CAPTURE = 41 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tvStatus)
        tvEmotionText = findViewById(R.id.tvEmotionText)
        pbHappiness = findViewById(R.id.pbHappiness)
        ivWallEFace = findViewById(R.id.ivWallEFace)
        btnTalk = findViewById(R.id.btnTalk)
        btnTalk.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            if (intent.resolveActivity(packageManager) != null) {
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE)
            } else {
                Toast.makeText(this, "لا يوجد تطبيق كاميرا متاح", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Uses the camera app intent for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val bitmap = data?.extras?.get("data") as? Bitmap
            if (bitmap != null) {
                ivWallEFace.setImageBitmap(bitmap)
                analyzeLivingThingsAndFood(InputImage.fromBitmap(bitmap, 0))
            } else {
                tvEmotionText.text = "🤖 لم تصلني الصورة بوضوح. حاول مرة أخرى!"
            }
        }
    }

    private fun analyzeLivingThingsAndFood(inputImage: InputImage) {
        tvEmotionText.text = "👀 WALL-E يفتح عدساته ويدقق في الكائن أمامه..."
        btnTalk.isEnabled = false
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
        labeler.process(inputImage)
            .addOnSuccessListener { labels ->
                if (labels.isNotEmpty()) {
                    val detectedObject = labels.maxByOrNull { it.confidence }!!.text.lowercase()
                    when {
                        detectedObject.contains("cat") || detectedObject.contains("dog") || detectedObject.contains("animal") -> {
                            robotCuriosity = (robotCuriosity + 15).coerceAtMost(100)
                            tvEmotionText.text = "🤖 *صفير خائف ومندهش!* 😰\nرصد WALL-E كائنًا حيًا: $detectedObject! يتراجع قليلًا بحذر من هذا الزائر الفضولي."
                            ivWallEFace.animate().scaleX(0.88f).scaleY(0.88f).rotation(-6f).setDuration(400).start()
                        }
                        detectedObject.contains("food") || detectedObject.contains("fruit") || detectedObject.contains("apple") || detectedObject.contains("bread") -> {
                            robotCuriosity = (robotCuriosity + 10).coerceAtMost(100)
                            tvEmotionText.text = "🤖 وااالي؟!! 🍎\nرصد شيئًا قد يكون طعامًا: $detectedObject. يتأمله بفضول ويتذكر نبتته الخضراء الصغيرة!"
                            ivWallEFace.animate().scaleX(1.1f).scaleY(1.1f).rotation(8f).setDuration(300).start()
                        }
                        detectedObject.contains("person") || detectedObject.contains("human") || detectedObject.contains("face") -> {
                            robotCuriosity = (robotCuriosity + 5).coerceAtMost(100)
                            tvEmotionText.text = "🥰 وااالي!\nرصد شخصًا في الصورة. يلوّح بفرح ويشعر بالرفقة!"
                            ivWallEFace.animate().scaleX(1.05f).scaleY(1.05f).rotation(0f).setDuration(200).start()
                        }
                        else -> {
                            robotCuriosity = (robotCuriosity + 3).coerceAtMost(100)
                            tvEmotionText.text = "🤖 وااالي يفحص المكان.. أعتقد أنني أرى: $detectedObject. هل يمكن أن تكون قطعة مفيدة؟"
                        }
                    }
                } else {
                    tvEmotionText.text = "🤖 يرمش WALL-E بعدساته.. لم يستطع تمييز الصورة بوضوح."
                }
                updateRobotUI()
            }
            .addOnFailureListener {
                tvEmotionText.text = "🤖 *أصوات تشويش*.. تعذّر تحليل الصورة. حاول مرة أخرى."
            }
            .addOnCompleteListener { labeler.close(); btnTalk.isEnabled = true }
    }

    private fun updateRobotUI() {
        pbHappiness.progress = robotCuriosity
        tvStatus.text = "الحواس جاهزة | مستوى الفضول: $robotCuriosity%"
    }
}
