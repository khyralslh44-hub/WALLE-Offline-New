const t0=Date.now();const H=require('./h.js');const {run,ctx,said,tick}=H;const boot=Date.now()-t0;
console.log('إقلاع أول تشغيل بعد شحن الدماغ مدرَّباً:',boot,'ms (كان 22363 ms)');
console.log('BR.ready =',run('BR.ready'),'| booting =',run('!!BR.booting'),'| بذرة =',run('M.brainSeed'));
// جودة الدماغ: خطأ العاطفة مقابل الغريزة على مدخلات من نفس توزيع الطفولة، مقارنةً بدماغ غير مدرَّب
const out=run(`(function(){const R=Math.random;let eT=0,eU=0,n=300;const W0=Float32Array.from(BR.Wa);
 const z0=Float32Array.from(BR.Wa.fill(0));BR.Wa.set(W0);
 const zf=x=>{BR.r.fill(0);BR.s.fill(0);BR.yh=null;const v=BR.x;v.fill(0);for(let i=0;i<NI;i++)v[i]=x[i];for(let t=0;t<12;t++)bcore(v,false);return Float32Array.from(BR.z)};
 for(let q=0;q<n;q++){const x=new Float32Array(NI);for(let k=0;k<NI;k++)x[k]=R()<.1?(R()*2-1)*.8:0;x[15]=R()<.4?1:0;x[14]=x[15]*R()*.6;x[36]=R()-.5;x[37]=R();x[38]=R()-.5;x[39]=R()-.5;x[32]=R()<.2?(R()<.5?-.8:.8):0;x[27]=R()<.1?1:0;x[24]=R()<.05?1:0;x[23]=R()<.1?R():0;
  const z=zf(x),T=innateAffect(x);for(let k=0;k<3;k++){let a=0;for(let i=0;i<NZ;i++)a+=BR.Wa[k*NZ+i]*z[i];eT+=Math.abs(Math.tanh(a)-T[k]);eU+=Math.abs(0-T[k])}}
 return{trained:eT/(3*n),untrained:eU/(3*n)}})()`);
console.log('خطأ العاطفة مقابل الغريزة: دماغ مدرَّب مسبقاً',out.trained.toFixed(3),'| دماغ غير مدرَّب',out.untrained.toFixed(3));
console.log(out.trained<.5*out.untrained?'PASS الدماغ المشحون يؤدي كدماغ مدرَّب (أقل من نصف خطأ غير المدرَّب)':'FAIL');
tick(100);run("understand('مرحبا')");console.log('رد على التحية:',said.slice(-1)[0]);
