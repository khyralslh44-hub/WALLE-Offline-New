const t0=Date.now();const H=require('./h.js');const {run,ctx,said,tick,getT,setT}=H;const boot=Date.now()-t0;
console.log('إقلاع كامل (تحليل JS + تدريب الطفولة الأول 12000 خطوة + فك أوزان LM): ',boot,'ms على هذا الحاسوب');
const timeIt=(n,f)=>{const a=process.hrtime.bigint();for(let i=0;i<n;i++)f(i);return Number(process.hrtime.bigint()-a)/1e6/n};
console.log('تكلفة tick() الواحد:',timeIt(500,()=>{H.setT(H.getT()+200);run('tick()')}).toFixed(3),'ms (يُستدعى 5 مرات/ثانية)');
const Q=['مرحبا','كيف حالك','ماذا ترى','احب القهوة','ماذا تفعلين','انا حزين','كم الساعة','ساعديني اختار بين القهوة والشاي'];
console.log('تكلفة understand() للجملة:',timeIt(160,i=>{ctx.__q=Q[i%Q.length];run('understand(__q);DLG=null;ASK=null')}).toFixed(2),'ms');
// حفظ: عدد المرات وحجم M بعد استعمال ثقيل
const m0=H.ctx; run("M.voice=M.voice||{}");
const S=require('./synth.js');const words=S.mkWords(22,5);S.setSeed(3);
run('earEnrollStart()');for(let i=0;i<22;i++)for(let k=0;k<3;k++){ctx.__u=S.toB64(S.word(words[i],S.spk({})));run('Eve.utt(__u)')}
run("{const n=Date.now();for(let i=0;i<300;i++)M.ep.push({t:n-i*6e4,p:'المطبخ',w:'سالم',o:['cup','book'],a:'يأكل',m:'joy',v:.5,s:'كلامك «ما»',sal:.6,c:1})}");
const jl=run('JSON.stringify(M).length');const js=timeIt(40,()=>run('JSON.stringify(M)'));
console.log('حجم M بعد تعليم 22 عبارة صوتية و300 تجربة:',(jl/1024).toFixed(0),'KB | زمن JSON.stringify:',js.toFixed(2),'ms');
const breakdown=run('Object.entries(M).map(([k,v])=>[k,JSON.stringify(v).length]).sort((a,b)=>b[1]-a[1]).slice(0,6)');console.log('أكبر مكوّنات M:',breakdown.map(([k,n])=>k+' '+(n/1024).toFixed(0)+'KB').join(' | '));
H.mem=H.mem; const n0=(global.__memn||0);
const mem=H.mem;mem.n=0;const T0=getT();for(let i=0;i<1500;i++){setT(getT()+200);run('tick()')}
console.log('عدد مرات الكتابة على التخزين خلال 5 دقائق من التشغيل الخامل:',mem.n,'(كل كتابة =',(mem.len/1024).toFixed(0),'KB)');
