// يولّد الدماغ المدرَّب مسبقاً بنفس خطوة تدريب الطفولة التي كانت تجري على الهاتف
const t0=Date.now();const H=require('./h.js');const {run}=H;
const ready=run('BR.ready'),seed=run('M.brainSeed');
if(!ready||seed!==20240601){console.log('لم يكتمل التدريب أو البذرة مختلفة',ready,seed);process.exit(1)}
const j=run('JSON.stringify(packBrain())');require('fs').writeFileSync('brain0.json',j);console.log('تدريب الطفولة على الحاسوب:',Date.now()-t0,'ms | حجم الدماغ',(j.length/1024).toFixed(1),'KB | بذرة',seed);
