# نبقي كود التطبيق كما هو، فالضغط يقع على المكتبات غير المستخدمة فقط
-keep class com.eve.companion.** { *; }
# جسر JavaScript (يُستدعى بالاسم من الصفحة)
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
# MediaPipe وJNI
-keep class com.google.mediapipe.** { *; }
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.mediapipe.**
-dontwarn com.google.auto.value.**
-dontwarn javax.lang.model.**
-dontwarn org.checkerframework.**
-dontwarn com.google.errorprone.annotations.**
# Vosk وJNA (النكهة الكاملة)
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-keep class * implements com.sun.jna.** { *; }
-dontwarn com.sun.jna.**
-dontwarn java.awt.**
