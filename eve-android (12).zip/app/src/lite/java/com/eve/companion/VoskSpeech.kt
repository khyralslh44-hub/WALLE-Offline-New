package com.eve.companion

import android.content.Context

/** النكهة الخفيفة: لا مكتبة Vosk ولا نموذجها داخل التطبيق، فيرجع التطبيق فوراً إلى الأذن المحلية أو محرك جوجل. */
class VoskSpeech(
    @Suppress("UNUSED_PARAMETER") ctx: Context,
    @Suppress("UNUSED_PARAMETER") onText: (String) -> Unit,
    @Suppress("UNUSED_PARAMETER") onLevel: (Float) -> Unit,
    @Suppress("UNUSED_PARAMETER") onState: (Boolean) -> Unit,
    @Suppress("UNUSED_PARAMETER") isBusy: () -> Boolean,
    @Suppress("UNUSED_PARAMETER") diag: (String) -> Unit,
    private val onFail: () -> Unit
) : Ear {
    override fun start() { onFail() }
    override fun stop() { }
}
