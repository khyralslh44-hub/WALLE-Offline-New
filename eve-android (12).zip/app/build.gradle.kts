plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.eve.companion"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.eve.companion"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
        ndk { abiFilters += listOf("arm64-v8a") }
        // نحذف لغات المكتبات غير المستخدمة (تقليل الحجم)
        resourceConfigurations += listOf("ar", "en")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    // «lite» (الافتراضية): بلا مكتبة Vosk ولا نموذجها | «full»: مع الأذن العربية المدمجة (وزن كبير)
    flavorDimensions += "engine"
    productFlavors {
        create("lite") { dimension = "engine" }
        create("full") { dimension = "engine"; versionNameSuffix = "-full" }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug") // للتثبيت المباشر على هاتفك
        }
    }
    packaging { resources { excludes += setOf("/META-INF/AL2.0", "/META-INF/LGPL2.1", "DebugProbesKt.bin", "kotlin-tooling-metadata.json") } }
    androidResources { noCompress += listOf("tflite", "task", "mdl", "fst", "int", "dubm", "mat", "conf", "stats", "ie", "bin") }
}
dependencies {
    implementation("androidx.activity:activity-ktx:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
    // أذن عربية مدمجة بلا إنترنت: في النكهة الكاملة فقط (النموذج يُضمَّن وقت البناء من .github/workflows/build.yml)
    "fullImplementation"("com.alphacephei:vosk-android:0.3.47")
    "fullImplementation"("net.java.dev.jna:jna:5.13.0@aar")
}
